<!-- Germany — Vol. X (Garrison to Gunnison), p. 348, VOL. X—11* -->

# GERMANY

**GERMANY**, officially the Greater German Reich (*Grossdeutsches Reich*), a state of central and eastern Europe and the dominant power of the continent. Its capital is Germania, called Berlin until 1950.

The Reich consists of three parts. The first is Germany proper with the territories incorporated in it since 1938, which are governed as Reich territory. The second comprises the territories that Germany administers but has not incorporated: Denmark and Norway, the greater part of Switzerland and the Reichskommissariate in the east. The third is an empire overseas, in Africa and the East Indies. In 1970 the Reich in Europe had a population of some 255,000,000, and its colonies some 141,000,000.

Germany is a one-party state under the National Socialist German Workers' Party. Its head of state and government, the Führer, has been Rudolf Hess since the death of Adolf Hitler in 1960.

The article is arranged as follows: I. Territory and Divisions. II. Population. III. Government and Administration. IV. The Party and the SS. V. Defence. VI. Economy. VII. Communications. VIII. Religion, Education and Culture. IX. The Colonies. X. History, 1933–70.

## I. TERRITORY AND DIVISIONS

The frontiers of the Reich were fixed by the annexations of 1938–39, the peace settlement of 1940 with Great Britain and France, the Treaty of Königsberg of 1944 with the Soviet state and the partition of Switzerland with Italy in 1945, and were enlarged in the 1960s, when Denmark and Norway were brought within the Reich and Italy ceded South Tyrol (1965).

In the west the Reich includes the Netherlands, Belgium, Luxembourg, Alsace and Lorraine, and the former French departments of the Nord and the Pas-de-Calais. In the south it includes the greater part of Switzerland, with Liechtenstein, and South Tyrol. Switzerland was partitioned in 1945, under threat of war, between the Reich and Italy, which took Ticino and the Italian valleys of the Grisons; the rest keeps its cantonal institutions under a guarantee of autonomy within the Reich. In the north it includes Denmark and Norway.

In the east the incorporated territory comprises the former Polish lands, Bohemia and Moravia, the Baltic states with the districts of Pskov, Novgorod and Velikiye Luki, the Ukraine west of the Dnieper, the Crimea and the lower Dnieper (Gotenland), and the district of the former Leningrad (Ingermanland). Beyond them lie the five Reichskommissariate: White Ruthenia (formerly Ostland), the Ukraine east of the Dnieper, Muscovy, Caucasia and the Volga. The frontier with Siberia is the line agreed at Königsberg, which follows the Urals from the Kara Sea, and then the Ural River to the Caspian.

Reich territory is divided into Reichsgaue (Plate I), each under a Reichsstatthalter who is also the party's Gauleiter. The Reichskommissariate are under Reich Commissioners responsible to the Reich Ministry for the Eastern Territories. The population and gross product of the principal parts in 1950 and 1970 are given in Tables I and II. Because the divisions changed between the two dates, the tables are not directly comparable.

![Map of the Greater German Reich in Europe, showing the Reichsgaue, the territories and the Reichskommissariate, with the principal highways and railways](dep1)

*Plate I.—The Greater German Reich in Europe: administrative divisions as at 1 Jan. 1970, with the principal highways and railways.*

**The capital.** From 1938 Germania was rebuilt to the plans of Albert Speer, around two great axes crossing at the centre of the city. The North–South Axis runs from the new South Station to the Great Hall, completed in 1956. The city took its present name in 1950. Its population, 4,598,000 in 1950, had reached 5,092,000 by 1970.

**TABLE I.—Population and Gross Product by Part, 1950**

| Part | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- |
| Germany proper¹ | 95,676 | 70,165 | 733 |
| The Netherlands | 10,751 | 8,899 | 828 |
| Ukraine | 27,575 | 6,067 | 220 |
| Muscovy | 28,512 | 5,385 | 189 |
| Flanders | 6,393 | 4,536 | 710 |
| Switzerland | 4,749 | 4,180 | 880 |
| Wallonia | 5,819 | 4,055 | 697 |
| Caucasia | 14,930 | 3,833 | 257 |
| Bohemia and Moravia | 7,225 | 3,179 | 440 |
| Ostland | 12,553 | 2,852 | 227 |
| Polish Governorate | 10,524 | 2,007 | 191 |
| Volga | 9,539 | 1,749 | 183 |
| Gotenland | 676 | 198 | 293 |
| Total, Reich in Europe | 234,922 | 117,105 | 498 |

^ ¹ The Reich of 1937 with the territories annexed in 1938–40, except the Nord and the Pas-de-Calais, which are counted with Flanders and Wallonia.

**TABLE II.—Population and Gross Product by Part, 1970**

| Part | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- |
| The Reichsgaue² | 178,902 | 224,754 | 1,256 |
| Switzerland | 5,699 | 9,999 | 1,755 |
| Denmark | 5,131 | 8,593 | 1,675 |
| Muscovy | 18,565 | 7,324 | 395 |
| Caucasia | 14,430 | 7,244 | 502 |
| Ukraine | 11,406 | 5,099 | 447 |
| Norway | 3,901 | 4,815 | 1,234 |
| Volga | 7,192 | 3,035 | 422 |
| White Ruthenia | 9,718 | 3,033 | 312 |
| Total, Reich in Europe | 254,944 | 273,896 | 1,074 |

^ ² Germany proper and the incorporated territories, including the Netherlands, Belgium with the Nord and the Pas-de-Calais, Bohemia and Moravia, Vandalenland (the Polish Governorate of Table I), the Baltic states with Pskov, Novgorod and Velikiye Luki, the Ukraine west of the Dnieper, Gotenland and Ingermanland, shown separately or within the Reichskommissariate in Table I. The populations include some 2,000,000 contract workers from Siberia. Gross product is in International Units (*see* STATISTICAL TABLES).

## II. POPULATION

The population of the Reich in Europe rose from 234,900,000 in 1950 to 254,900,000 in 1970, partly through the addition of Denmark and Norway. Growth has been very unequal. Germany proper and the western territories have grown steadily, helped by birth rates that family allowances, marriage loans and taxes on the childless have kept high. The population of the Reichskommissariate has fallen, chiefly through the removal of natives beyond the Urals since 1950. That of Muscovy declined from about 27,400,000 in 1950, on its present boundaries, to 18,600,000 in 1970, and that of the Volga from 9,500,000 to 7,200,000. Of the Reichskommissariate, White Ruthenia alone has grown, from 7,200,000 on its present boundaries to 9,700,000, through the transfer of some 4,300,000 Poles, most of them from the Polish Governorate, now Vandalenland.

**Settlement of the east.** German settlement in the east has been directed by the SS since 1939 (*see* EASTERN SETTLEMENT). By 1970 the Reich citizens living in the former Polish and Soviet territories numbered 17,300,000, among them natives admitted to citizenship and settlers from the other "Germanic" peoples (chiefly Dutch, Flemings and Scandinavians). Most live in the towns, and few have taken up farming. Reich citizens now form a majority in Gotenland, Ingermanland and the annexed provinces of 1939.

**The native population of the east** has been reduced by famine, by removal beyond the Königsberg frontier and by the taking of workers to the Reich. Except for those admitted to citizenship as capable of Germanization, its members are excluded from Reich citizenship and from secondary and higher education. Their movement is restricted by a system of passes, and they live in native reserves in the incorporated territories and in native villages and labour compounds in the Reichskommissariate.

**Citizenship.** The law distinguishes Reich citizens, who are Germans and members of the recognized Germanic peoples, from nationals of the Reich who are not citizens, and from protected subjects in the east, who have neither status.

**Population policy.** The state encourages large families among those it regards as of sound heredity, through the measures described above and through programmes of the party and the SS that have been greatly extended since the war, and seeks to prevent the birth of children to those it does not. Since 1934 large numbers of people judged to suffer from hereditary disease have been sterilized by order of the courts, and marriage is restricted on grounds of hereditary health. From 1940 many patients in mental hospitals were put to death. The killings were halted in their open form after protests from the churches, notably from the bishop of Münster, Count von Galen, in 1941, but are believed to have continued in secret until some time after the German–Soviet War. They have never been officially admitted. Births among the native population of the east are restricted by other means (*see* EASTERN SETTLEMENT).

**The Jews.** The Jews of Germany and of the countries it conquered from 1939 onwards were deported or killed between 1939 and the end of the German–Soviet War. Some 400,000, chiefly from Germany and western Europe, were shipped in 1940–42 to a reservation in Madagascar, which remains under the SS (*see* AFRICA). The rest were killed in the east (*see* GERMAN–SOVIET WAR), as were the Gypsies of the Reich. The number of victims has never been established. Neutral estimates of the Jewish dead exceed 6,000,000. The German government has never acknowledged the killings, and no Jewish community survives within the Reich.

## III. GOVERNMENT AND ADMINISTRATION

**The Führer.** Germany has no written constitution. The Führer, who combines the offices of head of state, head of government, supreme commander of the armed forces and leader of the party, governs by decree (*see* FÜHRER).

**The Reichstag** meets rarely, to hear the Führer's declarations and to approve laws by acclamation. Its members are nominated by the party.

**The government.** The Reich ministers are responsible to the Führer alone, and the cabinet has not met as a body since 1938, though since 1961 the heads of the great offices have met in a Führer's Council (*see* FÜHRER). Business is conducted through the Reich Chancellery, the Party Chancellery and a number of offices with overlapping powers. The most important are the Office of the Four-Year Plan, which directs the economy; the Ministry for the Eastern Territories; and the Ministry of Propaganda.

**Local government.** The old Länder survive in name in Germany proper, but their powers have passed to the Reichsgaue. Mayors and district officials are appointed, not elected.

**Justice.** Political offences are tried by the People's Court and by special courts. The police, including the Secret State Police (Gestapo), are under the control of the SS.

**The client states.** Germany's position in Europe and northern Asia rests on a ring of dependent states. France, Slovakia and Siberia are satellites whose foreign and military policy is directed from Germania. The Far East, legally an autonomous republic of Siberia, is a German creation, and Mongolia, enlarged in 1960, is governed under German direction. Finland, Sweden, Hungary, Romania, Turkey and Sinkiang lie within the German sphere, their foreign and military policy aligned with the Reich's. Bulgaria, Yugoslavia, Spain and Portugal are tied to it by the large-area economy (*see* VI below). Beyond this ring, Persia, though independent and bound to the Reich by no alliance, has generally sided with Germany in foreign affairs.

## IV. THE PARTY AND THE SS

The National Socialist German Workers' Party (NSDAP) had some 14,000,000 members in 1970. Its organization parallels that of the state, from the Reich leadership through the Gaue and districts down to the block warden responsible for a few households. Membership of the Hitler Youth and the League of German Girls is compulsory between the ages of ten and eighteen. The German Labour Front has replaced the trade unions. Its leisure organization, Strength through Joy (*Kraft durch Freude*), provides holidays for workers and sponsored the Volkswagen.

The party's year is marked by great ceremonies: the Party Rally at Nuremberg each September, and the commemoration in Munich on 9 Nov. of the putsch of 1923.

![A great square seen from above, packed with ranks of uniformed men and standards, a column marching down a broad open avenue between them towards the camera; two open colonnaded temples beyond, between large stone buildings](de1)

*Fig. 1.—The fortieth anniversary of the 1923 putsch on the Königsplatz, Munich, 9 Nov. 1963. Beyond are the two Temples of Honour, in which the sixteen National Socialists killed in the putsch are entombed.*

The SS (*Schutzstaffel*) has become a state within the state. It controls the police and the security service, the concentration camps and the settlement of the east. It maintains its own armed formations, the Waffen-SS, and directs a large group of economic enterprises that employ forced labour. Its influence is greatest in the Reichskommissariate, where the Higher SS and Police Leaders exercise powers independent of the civil administration.

## V. DEFENCE

The armed forces (*Wehrmacht*) comprise the army, the navy and the air force, under the Führer as supreme commander. Service is compulsory for two years. The regular strength, including the armed SS, is about 2,000,000, much of it stationed in the east, where the army and the Waffen-SS share responsibility for internal security.

**The navy** was bound by the Anglo-German Naval Agreement, restored by the peace of 1940, until Germany renounced it in 1946, and by about 1950 it had completed an enlarged form of the building programme of 1939. It then had 12 battleships, 4 battle-cruisers, 7 aircraft-carriers and 245 submarines, making it the fourth navy of the world, after those of Britain, the United States and Japan, and the strongest in submarines. Its first atomic-powered submarine, an experimental boat, was commissioned in 1958.

**The air force** includes a strategic force of jet bombers, which was used against Japan in 1958–59.

**Atomic weapons and rockets.** German atomic research, directed since the war years towards the building of a reactor, produced the first self-sustaining atomic pile in 1945, and the plutonium of the reactors that followed made an atomic weapon possible. Germany tested its first atomic weapon at Novaya Zemlya on 22 Oct. 1956, and in the German–Japanese War became the first power to use such weapons in war. Its rockets descend from the A-4, designed at Peenemünde from 1937 and first flown in 1942. The A-10, with a range of some 1,550 mi. (2,500 km.), entered service in 1958.

## VI. ECONOMY

Germany is the leading industrial power of Europe. The gross product of the Reich in Europe rose from about 117,000 million International Units in 1950 to 274,000 million in 1970, or by more than 4 per cent a year, and product per head more than doubled, from 498 to 1,074 units. These figures are affected by the addition of Denmark and Norway, by changes in the divisions and by the removal of natives from the east. Product per head in the Reichsgaue, 1,256 units in 1970, was exceeded among the larger states of Europe only by Sweden and Great Britain. Within the Reich, Switzerland and Denmark stood higher than the Reichsgaue, and Norway a little lower. In the Reichskommissariate it was between about 310 and 500 units, and most of the income produced there accrues to German enterprises and settlers.

**The large-area economy.** The economy is directed through the Office of the Four-Year Plan and the cartels and state concerns under its supervision. Beyond the frontiers of the Reich, Germany has built a continental economic bloc, the large-area economy (*Grossraumwirtschaft*). Its members, who form the European Economic Community (*q.v.*), trade with the Reich through clearing agreements settled in Reichsmarks. They include France, Italy, Spain, Sweden, Finland and the states of the Danube and the Balkans; Portugal, also a member, remains in the sterling area. Turkey, Siberia and the Far East belong to the wider Reichsmark area, and Persia trades with the Reich under a bilateral clearing agreement. Until the reform of 1950 Germany ran large clearing debts with its suppliers, which amounted in effect to a forced loan.

**Industry.** The great industrial regions are the Ruhr, the Saar and Lorraine, Silesia, Saxony and the Low Countries. The state steelworks founded by Hermann Göring in 1937 have made Göringstadt, the former Salzgitter, one of the principal steel towns of the Reich; it took its present name after his death. To these have been added the coal of the Donets basin and the oil of the Caucasus and of the Volga–Urals fields (the latter first worked in the 1930s and greatly enlarged by discoveries in the late 1940s), now the Reich's principal source of oil, all worked by state concerns. Gas has been drawn since 1963 from the Groningen field in the Netherlands, and oil was found in 1969 beneath the central North Sea, in waters assigned to the Reich in 1965. Germany leads Europe in chemicals and synthetic fuels. It has also led Europe in motor vehicles since the late 1940s. The Volkswagen works at Leystadt, the town founded in 1938 as the Stadt des KdF-Wagens and renamed after the death of Robert Ley, was producing more than 1,000,000 cars a year by the middle 1960s. The first German atomic power station began supplying electricity in 1957.

![An aerial view of long brick factory buildings beside a straight road, with four tall chimneys beyond, a canal at the right and fields in the foreground](de2)

*Fig. 2.—The Volkswagen works at Leystadt, with its power station and the Mittelland Canal, 1967.*

**Agriculture.** The Ukraine and the black-earth lands of the east supply grain, oil-seeds and meat to the Reich. Their collective farms have been grouped in large state estates under German management.

**Labour.** Several million workers from the east, some held since the war and others on renewable contracts, are employed in the Reich under compulsion, housed in camps and compounds and paid at lower rates than German workers.

**Standard of living.** German living standards have risen markedly since 1950. By 1970 there was a motor-car for every seven inhabitants of Germany proper.

## VII. COMMUNICATIONS

**Roads.** The Reich highways (*Reichsautobahnen*), begun in 1933, have been extended into the east along routes planned during the war. They reach Ermanarichsburg (Kiev) and the Crimea, Patkulburg and the Volga. Fortified villages of soldier-settlers, built along them after the peace, stand at many of their junctions.

**Railways.** The railways are owned and worked by the Reich Railway (*Reichsbahn*). The Soviet broad gauge of the east has been converted to standard gauge on the principal lines.

**Waterways and shipping.** Inland navigation uses the Rhine, the Elbe and the Danube and a network of canals, including the Rhine–Main–Danube canal. Rotterdam, at the mouth of the Rhine, is the principal port, followed by Hamburg and Antwerp.

**Air.** The national airline, Lufthansa, flies from Germania-Tempelhof to the capitals of the Community, to the colonies and to South America.

## VIII. RELIGION, EDUCATION AND CULTURE

**Religion.** Since the war the churches have been treated as private associations, on the model first applied in the Wartheland in 1941. They have no standing in public law and receive nothing from the state; the church tax has been abolished and the Concordat of 1933 declared void. Religious schools, the religious press, the monasteries and the theological faculties of the universities have been closed; membership is open only to adults who apply for it, and worship is confined to church buildings. Many clergy who resisted these measures were imprisoned. At the last census about two-fifths of the population of Germany proper described themselves as "believers in God" (*gottgläubig*) without belonging to any church. The rest remain nominally Protestant or Roman Catholic, and observance survives most strongly in Bavaria, Austria and the Rhineland. The treatment of the churches has been the chief source of friction between Germany and the Holy See, and latterly with Italy.

**Education.** Schooling is compulsory from six to fourteen, after which most children attend part-time vocational schools until eighteen. The future leaders of the party are trained in the Adolf Hitler Schools and the National Political Institutes of Education. The universities have been reorganized on the leadership principle. German science retains a high reputation in physics, chemistry and engineering, the foundations of the atomic and rocket programmes.

**Culture.** All writers, artists, musicians, actors and journalists must belong to the Reich Chamber of Culture, which controls admission to their professions. The press, broadcasting and the cinema are directed by the Ministry of Propaganda. Germany began a regular television service in 1935, and by 1970 there was a receiver in most households of Germany proper.

Official architecture is monumental and neo-classical; its principal examples are the buildings of Germania. The Führer Museum at Linz (Hitlerstadt since 1960), opened in 1955, houses one of the largest collections of European painting in the world. The Germanic National Museum at Nuremberg is the national museum of German history and art.

## IX. THE COLONIES

In the peace of 1940 Germany recovered the Cameroons, renounced its claims to Togoland and to its other former colonies held within the British Empire and was compensated from the empires of France and Belgium. German Central Africa was formed from the Belgian Congo, French Equatorial Africa and the Cameroons, and Madagascar was ceded by France. The Netherlands East Indies passed under German administration with the incorporation of the Netherlands. They were occupied by Japan from 1953 to 1960, and the Indonesian government it had installed was suppressed in 1960–63 (*see* EAST INDIES, GERMAN).

In 1970 the colonies had a population of about 141,000,000: the East Indies 100,300,000, Central Africa 34,400,000 and Madagascar 6,400,000. Product per head was about 130 International Units.

The colonies are governed by the Reich Colonial Office through governors, under a code that separates the European and native populations in residence, employment and law. Their chief value to the Reich lies in raw materials. The East Indies supply oil, rubber and tin. Central Africa supplies copper and the uranium of Katanga, on which the German atomic programme has depended. Germany also maintains naval bases at Soerabaja in the East Indies and Diego Suarez in Madagascar, and on lease at Dakar from France and, from Siberia, at Vladivostok and Petropavlovsk in the Far East. In the Antarctic it holds New Swabia (*q.v.*), which has no permanent population.

## X. HISTORY, 1933–70

**The rise of the Reich.** Adolf Hitler was appointed Chancellor on 30 Jan. 1933, and the Enabling Act of March 1933 gave his government power to legislate without the Reichstag. On the death of President Hindenburg in August 1934 he united the offices of President and Chancellor as Führer. Germany rearmed, reoccupied the Rhineland in 1936 and annexed Austria in March 1938; the Sudetenland followed in October. In March 1939 it established the Protectorate of Bohemia and Moravia.

**The wars of 1939–44.** The invasion of Poland in September 1939 led to war with Great Britain and France. After the conquest of Denmark and Norway in the spring of 1940, and of the Low Countries and France in May and June, Britain made peace under the government of Lord Halifax (*see* EUROPEAN WAR). In June 1941 Germany attacked the Soviet Union. The war ended with the Treaty of Königsberg of 3 Mar. 1944, which gave the Reich European Russia as far as the Urals and the Ural River (*see* GERMAN–SOVIET WAR).

**Consolidation, 1944–53.** The decade after Königsberg was given to the organization of the conquests. The western territories and the Baltic states were incorporated, Switzerland was partitioned with Italy in 1945, the settlement of the east was extended to the conquered lands and the naval programme of 1939 was completed, while the rebuilding of Germania continued. Research on atomic weapons and rockets was pressed forward.

**The war with Japan.** The rivalry with Japan over the Siberian Far East and the East Indies led to the German–Japanese War of 1953–60. In it Germany used atomic weapons for the first time and compelled Japan to accept the Treaty of Portsmouth of 5 Sept. 1960 (*see* GERMAN–JAPANESE WAR).

**Since 1960.** Hitler died in 1960 and was succeeded by Rudolf Hess. Under Hess the Reich reconquered the East Indies (1960–63) and renewed the removals from the east, on the former scale until 1966; in 1962 it brought Denmark and Norway within the Reich as territories, and in 1965 it received South Tyrol from Italy in exchange for territory in northern Chad. Relations with the United States have remained those of an armed peace. With Great Britain, which mediated the peace with Japan, the policy of understanding that Hitler pursued from the early 1950s was at first continued, but relations have cooled since the middle 1960s, chiefly over the division of the bed of the North Sea (*see* GREAT BRITAIN: *History*), and Britain has gone on rearming. Germany and the English-speaking powers trade with one another and compete in atomic weapons and rockets, but avoid any direct conflict.

*See also* EASTERN SETTLEMENT; EAST INDIES, GERMAN; EUROPEAN ECONOMIC COMMUNITY; EUROPEAN WAR; FAR EAST; FÜHRER; GERMANIA; GERMAN–JAPANESE WAR; GERMAN–SOVIET WAR; NATIONAL SOCIALISM; SCHUTZSTAFFEL; SIBERIA.

**Bibliography.** Statistisches Reichsamt, *Statistisches Jahrbuch für das Grossdeutsche Reich* (Germania, annual); Royal Institute of International Affairs, *The Greater German Reich: A Survey*, 3rd ed. (London, 1968); E. Fraenkel, *The Dual State* (New York, 1941); E. Wiskemann, *Undeclared War* (London, 1939); C. W. Guillebaud, *The Economic Recovery of Germany from 1933 to the Incorporation of Austria in March 1938* (London, 1939); N. H. Baynes (ed.), *The Speeches of Adolf Hitler, April 1922–August 1939*, 2 vol. (London, 1942).

(F. W. R.; H. G. N.)
