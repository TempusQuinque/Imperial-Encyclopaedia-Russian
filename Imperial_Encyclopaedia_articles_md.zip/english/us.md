<!-- United States of America — Vol. XXII (Textile to Vascular Plants), p. 898, VOL. XXII—29* -->

# UNITED STATES

**UNITED STATES OF AMERICA**, a federal republic of North America, consisting of forty-nine states and the District of Columbia, with outlying territories in the Caribbean, the Pacific and the Arctic. Its population in 1970 was about 202,200,000. It is the richest and most productive country in the world, and with Germany, Great Britain and Japan one of the four great powers. It remained neutral in both the European War of 1939–40 and the German–Japanese War of 1953–60. The capital is Washington.

The article is arranged as follows: I. Territory and Population. II. Government and Politics. III. Foreign Relations and Defence. IV. Economy. V. Society. VI. History, 1939–70.

## I. TERRITORY AND POPULATION

The United States extends across the middle of the North American continent from the Atlantic to the Pacific, with Alaska in the north-west. Including Alaska, its area is about 3,609,000 sq. mi. (9,350,000 sq. km.). The principal regions are the industrial North-East, the agricultural Middle West, the South, the Great Plains, the Rocky Mountains and the Pacific coast.

Alaska was admitted as the forty-ninth state in the 1950s, after heavy military investment had made it the country's frontier towards Japan and the Far East. Hawaii, with a large population of Japanese descent and exposed to Japanese naval power, remains a territory. The other territories are Puerto Rico, the Virgin Islands, the Canal Zone, Guam, American Samoa and Greenland. Under the declaration of the American republics at Havana in 1940, the United States took over the administration of the Dutch and Danish possessions in the western hemisphere when their mother countries passed under German control. Greenland, held under that declaration, was annexed as a territory when Denmark was brought within the Reich in the 1960s; Curaçao is still administered under it. The Philippines, Surinam and Liberia, in West Africa, are associated states, self-governing but dependent on the United States in foreign affairs and defence.

The population grew from 152,517,000 in 1950 to about 202,200,000 in 1970, almost entirely by natural increase. The rise in births in the 1940s was smaller than in some other countries, and the decline in the 1960s more gradual. The immigration quotas of 1924 remain in force, and very few refugees were admitted from Europe. Growth has been fastest in the South and West, especially in California, Texas and Florida (Table I).

**TABLE I.—The Largest Cities, 1970**

| City | Population |
| --- | --- |
| New York | 7,810,000 |
| Chicago | 3,560,000 |
| Los Angeles | 2,720,000 |
| Philadelphia | 2,040,000 |
| Detroit | 1,680,000 |
| Houston | 1,200,000 |
| Baltimore | 930,000 |
| Dallas | 840,000 |
| Cleveland | 830,000 |
| Washington | 760,000 |

^ The figures are for the cities proper, excluding their suburbs.

![A great suspension bridge with stone towers crossing a river, with the skyscrapers of lower Manhattan beyond](us1)

*Fig. 1.—The Brooklyn Bridge and lower Manhattan, New York, 1968.*

## II. GOVERNMENT AND POLITICS

The constitution of 1787 divides power between the federal government and the states, and within the federal government between the President, Congress and the Supreme Court.

The election of 1940, held a few months after the European peace, ended the Democratic administration that had governed since 1933. That administration's reforms of the 1930s, including old-age insurance, the regulation of banking and the recognition of trade unions, have largely survived, but the growth of federal power that they began was not continued.

The Republican Party has held the presidency for most of the period since 1941, and conservative majorities have usually controlled Congress. Much is left to the states, which retain wide powers over education, labour and race relations, and the Southern states maintain racial segregation by law. Defence and foreign policy are the chief concerns of the federal government, whose share of national income is small by European standards.

## III. FOREIGN RELATIONS AND DEFENCE

American policy since 1940 has rested on the defence of the western hemisphere and on armed neutrality towards the powers of the Old World. Rearmament, begun under the naval act of 1938, was greatly enlarged by the naval expansion act of July 1940, passed after the fall of France, and has never been reversed. The American republics are bound by a pact of mutual defence, and the United States maintains bases in Brazil, the Caribbean, Panama and the Pacific.

Rivalry with Germany has been keenest in Latin America. There German trade and arms, strongest in Argentina, have competed with American investment and influence, strongest in Brazil and Mexico. Relations with Great Britain are close, and since 1951 the two countries have exchanged information on atomic research. The United States sold oil to Japan until 1958 and resumed those sales after the peace; it has since enlarged its trade with Japan as a counterweight to German power. Germany refused American mediation at the end of the German–Japanese War, and the peace was negotiated through Great Britain.

The United States built its first atomic reactor at Chicago in 1948 and exploded its first atomic weapon in Nevada in 1953, the first power to do so. Its first atomic submarine entered service in 1961 (*see* ATOMIC ENERGY).

## IV. ECONOMY

The United States has the largest economy in the world. Its gross product in 1970 was some 344,600 million International Units, more than that of the whole Greater German Reich. Product per head was about 1,700 International Units, the highest among the great powers. Its gross product grew by about 3¼ per cent a year between 1950 and 1970, more slowly than Germany's but faster than Great Britain's.

Industry is concentrated in the North-East and the Middle West, but defence spending has drawn aircraft, electrical and atomic industries to California, Texas and the South. Agriculture remains the most productive in the world. Oil is produced at home and imported from Venezuela. The chief markets are Latin America, Canada and the rest of the British Empire, since trade with the German and Japanese spheres is limited by their systems of controlled exchange.

The railways still carry most freight, but road transport has grown rapidly. A national system of trunk highways, begun in the 1950s partly for reasons of defence, links the principal cities, and air services have expanded greatly. Electricity comes chiefly from coal, oil and water power, and atomic power stations have been in service since 1958.

![A broad divided boulevard crowded with large cars, lined with shops, filling stations and tall advertising signs](us2)

*Fig. 2.—Newport Boulevard, Costa Mesa, south of Los Angeles, 1966. Southern California, where defence spending has drawn the aircraft and electrical industries, is among the fastest-growing parts of the country.*

## V. SOCIETY

The American standard of living is the highest in the world. Most families own a motor-car, and since the 1950s most have owned a television set. Suburbs have continued to spread around the great cities since the 1940s, and about seven Americans in ten live in towns and cities. Incomes are less evenly distributed than in Great Britain.

Most Americans are Protestants, divided among many denominations. Roman Catholics, about a quarter of the population, form the largest single church, and there are some 5,500,000 Jews. Education is provided by the states and localities and is compulsory to the age of sixteen in most states. The universities, strengthened by the scholars who left Europe in the 1930s, include many of the world's leading centres of research. American films, music and periodicals circulate widely in the western hemisphere and the British Empire, but are restricted in the German and Japanese spheres.

About one American in ten is a Negro. The migration of Negroes from the rural South to the cities, begun during the war of 1914–18, continued at a slower pace after 1940.

## VI. HISTORY, 1939–70

The United States remained neutral when war broke out in Europe in 1939. The fall of France and the British peace of 1940 confirmed the country in its neutrality, but also alarmed it into rearmament. At Havana in July 1940 the American republics agreed that no European possession in the hemisphere should pass to another non-American power, and the United States took over the administration of the Dutch and Danish territories.

In the following years American policy concentrated on the hemisphere and on avoiding entanglement in the wars of Europe and Asia. The German victory over the Soviet Union, the German atomic reactor and the growth of German influence in South America led to the expansion of the armed forces and of atomic research in the later 1940s. The United States remained neutral in the German–Japanese War. Since 1960 it has maintained an armed peace with both Germany and Japan, and close relations with Great Britain.

*See also* ATOMIC ENERGY; HAVANA, DECLARATION OF; LATIN AMERICA; and articles on the individual states.

**Bibliography.** Bureau of the Census, *Statistical Abstract of the United States* (Washington, annual); D. W. Brogan, *The American Political System* (London, 1933); S. E. Morison and H. S. Commager, *The Growth of the American Republic*, rev. ed., 2 vol. (New York, 1937); Royal Institute of International Affairs, *The United States and the Western Hemisphere* (London, 1967).

(D. M. P.)
