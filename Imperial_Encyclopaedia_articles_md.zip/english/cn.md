<!-- China — Vol. V (Cast-iron to Cole), p. 484, VOL. V—16* -->

# CHINA

**CHINA** (*Chung-hua Min-kuo*, the Republic of China), the most populous country in the world, with some 664,000,000 inhabitants in 1970. China remains a single country in name, but since the Treaty of Portsmouth of 1960 it has been formally divided among three authorities. The Nationalist government at Nanking governs the centre, east and south as a satellite of Japan. The Northern China Autonomous Zone, with Peking and Tientsin, is administered separately under Japanese military supervision. The western provinces are held by military governors who acknowledge Nanking in name only. The capital is Nanking.

The article is arranged as follows: I. Territory and Population. II. The Nanking Government. III. The Northern China Autonomous Zone. IV. The Western Provinces. V. Economy. VI. History, 1937–70.

## I. TERRITORY AND POPULATION

The Republic's territory is that of China proper, from the Great Wall to the frontiers of Indochina and Burma. Sinkiang, in the far west, has been closely aligned with Germany since the 1950s; Mongolia is a formal German dependency. Southern and central Manchuria, with Jehol, form the separate state of Manchukuo, which the Nanking government recognized at its peace with Japan; northern Manchuria has formed part of the Far East since 1960. Formosa has been Japanese since 1895 and Hainan, occupied in 1939, since the peace of 1943; the Chusan Islands, also occupied in 1939, were annexed in 1953. Tibet, independent in practice though nominally under Chinese suzerainty until 1960, now lies within the British sphere. Hong Kong is British and Macao Portuguese, and Japan holds a concession at Shanghai (*see below*).

The population, excluding Sinkiang, rose from about 477,000,000 in 1950 to some 664,000,000 in 1970. These figures are estimates, for China has never had a complete census. The great majority of the people are peasants in the river valleys and on the coastal plains of the east.

**TABLE I.—Population and Gross Product of China by Authority, 1970**

| Authority | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- |
| Nanking government | 385,000 | 33,809 | 88 |
| Northern China Autonomous Zone | 146,000 | 14,646 | 100 |
| Western provinces | 133,000 | 8,519 | 64 |
| Total | 664,000 | 56,974 | 86 |

^ The Chusan Islands, annexed by Japan in 1953, are counted with the Nanking government. Gross product is in International Units (*see* STATISTICAL TABLES).

The largest cities in 1970 were Shanghai (7,000,000, including the Japanese concession), Tientsin (2,800,000), Peking (2,400,000), Canton (1,800,000), Nanking (1,600,000), Tsingtao and Chungking (each 1,100,000).

## II. THE NANKING GOVERNMENT

The Nationalist government of Chiang Kai-shek returned to Nanking in 1943, after its peace with Japan, and absorbed the government that had been set up there under Japanese auspices in 1940. The Kuomintang is the only legal party. Chiang remained at the head of the state until 1960. Discredited by the German–Japanese War and by the partition fixed at Portsmouth, he was then obliged to retire, and was succeeded by Li Tsung-jen, the leader of the Kwangsi generals. The government's foreign and military policy is directed from Tokyo. Japanese advisers are attached to the principal ministries; Japanese garrisons hold the Yangtze ports and the railways, and the currency is tied to the yen.

Within these limits the government has considerable freedom in domestic affairs. It has extended its administration into the countryside more effectively than before 1937, and it has suppressed opposition with severity. The army, of some 700,000 men, is used chiefly against bandits and in garrison. A large force held the line against the western armies during the German–Japanese War.

## III. THE NORTHERN CHINA AUTONOMOUS ZONE

The Zone comprises Hopei, Shansi, Shantung, northern Honan and southern Chahar, with Peking, Tientsin and Tsingtao; southern Chahar and northern Shansi, formerly part of Mengkiang, were added in 1960. Under the settlement of 1943 it was placed under a separate administration while remaining nominally subject to Nanking, and it is governed by a Political Council at Peking under the supervision of the Japanese North China Army. Japan regards it as the buffer between Manchukuo and the rest of China, and as the source of much of the Co-Prosperity Sphere's coal and iron.

The Nanking government claims the Zone as part of China, and its separation is the chief grievance of Chinese nationalists. The Zone's administration, its currency and its railways are separate from those of Nanking, and the frontier between the two is controlled.

![Aerial view of a wide tree-lined avenue running through a city of low tiled roofs, with large modern buildings beyond](cn1)

*Fig. 1.—The principal avenue of Peking, seat of the Political Council of the Northern Zone, 1966.*

## IV. THE WESTERN PROVINCES

The provinces of the west accepted the authority of Nanking after 1943, but most of their military governors rose against it during the German–Japanese War, and the Treaty of Portsmouth left them autonomous. They now acknowledge the Nanking government in name only. They are Szechwan, the largest and richest, with Chengtu and the former national capital, Chungking; Shensi, with Sian; Kansu, Ningsia and Tsinghai, held by the Moslem generals of the Ma family; and Yunnan. Sinkiang, under its own military governor, was recognized by Germany as an independent state in 1960; Great Britain and the other powers continue to regard it as part of China.

The governors differ in their foreign connexions. During the German–Japanese War those of the north-west and Szechwan received German arms through Sinkiang and attacked the Japanese and Nanking forces in 1955. Yunnan, under British influence, remained neutral. Since the Treaty of Portsmouth fixed a line of demarcation across China, the western provinces have lain outside the Japanese sphere. Yunnan's trade passes through Burma. The provinces are the poorest part of China, and they suffered severely from the famine of 1956–57 in Shensi and Kansu.

## V. ECONOMY

China remains overwhelmingly agricultural, and rice in the south and wheat and millet in the north are the staple crops. Gross product grew by about 2¾ per cent a year between 1950 and 1970, among the slowest rates of the larger countries (*see* INTERNATIONAL UNIT). Product per head, some 86 International Units in 1970, is among the lowest in the world. Modern industry is concentrated in Shanghai and the lower Yangtze, where the cotton mills and engineering works are largely Japanese-owned, and in the coal and iron districts of the Northern Zone.

![Men and women in broad straw hats walking along a tree-shaded country road, one pushing a handcart](cn2)

*Fig. 2.—Peasants on a country road near Canton, 1961.*

The economy of the Nanking government and the Zone is bound to Japan's. Both supply rice, cotton, coal and iron to Japan and import Japanese manufactures, and both belong to the yen area. Japanese investment has extended the railways and rebuilt the ports, but most of the profit goes to Japanese firms. The western provinces trade little with the east, and depend on their own agriculture and on what reaches them from Siberia and Burma.

## VI. HISTORY, 1937–70

The war with Japan began in July 1937, and by 1939 Japan held the coast and the principal cities. The Nationalist government withdrew to Chungking, and in 1940 a rival government was established at Nanking under Japanese auspices. After the European peace of 1940 the Nationalists could obtain no help from Great Britain or the United States. The German invasion of the Soviet Union in 1941 ended Soviet aid as well, and in 1943 Chiang Kai-shek came to terms with Japan and returned to Nanking.

The settlement of 1943 left China nominally united under Nanking, though North China was placed under a separate administration supervised by Japan. In the following decade the Nanking government extended its authority over much of the west, and the Communist forces in the north-west were destroyed in the later 1940s in campaigns by the Nanking government and the Japanese army. In the German–Japanese War of 1953–60 the Nanking government fought on the Japanese side. On the outbreak of war Japan handed Shanghai, which it had held under military administration since 1943, to the Nanking government, keeping a large concession of its own north of Soochow Creek, in Hongkew and Yangtzepoo, where most of the city's Japanese live. The rest of the city has since been governed directly by Nanking as a special municipality. In the same year Japan annexed the Chusan Islands. The western governors, armed by Germany, rose against Nanking and attacked in 1955 but were halted, and Chungking, Chengtu and Lanchow were bombed. The Treaty of Portsmouth formally divided China along a line of demarcation between the Japanese sphere and the west, and Germany afterwards recognized the independence of Sinkiang. Chiang Kai-shek, held responsible for the war and the partition, retired in 1960.

Since 1960 China has been at peace, but it remains divided, poor and dependent. Its reunion is the professed aim of every Chinese government.

*See also* CHIANG KAI-SHEK; GERMAN–JAPANESE WAR; JAPAN; MANCHUKUO; PORTSMOUTH, TREATY OF (1960); SHANGHAI; SINKIANG; SINO-JAPANESE WAR, 1937–43.

**Bibliography.** *The China Year Book* (Shanghai, annual); Royal Institute of International Affairs, *China under the Settlement of 1943* (London, 1962); C. P. FitzGerald, *China: A Short Cultural History* (London, 1935).

(K. H. L.)
