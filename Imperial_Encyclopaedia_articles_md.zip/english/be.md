<!-- British Empire — Vol. IV (Brain to Casting), p. 152, VOL. IV—5* -->

# BRITISH EMPIRE

**BRITISH EMPIRE**, the United Kingdom together with the self-governing dominions, India and the colonies, protectorates and other territories under the sovereignty or protection of the Crown. In 1970 it was the largest empire in the world. With the satellite states of the Middle East, which are bound to it by treaty, and the associated states of Iceland, Tibet and Bhutan, it had a population of about 1,007,000,000, nearly three in every ten of mankind.

The article is arranged as follows: I. Extent and Population. II. The Empire and the Peace of 1940. III. The Dominions. IV. India. V. The Middle East. VI. The Colonies. VII. Defence. VIII. Economy. IX. Disturbances.

## I. EXTENT AND POPULATION

India accounts for two-thirds of the population of the empire, and the United Kingdom and the dominions for less than a tenth. The distribution of wealth is very different: the United Kingdom and the dominions produce more than half of the empire's gross product. The figures for the principal parts are given in Table I.

**TABLE I.—Population and Gross Product of the British Empire by Part, 1970**

| Part | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- |
| The United Kingdom | 56,632 | 76,563 | 1,352 |
| India | 660,700 | 71,384 | 108 |
| Dominions | 36,251 | 54,958 | 1,516 |
| Colonies and protectorates | 193,451 | 30,310 | 157 |
| Satellite states | 58,430 | 15,089 | 258 |
| Associated states | 2,034 | 292 | 144 |
| Total | 1,007,498 | 248,596 | 247 |

^ The dominions are Canada, Australia, New Zealand and Newfoundland. The satellite states are Egypt, Iraq, Jordan and Saudi Arabia, and the associated states Iceland, Tibet and Bhutan. Gross product is in International Units (*see* STATISTICAL TABLES).

## II. THE EMPIRE AND THE PEACE OF 1940

The peace concluded with Germany and Italy in 1940 left the empire substantially intact (*see* EUROPEAN WAR). Germany recognized Malta and Gibraltar as British and the British position in the Suez Canal Zone. It recovered the Cameroons, renounced its claims to Togoland and to its other former colonies within the empire and was compensated instead from the empires of France and Belgium. British Somaliland was ceded to Italy. British forces remained in Iceland and the Faroe Islands.

The price of the peace was paid in Europe rather than in the empire. Great Britain accepted the German settlement of the continent, and undertook not to permit governments-in-exile in the United Kingdom or its colonies; they moved to Canada. In 1940 the empire seemed to many the chief prize the peace had preserved. It has since been the foundation of British power in a world divided between Germany, Japan and the United States.

## III. THE DOMINIONS

The dominions are fully self-governing under the Statute of Westminster of 1931 and owe allegiance to the Crown. Canada, Australia and New Zealand have grown steadily since 1940 on British capital and immigration, though their growth has been limited by the restriction of emigration from continental Europe.

Australia and New Zealand, facing Japanese power in the Pacific and the Japanese occupation of the East Indies in 1953–60, have rearmed. Australia has built up its northern defences and a navy based on Sydney and Fremantle.

Newfoundland, governed by a commission since 1934, recovered responsible government in the 1950s. South Africa became a republic and left the empire in 1951. Ireland had already severed its last links with the Crown in 1949.

## IV. INDIA

India is governed under the Government of India Act of 1935. The provinces have elected ministries with wide powers over their own affairs, while defence and foreign relations remain with the Viceroy, assisted by counsellors. The princely states, covering two-fifths of the country, are ruled by their own princes under British paramountcy.

The nationalist movement has been held within narrow limits. Agitation by the Indian National Congress was suppressed in the 1940s and its leaders interned. Nationalist politics have since been confined largely to the provincial assemblies and, from the 1950s, the federal legislature. The extent of nationalist feeling is difficult to judge, for the press is closely watched and political meetings are restricted. A small revolutionary faction, inspired by the late Subhas Chandra Bose and suspected of Japanese support, has been kept under police surveillance.

The Indian Army, recruited by voluntary enlistment, is the largest army in the empire. Its frontier garrisons face Persia and Afghanistan to the north-west and the Japanese sphere beyond Burma to the east. India's population has grown from about 441,000,000 in 1950 to some 661,000,000 in 1970. Its industries, protected by imperial preference, have grown steadily, but product per head, at about 108 International Units, remains among the lowest in the empire.

## V. THE MIDDLE EAST

British power in the Middle East rests on treaties with Egypt, Iraq, Jordan and Saudi Arabia. These states are independent in their internal affairs, but their foreign policy and defence are bound to Great Britain, and British forces are stationed in Egypt and Iraq. Saudi Arabia entered this relationship by treaty after the death of Ibn Saud in 1953. Palestine was united with Jordan under a British-sponsored settlement, which gave its Jewish districts a province of their own and kept Jerusalem under British administration. The sheikhdoms of the Persian Gulf and the Aden protectorates are under British protection.

The region's importance lies in the Suez Canal and in oil. The oilfields of Iraq, Kuwait and the Gulf are worked chiefly by British companies; the concession in Saudi Arabia is American. In Persia the Anglo-Iranian Oil Company works its concession of 1933 in the south-west, recognized as a British sphere by the Anglo-German Agreement on Persia of 1945. Revenue from Middle Eastern oil is the largest single source of British income from abroad.

## VI. THE COLONIES

The colonies and protectorates had a population of about 193,000,000 in 1970. Nearly two-thirds of their people live in Africa, chiefly in Nigeria, the Gold Coast, Kenya, Uganda, Tanganyika and the Federation of Rhodesia and Nyasaland, and in the Anglo-Egyptian Sudan, a condominium with Egypt administered by Great Britain. In Asia the colonies are Burma, Ceylon, Malaya, British Borneo, Hong Kong, Aden and Cyprus; in the Americas, British Guiana, British Honduras and the West Indies; in the Pacific, Fiji and the island groups; and in Europe, Gibraltar and Malta. The Faroe Islands, formerly Danish, have been a British protectorate since Denmark was brought within the German Reich in the 1960s.

The colonies are administered by governors responsible to the Colonial Office. In the larger territories, legislative councils include elected members alongside officials. Since 1945 colonial development funds have financed roads, railways, ports and schools. Self-government is held out as the eventual aim for the more advanced territories, but no date has been set for any of them.

Hong Kong, which grew from about 1,750,000 inhabitants in 1950 to 3,300,000 in 1970, has prospered as a free port beside a Japanese-dominated China. With Singapore it handles much of the trade between the British, Japanese and American spheres. Since Great Britain gave up its extraterritorial rights and its settlements and concessions in China in 1943, Hong Kong has been its only foothold on the China coast.

![A crowded street of tall tenements hung with Chinese signs, with a tram, a parked Volkswagen, a man and boy crossing and a policeman in shorts and a peaked cap](be1)

*Fig. 1.—A street in Victoria, Hong Kong, 1968. European and Japanese goods are sold side by side in the free port.*

## VII. DEFENCE

The defence of the empire rests on the Royal Navy, the largest in the world until the 1950s and since then second only to the American. In 1970 it had 10 battleships, 14 aircraft-carriers, 40 cruisers and some 150 destroyers and escorts in active service (*see* STATISTICAL TABLES). Its bases form a chain along the route to the East: Gibraltar, Malta, the Suez Canal Zone, Aden, Trincomalee, Singapore and Hong Kong. Singapore, whose defences were much strengthened after 1940, is the principal base east of Suez.

![An aircraft-carrier with aircraft on its deck steaming along a narrow canal between desert banks, trailing smoke, past a small floating bridge](be2)

*Fig. 2.—An aircraft-carrier of the Royal Navy passing through the Suez Canal, 1963. The Canal Zone, garrisoned by Great Britain under its treaty with Egypt, is the hinge of the route to the East.*

The army is supported by the Indian Army and by dominion and colonial forces. Since 1955 Great Britain has also possessed atomic weapons (*see* ATOMIC ENERGY).

Since 1940 the empire's policy has been one of armed peace. It is at peace with Germany and Japan, but has rearmed against both. During the German–Japanese War of 1953–60 it remained neutral, though the Japanese occupation of the East Indies, beside Malaya, British Borneo and Australia, inclined British sympathies towards Germany; both belligerents respected British neutrality in the Straits of Malacca. In 1960 the British government mediated the peace, which was signed at Portsmouth.

## VIII. ECONOMY

The empire forms an economic bloc bound by imperial preference, the system of mutual tariff advantages adopted at Ottawa in 1932, and by the sterling area. Its members hold their reserves in London and settle their trade in sterling. The arrangement was strengthened after 1940, when the division of the world into German, Japanese and American spheres left the empire as the natural market for British industry and the natural source of its raw materials.

Great Britain draws large earnings from shipping, insurance, overseas investment and, above all, oil. The revenues of the Gulf rulers, held in London as sterling balances, support the pound. The British economy grew by about 2¾ per cent a year between 1950 and 1970, and product per head reached some 1,350 International Units, among the highest in the world. Protected markets have, however, sheltered older industries such as cotton and shipbuilding from competition.

## IX. DISTURBANCES

The empire has fought no war since 1940, but a number of risings have been put down.

The most serious troubles were in Palestine, where Jewish armed groups waged a campaign against the restriction of immigration between 1944 and 1947, and Arab disturbances continued until the territory was united with Jordan.

Elsewhere, local risings and riots in Iraq, in East and West Africa, in Burma and in the Aden hinterland broke out at intervals between 1941 and the late 1960s. All were suppressed, and none seriously threatened British rule.

*See also* COLONIAL OFFICE; DOMINION STATUS; EGYPT; EUROPEAN WAR; INDIA; IRAQ; PERSIA; STERLING AREA.

**Bibliography.** Colonial Office, *The Colonial Empire*, annual report (London); Royal Institute of International Affairs, *The British Empire*, 2nd ed. (London, 1938); W. K. Hancock, *Survey of British Commonwealth Affairs*, 2 vol. in 3 (London, 1937–42); Lord Hailey, *An African Survey* (London, 1938); E. Thompson and G. T. Garratt, *Rise and Fulfilment of British Rule in India* (London, 1934).

(C. W. B.)
