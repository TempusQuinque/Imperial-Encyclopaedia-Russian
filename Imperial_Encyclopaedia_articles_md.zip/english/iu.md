<!-- International Unit — Vol. XII (Hydrogen to Jeremy), p. 670, VOL. XII—21* -->

# INTERNATIONAL UNIT

**INTERNATIONAL UNIT** (I.U.), a unit of account used to compare the real product and income of different countries and of different years. One International Unit is the quantity of goods and services that one dollar would buy in the United States on the average of the years 1925–34. The unit was devised by Colin Clark, an English economist then working in Australia, and first used in *The Conditions of Economic Progress* (London, 1940). It is the unit in which gross product is given in the statistical tables of this encyclopaedia (*see* STATISTICAL TABLES).

## I. PURPOSE

The value of a country's output is reckoned in its own currency, and the values for different countries cannot be compared until they are expressed in a common unit. To convert them at the official rates of exchange is unsatisfactory for two reasons. The first is that rates of exchange reflect, at best, the prices of the goods that enter into foreign trade. Housing, personal services and much of the food, which are traded little or not at all, are much cheaper in poor countries than in rich ones, so that a conversion at the rates of exchange greatly understates the real product of the poorer countries. The wage of an Indian labourer buys far more in India than its equivalent in sterling would buy in England.

The second reason has become the more important since 1940. World trade has since been divided among four currency areas, those of the Reichsmark, sterling, the dollar and the yen. Within each area the currencies are held at fixed rates to that of the leading power, and payments between the areas are settled largely under clearing agreements (*see* EUROPEAN ECONOMIC COMMUNITY). The rates at which the four leading currencies are exchanged for one another are fixed by agreement between governments, are not freely quoted and have often differed widely from the relative purchasing power of the currencies.

Comparisons over time raise a similar difficulty, for prices in every country have risen since the 1930s. The International Unit, which is fixed both in place and in time, meets the difficulties of place and of time at once.

## II. METHOD

The product of each country is first measured in its own currency and at its own prices. It is then converted into International Units at a rate of purchasing power: the number of units of the national currency needed to buy, in that country, what one dollar bought in the United States in 1925–34. The rate is found by pricing a list of goods and services in each country, each item weighted by its importance in consumption and investment, and comparing the total with the cost of the same list in the United States. Comparisons for other years are carried forward or back by each country's own index of prices. By 1970 prices in the United States had risen so far that one International Unit corresponded to rather more than two dollars of current money. In British money a unit is equivalent to about 2s. 5d. at the prices of 1913, so that a pound of 1913 is worth about 8¼ units.

Clark set out the method in detail in *The Conditions of Economic Progress*, and the figures in the statistical tables of this encyclopaedia are estimated by his method.

![Bar chart of product per head in International Units for twelve countries, 1950 and 1970](iu1)

*Fig. 1.—Gross product per head of selected countries, 1950 and 1970, in International Units.*

## III. RELIABILITY

The results are estimates, subject to wide margins of error. The goods priced in different countries are not always of the same quality, and many goods now in common use, such as television sets, were unknown or rare in 1925–34 and can be valued only indirectly. The result depends also on whose prices are used to value the goods: valued at American prices, the product of a poor country appears larger, in relation to that of the United States, than when the comparison is made at its own prices. Where much of the food is grown and eaten by the families that grow it, such production must be estimated and valued, and the estimates for much of Asia and Africa are rough. The figures for Germany rest on the official statistics of the Reich, which since 1939 have been published only in part, and those for Siberia and the countries of the Japanese sphere on still scantier information. The error is believed to be of the order of a tenth for the industrial countries, and it may be considerably larger for the others.

## IV. THE WORLD ECONOMY IN INTERNATIONAL UNITS

Measured in International Units, the gross product of the world rose from about 668,000 million in 1950 to about 1,427,000 million in 1970, or by 3.9 per cent a year, while product per head rose from 267 to 409 units. Growth was fastest in Libya and the oil states of the Middle East and in Latin America, and among the great powers in Germany. Among the principal countries it was slowest in China and Great Britain (Table I). The gross product of the Reich more than doubled in the twenty years, as did its product per head.

**TABLE I.—Gross Product of the Principal Countries, 1950 and 1970**

| Country | 1950 | 1970 | Growth, per cent a year |
| --- | --- | --- | --- |
| United States | 183.7 | 344.6 | 3.2 |
| Germany | 117.1 | 273.9 | 4.3 |
| United Kingdom | 44.5 | 76.6 | 2.8 |
| India | 36.3 | 71.4 | 3.4 |
| China | 33.2 | 57.0 | 2.7 |
| Japan | 28.6 | 55.2 | 3.4 |
| France | 23.3 | 51.4 | 4.0 |
| Italy | 22.5 | 44.8 | 3.5 |
| Canada | 12.5 | 31.9 | 4.8 |
| Brazil | 8.0 | 30.2 | 6.8 |
| World | 667.9 | 1,427.4 | 3.9 |

^ In thousand million International Units. The countries are ranked by gross product in 1970. Germany: the Reich in Europe of each year; on its present territory, with Denmark and Norway in 1950, its growth was 4.1 per cent a year (*see* EUROPEAN ECONOMIC COMMUNITY, Table II). United Kingdom: Great Britain and Northern Ireland. India: the provinces of British India and the Indian States.

Countries stand in a very different order by product per head from that by total product. Among those of Fig. 1 product per head ranged in 1970 from about 1,700 units in the United States to less than 100 in China. In 1950 the United States alone among the larger states had more than 1,000 units a head; by 1970 the Reich, France, Great Britain, Sweden, Canada, Australia and Argentina, among others, had passed that figure, and the countries above it held nearly a fifth of the world's population and three-fifths of its product. More than half of mankind, chiefly in India, China and the East Indies, still lived in countries with less than 200 units a head, which together produced about 15 per cent of the world's product (Fig. 2).

![Divided bars showing the shares of the world's population and gross product held by countries grouped by product per head, 1950 and 1970](iu2)

*Fig. 2.—The population and gross product of the world divided according to product per head, 1950 and 1970.*

*See also* ECONOMICS; NATIONAL INCOME; STATISTICAL TABLES.

**Bibliography.** C. Clark, *National Income and Outlay* (London, 1937); C. Clark, *The Conditions of Economic Progress* (London, 1940); Royal Institute of International Affairs, *The German Economic Bloc* (London, 1964); National Institute of Economic and Social Research, *The Real Product of the Currency Areas, 1950–65* (London, 1967); Statistisches Reichsamt, *Wirtschaft und Statistik* (Berlin, later Germania, 1921– ).

(G. F. T.)
