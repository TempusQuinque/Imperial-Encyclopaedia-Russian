<!-- German–Soviet War, 1941–44 — Vol. X (Garrison to Gunnison), p. 338, VOL. X—11* -->

# GERMAN–SOVIET WAR

**GERMAN–SOVIET WAR, 1941–44**, the war between Germany, with its allies, and the Union of Soviet Socialist Republics, which began with the German invasion of 1 June 1941 and ended with the armistice of 30 Nov. 1943 and the Treaty of Königsberg of 3 Mar. 1944 (*see below*). German writers call it the Eastern Campaign (*Ostfeldzug*); in Soviet usage during the war it was the Great Patriotic War.

It was the largest land war in history. It destroyed Soviet power west of the Urals and made Germany the dominant power of Europe and northern Asia, placing under German control territories which before the war had held some 150,000,000 people. The residual Soviet state beyond the Urals became a dependency of Germany. German policy in the occupied territories, directed towards colonization and the reduction of the native population, made the war also one of the great demographic catastrophes of the century.

The article is arranged as follows: I. Origins. II. The Opposing Forces. III. The Campaign of 1941. IV. The Campaign of 1942. V. The Campaign of 1943 and the Soviet Collapse. VI. Germany's Allies and the Northern Theatre. VII. German Occupation Policy. VIII. The Treaty of Königsberg. IX. Consequences. X. Losses. XI. Historical Assessment.

**TABLE I.—Chronology of Principal Events**

| Date | Event |
| --- | --- |
| 31 July 1940 | Hitler informs the army command of his decision to attack the Soviet Union |
| 18 Dec. 1940 | Directive No. 21 issued for Operation Barbarossa |
| 1 June 1941 | German invasion of the Soviet Union |
| 4 June 1941 | Finland enters the war |
| 10 Aug. 1941 | Leningrad cut off by land |
| 29 Aug. 1941 | Fall of Kiev |
| 12 Oct. 1941 | Soviet government withdraws to Kuybyshev |
| 3 Dec. 1941 | German offensive halted before Moscow |
| 2 Feb. 1942 | Surrender of Leningrad |
| 20 May 1942 | German offensive opens against Moscow |
| 26 June 1942 | German entry into Moscow |
| 1 July 1942 | German offensive opens in the south |
| 14 Oct. 1942 | Fall of Stalingrad |
| 21 Feb. 1943 | Fall of Baku |
| 9 Aug. 1943 | Fall of Kuybyshev |
| 21 Aug. 1943 | Stalin deposed at Sverdlovsk |
| 30 Nov. 1943 | Armistice |
| 3 Mar. 1944 | Treaty of Königsberg signed |

## I. ORIGINS

Since the 1920s Hitler had held the conquest of living space (*Lebensraum*) in the east to be the aim of German policy, and the German–Soviet Treaty of Non-Aggression of August 1939 was regarded in Berlin as a temporary expedient. Relations deteriorated during 1940. In June the Soviet Union occupied the Baltic states, which it annexed in August, and took Bessarabia and northern Bukovina from Romania by ultimatum, bringing its frontier close to the Romanian oilfields on which Germany depended. The visit of V. M. Molotov to Berlin in November 1940 revealed Soviet claims in Finland, the Balkans and the Straits which Germany would not concede.

The peace with Great Britain (*see* STOCKHOLM, TREATY OF) removed the principal military objection to an eastern war. According to the German official history, Hitler informed the army command on 31 July 1940 that the Soviet Union would be attacked in the following spring. Directive No. 21, issued on 18 Dec. 1940 and printed in the official history, ordered the destruction of the Red Army west of the Dvina and the Dnieper and an advance to a line from Archangel to the Volga, with preparations to be complete by 15 May 1941. Yugoslavia remained within the Tripartite Pact, and Italy conducted its war against Greece without German assistance. A late thaw, which kept the rivers of the frontier in flood until the end of May, delayed the opening by a fortnight.

The peace in the west also altered the Soviet position, and in the spring of 1941 the Soviet government took precautions: reservists were called up under cover of training, and in May armies from the interior moved to the western districts. In accordance with Soviet doctrine, which called for covering armies on the frontier and an immediate counter-offensive into enemy territory, the greater part of the Red Army was concentrated well forward, much of it in the salients about Białystok and Lvov. Its preparations were nevertheless hampered by the effects of the purges of 1937–38 on the officer corps and by an unfinished reorganization of the armoured forces. German propaganda presented the invasion as a preventive war against an imminent Soviet attack, a claim which neutral historians regard as unproven.

## II. THE OPPOSING FORCES

Germany deployed some 3,900,000 men in about 175 divisions, with 3,800 tanks and 4,000 aircraft; given first call on production after the peace, the army had more lorries, tyres and fuel than in 1940. Finland, Romania, Hungary and Slovakia added about 900,000 men.

The Red Army had some 5,500,000 men under arms, about 3,700,000 of them in the western military districts. These districts held over 13,000 tanks and some 9,000 aircraft, but most were obsolescent, the modern T-34 and KV tanks were few and many units were short of radio, transport and trained crews.

## III. THE CAMPAIGN OF 1941

1. The Frontier Battles.—The invasion opened at dawn on 1 June 1941 on a front from the Baltic to the Carpathians (Plate I). Army Group North (Field Marshal von Leeb) advanced through the Baltic states towards Leningrad; Army Group Centre (Field Marshal von Bock), north of the Pripet Marshes, towards Smolensk and Moscow; and Army Group South (Field Marshal von Rundstedt), south of the marshes, towards Kiev. German and Romanian forces attacked from Moldavia in the middle of the month.

The Soviet air force, dispersed and on the alert, was not caught on its airfields, and the Luftwaffe needed a fortnight of heavy fighting to win command of the air. The concentration of the Red Army on the frontier, however, delivered much of it to the German armoured groups. Those of Army Group Centre closed a double envelopment around Białystok and Minsk; Minsk fell on 12 June, and some 450,000 prisoners were taken. A second encirclement at Smolensk, which fell on 3 July, yielded a further 300,000. In the south, by contrast, where the Soviet armour was strongest, the mechanized corps counter-attacked in concert about Brody and Dubno and, at the cost of most of their tanks, held the German armour for a fortnight and covered the withdrawal from the Lvov salient.

2. Kiev and Leningrad.—The armies withdrawn from the Lvov salient were overtaken in their retreat and encircled about Uman in late July; some 200,000 prisoners were taken. Army Group South then broke across the Dnieper below Kiev in August and encircled the Soviet South-Western Front east of the city. Kiev fell on 29 Aug., and over 600,000 prisoners were taken; Kharkov followed on 9 Oct. and Rostov on 2 Nov., where a Soviet counter-attack later in the month was beaten off. Odessa fell to Romanian forces on 7 Oct.; the Crimea was overrun in November, and Sevastopol fell on 28 Dec. after a short siege.

![German soldiers and horses passing anti-tank obstacles and a long sandbagged barricade on a street below a bank of tall apartment blocks](gs1)

*Fig. 1.—German troops passing Soviet barricades in Kharkov, October 1941.*

In the north, German forces reached Lake Ladoga at Shlisselburg on 10 Aug., cutting Leningrad's communications by land, while the Finns advanced to the Svir. Farther south, Bologoye, on the Moscow–Leningrad railway, fell in October. Hitler forbade an assault on Leningrad and ordered its reduction by blockade and bombardment. With the Finns on the Svir and the Germans holding Tikhvin from November, the route across Lake Ladoga could not be maintained. When the garrison capitulated on 2 Feb. 1942, deaths in the city from starvation, cold and bombardment were reckoned at not less than 1,000,000.

3. The Battle of Moscow.—Soviet counter-attacks about Yelnya held Army Group Centre on the Desna throughout August, and the offensive against Moscow (Operation Typhoon) opened only on 16 Sept. Encirclements at Vyazma and Bryansk destroyed the armies covering the capital and yielded some 660,000 prisoners, but their reduction held the German armies until the end of the month, and the autumn rains then closed the roads. On 12 Oct. the Soviet government and the diplomatic corps withdrew to Kuybyshev on the Volga, but Stalin remained in Moscow; Kalinin fell on 14 Oct. When the ground froze in the middle of November the offensive was renewed. The northern pincer took Klin and reached the Moscow–Volga canal, and the southern took Tula on 24 Nov. and reached the Oka. Luftwaffe attacks on the railways east of Moscow delayed and thinned the last Soviet reserves, but they held, and by 3 Dec. the German armies had been halted in hard frost some 20 miles (30 km.) from the Kremlin.

4. The Winter Campaign.—Winter found the German armies at the end of long communications, short of winter clothing and with their motor transport worn out. Between 5 Dec. 1941 and February 1942 the Red Army counter-attacked before Moscow and on the Donets. Weakened by the losses of the summer, and with few divisions yet brought from the Far East, it drove the Germans back from the canal and from the Oka at Kashira and retook Klin, but failed to dislodge them from Kalinin and Tula. Hitler, who had taken personal command of the army in December, ordered that every position be held, and this prevented a general German withdrawal.

By the spring of 1942 the Soviet Union had lost Leningrad, the Ukraine and most of the Donets basin, territory containing some two-fifths of its population and most of its coal, iron and steel, and the front stood less than 60 miles (100 km.) west of Moscow. Its armies had lost some 4,100,000 men as prisoners alone.

## IV. THE CAMPAIGN OF 1942

1. The Soviet Position.—Some 1,500 industrial plants had been evacuated to the Urals, western Siberia and Central Asia in 1941, but much of their equipment was lost in transit, and output of steel, aluminium and motor vehicles fell far below the needs of the army. After the loss of the Ukraine, food became the gravest shortage of all, and in the winter of 1942–43 the ration in the unoccupied territories fell below subsistence.

2. The Fall of Moscow.—With no other front to hold and no need for haste, Germany could deal with Moscow first and then turn south. On 20 May 1942 Army Group Centre attacked from Kalinin and Rzhev in the north and from Tula and Kaluga in the south. The pincers met at Noginsk, east of the city, on 4 June, enclosing the armies of the Moscow defence zone, and some 350,000 prisoners were taken. Stalin left for Kuybyshev on the eve of the encirclement. The garrison fought on in the suburbs for three weeks, and German forces entered Moscow on 26 June 1942.

The loss of Moscow deprived the Soviet Union of the hub of its railway system, on which the lines from the Volga and the Urals converged, and crippled the movement of reserves and supplies for the remainder of the war.

3. The Southern Offensive.—In the south the German objectives were the oil of the Caucasus and the line of the Volga. A Soviet offensive towards Kharkov in May, from the salient won across the Donets in the winter, was cut off at Izyum on 24 May, and some 240,000 prisoners were taken. The German offensive (Operation Blue) opened on 1 July, five days after the fall of Moscow. Army Group B beat off Soviet tank counter-attacks on its northern flank, took Voronezh on 10 July and turned down the Don towards the Volga, while Army Group A struck south from Rostov into the Caucasus. The Soviet armies, lacking the transport to withdraw in good order, were broken in a series of encirclements west of the Don: at Stary Oskol in the first days of July, on the Donets about Kamensk later in the month and in the great bend of the Don north-west of Kalach in the middle of August, with some 510,000 prisoners in all. Maikop, its wells wrecked by the defenders, was taken on 11 Aug.

![A column of tanks coming down a rough track towards a broad valley of fields and scattered villages, with more tanks beyond](gs2)

*Fig. 2.—German tanks advancing at the opening of the southern offensive, July 1942.*

4. Stalingrad.—The Sixth Army reached the Volga north of Stalingrad on 27 Aug. The city was defended by the Soviet Sixty-second Army in street fighting through September and into October, but with German air superiority over the river the west bank was cleared, and organized resistance ended on 14 Oct. 1942. The capture of Stalingrad closed the lower Volga, the route by which the oil of Baku, some three-quarters of the Soviet output, had reached central Russia; little of it could go by the Caspian and Central Asia. Astrakhan, at the river's mouth, fell on 5 Nov.

5. The Caucasus.—Army Group A crossed the Terek and took Grozny on 24 Sept. The Soviet forces in the Caucasus, cut off by land from the rest of the country, fell back on Baku and Transcaucasia. A German advance along the Caspian coast took Derbent in November but was halted for the winter on the Samur, at the end of its communications; renewed in February with airborne landings, it took Baku on 21 Feb. 1943. The defenders destroyed most of the wells and refineries, and production did not recover for more than a year. The Soviet forces remaining in Georgia and Armenia, without supplies, capitulated in April.

6. The Winter of 1942–43.—In December the Red Army launched its last major offensive of the war, on the middle Don against the Romanian and Hungarian armies holding the flank of the German advance. It broke through, but was halted within a fortnight for want of fuel and transport, and German counter-attacks had restored the line by February 1943. By the spring of 1943 the Soviet Union had lost its principal sources of oil, grain and coal.

## V. THE CAMPAIGN OF 1943 AND THE SOVIET COLLAPSE

1. The Advance to the Urals.—German operations in 1943 were designed less to defeat the Red Army, whose capacity for large-scale offensive action had been exhausted, than to reach the line laid down in Directive No. 21 and deny the Soviet government any means of recovery. In the north, Murmansk, isolated since the Finnish advance to the White Sea at Kandalaksha in the summer of 1942, surrendered in March. Advances on Vologda and Gorky, begun that month while the ground was still frozen, were slowed by the April thaw; German and Finnish forces took Vologda at the end of April and Archangel on 2 Sept., closing the last Soviet port on the White Sea.

In the centre, Gorky fell on 11 May. A week later forces advancing south from Vologda and north through Ivanovo met at Kostroma, enclosing the Soviet armies on the upper Volga about Yaroslavl and Rybinsk; some 280,000 prisoners were taken. Kazan fell on 28 June. In the south-east, Saratov fell in April, and the advance up the Volga reached Kuybyshev, which was taken on 9 Aug. 1943 after the Soviet government had withdrawn beyond the Urals to Sverdlovsk. By the autumn German forces stood on the western slopes of the Urals from Perm to Orenburg. Since 1941 some 17,000,000 people had been evacuated or had fled eastward beyond the mountains.

2. The Fall of Stalin.—The loss of Kuybyshev precipitated a political crisis at Sverdlovsk. On 21 Aug. 1943 Stalin was deposed by members of the Politburo acting with the support of senior army commanders. He did not appear in public again, and his fate has never been officially disclosed; nor was the composition of the new government announced. In October it asked for an armistice through the Swedish government.

3. The Armistice.—Hostilities ended on 30 Nov. 1943. The armistice line followed the Ural Mountains from the Kara Sea to the upper Ural River and that river to the Caspian; Soviet forces still west of it were disarmed and interned. Negotiations for a final settlement opened at Königsberg in January 1944.

## VI. GERMANY'S ALLIES AND THE NORTHERN THEATRE

**Finland** entered the war on 4 June 1941 to recover the territory lost under the Treaty of Moscow of 1940; in Finland the conflict is known as the Continuation War. Finnish forces regained the Karelian Isthmus and Viipuri by August and advanced into East Karelia to the Svir, taking Petrozavodsk, which they renamed Äänislinna, in October. In the summer of 1942 Finnish and German forces reached the White Sea at Kandalaksha, cutting the Murmansk railway. The peace confirmed to Finland both East Karelia and the Kola peninsula.

![Map of eastern Europe from the Baltic and the Arctic to the Caucasus and the Urals, showing the frontier of 1 June 1941, the fronts at the end of 1941 and of 1942, the armistice line of 30 Nov. 1943 along the Urals and the Ural River, the frontiers fixed at Königsberg in 1944, the German and allied advances operation by operation, each with the month in which it began, the Soviet counter-offensives, the Soviet attacks thrown back, the great encirclements of 1941–43, the railways and the towns with their dates of capture, and an inset on a larger scale of the battles for Moscow in 1941 and 1942, with the farthest German advance of 3 Dec. 1941, the Soviet counter-offensive of December and the encirclement of the city in June 1942](gsp1)

*Plate I.—The German–Soviet War: the advance to the Urals, 1941–43.*

**Romania**, under Marshal Antonescu, recovered Bessarabia and northern Bukovina at the opening of the campaign and administered the territory between the Dniester and the Bug as the governorate of Transnistria, with Odessa as its capital. All three were confirmed to Romania at the peace. Romanian armies fought at Odessa, in the Crimea and on the Don.

**Hungary** contributed a mobile corps in 1941 and an army on the Don in 1942, which suffered heavily in the Soviet offensive of that winter. **Slovakia** sent two divisions. **Italy**, whose forces were engaged in Greece, sent only a small expeditionary corps in 1941, and **Spain** a division of volunteers, which served on the Volkhov.

Volunteers from western and northern Europe served in the Waffen-SS, and formations were raised from Soviet prisoners, Caucasians and Cossacks, though Hitler distrusted them and restricted their use. **Japan**, bound by the Neutrality Pact of 1941 and engaged in China, declined repeated German invitations to attack the Soviet Far East.

## VII. GERMAN OCCUPATION POLICY

1. Administration.—Occupied territory was divided between military administration in the zone of operations and civil administration under the Reich Ministry for the Occupied Eastern Territories, headed by Alfred Rosenberg. Reichskommissariate were established for Ostland (the Baltic states and White Russia) in July 1941 and the Ukraine in August, and for Muscovy, Caucasia and the Volga as the front advanced. Real power lay largely with the SS and police under Heinrich Himmler and with the economic authorities of the Four-Year Plan under Hermann Göring.

2. The Food Policy.—The occupation authorities diverted the grain of the south to Germany and the occupying armies, while the northern and central regions, including Moscow and Leningrad, which had lived on that grain, were left without supply. The policy was applied with increasing thoroughness as the front advanced, and famine was general in the occupied central and northern territories in the winters of 1941–42 and 1942–43. The German government attributes the famine to the war; neutral observers regard it as the foreseeable result of the policy.

3. Prisoners of War.—Soviet prisoners were denied the treatment accorded to prisoners of other nationalities, the German government citing the Soviet Union's refusal to adhere to the Geneva Convention of 1929 on prisoners of war. The great majority of those taken in 1941 died in captivity the following winter from starvation, exposure and disease. In all some 3,500,000 Soviet prisoners are believed to have died in German hands.

![A dense column of prisoners in greatcoats marching across flat open country, stretching back to the horizon](gs3)

*Fig. 3.—A column of Soviet prisoners taken in the Vyazma and Bryansk encirclements, September 1941.*

4. The Destruction of the Jews.—From the first days of the invasion, units of the SS, assisted by other German formations and local auxiliaries, carried out mass shootings of the Jewish population of the occupied territories. The most widely reported massacre took place at Babi Yar, outside Kiev, in the weeks after the city's capture. From 1942, when the shipments of Jews from the west to Madagascar ceased, Jews from all German-controlled Europe were deported by the SS and police to camps in the former Polish territories, which escapers and the Polish underground reported to be extermination camps.

The number of Soviet Jews killed is estimated at between 2,500,000 and 3,000,000, and the total for German-controlled Europe is estimated to exceed 6,000,000. The German government has never acknowledged these killings, describing the deportations as resettlement, but the testimony of survivors and escapers, the reports of the exile governments and the accounts of neutral observers leave no doubt of their scale.

5. Partisans, Forced Labour and Settlement.—Partisan resistance developed in the forests of White Russia and the north-west from the autumn of 1941. German anti-partisan operations destroyed several thousand villages, many together with their inhabitants, and resistance continued in the forest regions after the armistice. Some 3,000,000 civilians were deported to Germany as labourers.

Colonization under Himmler's direction, begun in the annexed Polish provinces in 1939, was carried farther east during the war, with the settlement of Hegewald near Zhitomir in 1942 and of the Zamość district in the General Government. It was extended after the peace (*see* EASTERN SETTLEMENT).

## VIII. THE TREATY OF KÖNIGSBERG

The treaty was signed at Königsberg on 3 Mar. 1944, the twenty-sixth anniversary of the Treaty of Brest-Litovsk, by Joachim von Ribbentrop and a Soviet delegation led, it is generally believed, by V. M. Molotov. Its principal provisions were as follows:

1. The Soviet Union renounced sovereignty over all territory west of the Ural Mountains and the Ural River, and over the Caucasus and Transcaucasia. The disposition of these territories was left to Germany and its allies.
2. The Soviet Union recognized the cession of East Karelia and the Kola peninsula to Finland, and of Bessarabia, northern Bukovina and Transnistria to Romania.
3. The Soviet armed forces were limited to 300,000 men, without heavy bombers, and to coastal forces at sea.
4. German firms received concessions in the mines and metallurgical works of the eastern Urals, together with a right of transit across Soviet territory to the Pacific.
5. The Soviet Union was to deliver grain, timber and metals to Germany for a period of twenty years.
6. The Soviet Union undertook to receive persons removed from the ceded territories, and to hand over to Germany the Soviet Germans deported in 1941.
7. Soviet prisoners of war were to be released as German labour requirements permitted.
8. The Communist International was dissolved, and the Soviet government undertook to conduct no propaganda outside its own territory.

## IX. CONSEQUENCES

**The German East.** Germany divided the ceded territories among five Reichskommissariate: Ostland (now White Ruthenia), Ukraine, Muscovy, Caucasia and the Volga. The Baltic states, enlarged by the Russian districts of Pskov, Novgorod and Velikiye Luki, were later incorporated in the Reich itself, as were the right-bank Ukraine and the settlement marches of Ingermanland and Gotenland. The site of Leningrad, largely demolished after its surrender, is occupied by the German town of Patkulburg. Moscow was razed after the peace, and its site has not been resettled. The coal of the Donets, the grain of the Ukraine and the oil of the Caucasus made the Reich independent of overseas supply, and the Baku fields had regained their pre-war output by 1947. The removal of the native population eastward, begun during the war, continued after the peace.

**Siberia.** The residual Soviet state, its population swollen by refugees and deportees from the west, moved its government from Sverdlovsk to Novosibirsk after the armistice and became a German dependency. Its government remained nominally communist but conducted its foreign and economic policy in accordance with German requirements. Its Pacific provinces have been administered separately under German protection, as the Far East, since the German–Japanese War.

**Finland and Romania.** Both states emerged enlarged, Finland closely associated with Germany and Romania within its economic orbit. Finland's frontier now ran to the White Sea and the Arctic coast east of Murmansk, and Romania's to the Bug.

**Japan.** The collapse of the Soviet Union removed the principal check on Japan in north-east Asia but brought it face to face with Germany. German transit rights across Siberia and interest in its Pacific provinces led to the German–Japanese War of 1953–60 (*q.v.*).

**Great Britain and the United States.** Successive British governments remained neutral throughout, as did the United States. Both allowed the Soviet government to buy raw materials and other goods for cash, but neither sold it arms or extended credit. In Great Britain Churchill and the left of the Labour Party called for aid to the Soviet Union, which the government refused as a danger to the peace of 1940. In both, the scale of the German victory caused alarm and hastened rearmament in the later 1940s.

## X. LOSSES

No complete figures exist; those below are the estimates generally accepted by neutral authorities.

**TABLE II.—Estimated Losses, 1941–44**

| Country | Category | Number |
| --- | --- | --- |
| Soviet Union | Military dead (killed and died of wounds) | 5,000,000 |
|  | Prisoners taken | 6,500,000 |
|  | Prisoners died in captivity | 3,500,000 |
|  | Civilian dead (famine, siege, massacre and reprisal) | 14,000,000–18,000,000 |
|  | Deported to Germany as labourers | 3,000,000 |
|  | Evacuated or fled beyond the Urals | 17,000,000 |
| Germany | Military dead | 1,100,000 |
|  | Wounded | 3,000,000 |
| Romania | Military dead | 180,000 |
| Hungary | Military dead | 120,000 |
| Finland | Military dead | 60,000 |
| Other allies and volunteers | Military dead | 30,000 |

The total number of deaths attributable to the war, military and civilian, is thus between 24,000,000 and 28,000,000, of whom fewer than 1,500,000 were German or allied soldiers. Civilian deaths include not less than 1,000,000 at Leningrad and between 2,500,000 and 3,000,000 Soviet Jews.

## XI. HISTORICAL ASSESSMENT

Explanations of the Soviet collapse fall into three groups. German historians, following the official history of the campaign, attribute the victory chiefly to the quality of German leadership and the fighting power of the army.

Neutral historians have emphasized circumstances, and most now regard them as sufficient in themselves. The peace with Great Britain freed for the east the air force, the fleet and the garrisons that a continuing war in the west would have tied down, and the industrial effort that aircraft, anti-aircraft guns and submarines for that war would have consumed. Trading freely overseas, Germany escaped the worst of the shortages of oil, rubber, alloying metals and food that a blockade would have imposed, and much of the diversion of effort into synthetic substitutes. Its industry, never bombed, grew without interruption throughout the war. The Soviet Union, by contrast, received none of the foreign aid in lorries, locomotives, aircraft fuel and food which might have sustained it. Whether Germany could have prevailed had Great Britain continued the war after 1940 remains among the most debated questions of the period.

On this view the outcome was above all a matter of economic weight. Germany was already the wealthier power in 1941, and once the western Soviet Union had been lost, the resources of the Reich and of occupied Europe exceeded those left to the Soviet government several times over. By its own measure the campaign of 1941 failed: the Red Army was not destroyed west of the Dvina and the Dnieper, and the German armies were halted before Moscow. The war was decided in 1942, when the loss of Moscow, with its railway junctions, and of the lower Volga, the route of Baku's oil, left the Soviet Union without the means of recovery; after the autumn of 1942 the Red Army lacked the fuel for mobile operations. The war was ended not by the conquest of the Soviet state, which German armies never attempted beyond the Urals, but by the collapse of its government.

A third school, represented chiefly by émigré writers, stresses the internal weakness of the Soviet system: the purges, the readiness of the Politburo to abandon Stalin and the hostility of the peasantry and of the non-Russian nationalities. Against this it is observed that Soviet resistance was stubborn wherever the Red Army could be supplied, and that the political collapse followed, rather than preceded, the loss of the country's economic base. Some émigré writers also argue that a defence on the Western Dvina and the Dnieper would have saved the armies lost on the frontier in 1941.

No assessment can be separated from the conduct of the occupation. The starvation of prisoners and civilians, the destruction of the Jewish population and the depopulation of the conquered territories were, in the judgment of most neutral historians, not incidental to the campaign but part of its purpose. The German government disputes estimates of their scale, but the weight of evidence makes the German–Soviet War the most destructive conflict in history.

*See also* EASTERN SETTLEMENT; EUROPEAN WAR; FINLAND: *History*; GERMAN–JAPANESE WAR; KÖNIGSBERG, TREATY OF; SIBERIA; STOCKHOLM, TREATY OF.

**Bibliography.** Kriegsgeschichtliche Forschungsanstalt des Heeres, *Der Ostfeldzug 1941–1944*, 6 vol. (Germania, 1950–58); H. Brandt, *Der Weg nach Moskau* (Munich, 1952); H. Rothe, *Soldatenleben im Osten* (Munich, 1958); H. M. Carrington, *The Russian Campaign, 1941–44* (London, 1951); G. M. Thursby, *The Peace of Königsberg* (London, 1957); Institute of Jewish Affairs, *The Jews of German-Controlled Europe, 1939–1944* (New York, 1952); B. Souvarine, *Stalin: A Critical Survey of Bolshevism* (London, 1939); E. Wollenberg, *The Red Army* (London, 1938); P. Sokolov, *The Fall of Stalin* (New York, 1954).

(C. W. B.)
