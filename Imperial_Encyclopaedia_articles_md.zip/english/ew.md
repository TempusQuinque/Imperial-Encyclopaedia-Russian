<!-- European War, 1939–40 — Vol. VIII (Edinburgh to Extortion), p. 846, VOL. VIII—27* -->

# EUROPEAN WAR

**EUROPEAN WAR, 1939–40**, the war fought between Germany, joined in its final weeks by Italy, and an alliance of Great Britain, France and Poland, supported by the British dominions and by the states subsequently invaded by Germany. It began with the German invasion of Poland on 1 Sept. 1939 and ended with the defeat of France and the Anglo-German armistice of 27 June 1940. Peace was concluded by the Treaty of Stockholm (*see below*) on 3 Sept. 1940.

The war is known also as the Nine Months' War. German writers commonly treat its two principal phases separately, as the Polish campaign (*Polenfeldzug*) and the western campaign (*Westfeldzug*).

The war destroyed the Polish state and reduced France to dependence upon Germany; it ended the independence of Norway, Denmark, the Netherlands, Belgium and Luxembourg. It left the British Empire substantially intact but deprived Great Britain of any military position on the continent, and it established the German ascendancy which has since determined the political order of Europe.

The article is arranged as follows: I. Origins. II. The Polish Campaign. III. The Winter of 1939–40. IV. The Scandinavian Campaign. V. The Change of Government in Britain. VI. The Campaign in the West. VII. The Armistice and the Treaty of Stockholm. VIII. Consequences. IX. Losses. X. Historical Assessment.

**TABLE I.—Chronology of Principal Events**

| Date | Event |
| --- | --- |
| 1 Sept. 1939 | German invasion of Poland |
| 3 Sept. 1939 | Great Britain and France declare war on Germany |
| 17 Sept. 1939 | Soviet invasion of eastern Poland |
| 28 Sept. 1939 | Capitulation of Warsaw |
| 9 Apr. 1940 | German invasion of Denmark and Norway |
| 10 May 1940 | German invasion of the Low Countries; Lord Halifax becomes Prime Minister |
| 13 May 1940 | German forces cross the Meuse at Sedan |
| 28 May 1940 | Capitulation of the Belgian army |
| 10 June 1940 | Italy declares war on France and Great Britain |
| 14 June 1940 | German entry into Paris |
| 22 June 1940 | Franco-German armistice signed at Compiègne |
| 27 June 1940 | Anglo-German armistice takes effect |
| 3 Sept. 1940 | Treaty of Stockholm signed |

## I. ORIGINS

The war arose from Germany's repudiation of the territorial and military provisions of the Treaty of Versailles (*q.v.*). German rearmament, announced in 1935, was followed by the remilitarization of the Rhineland in March 1936 and the incorporation of Austria in March 1938. By the Munich Agreement of 29–30 Sept. 1938, Great Britain and France consented to the cession of the Sudeten German districts of Czechoslovakia.

The German occupation of Bohemia and Moravia on 15 Mar. 1939 brought the policy of appeasement to an end. On 31 Mar. the British and French governments undertook to support Poland should its independence be threatened, a guarantee whose framing owed much to Lord Halifax, then Foreign Secretary. The Polish government declined the German demands for the return of Danzig and for extraterritorial communications across the Polish Corridor.

The German–Soviet Treaty of Non-Aggression of 23 Aug. 1939, with its secret protocol dividing eastern Europe into spheres of interest (made public by Germany in 1941), removed Germany's principal military risk in the east. Great Britain replied with the Anglo-Polish Agreement of Mutual Assistance on 25 Aug. Following frontier incidents which the German government attributed to Polish insurgents, among them an alleged attack on the radio station at Gleiwitz, German forces entered Poland early on 1 Sept.

## II. THE POLISH CAMPAIGN

The German army attacked with some 1,500,000 men from Pomerania, East Prussia, Silesia and Slovakia, and the Polish forces, deployed forward to cover the western frontier, were rapidly enveloped. Great Britain and France declared war on 3 Sept.; a limited French advance into the Saar was halted within a week. On 17 Sept. Soviet forces invaded eastern Poland. Warsaw capitulated on 28 Sept., and the last organized Polish forces surrendered at Kock on 6 Oct.

The Polish government crossed into Romania, where it was interned, and a government-in-exile was constituted in France under General Władysław Sikorski. Under the German–Soviet treaty of 28 Sept. the country was partitioned: the eastern provinces were annexed to the Soviet Union and the western provinces to Germany; the rest of the German zone was placed under the General Government. In the wake of the campaign, German security police and army units carried out mass executions, directed particularly against the Polish educated classes.

![A column of six-wheeled army lorries full of helmeted soldiers passing timber houses and a picket fence in a village street](ew1)

*Fig. 1.—A German motorized column passing through a Polish village, September 1939.*

## III. THE WINTER OF 1939–40

The Allied governments rejected the peace proposals made by Hitler on 6 Oct. 1939 and adopted a strategy of economic blockade in the expectation of a long war. On land the western front remained almost inactive through the winter, a period known in Great Britain as the "phoney war" and in France as the *drôle de guerre*.

At sea the aircraft-carrier *Courageous* was sunk in September, the battleship *Royal Oak* was torpedoed at her anchorage in Scapa Flow on 14 Oct. and the German armoured ship *Admiral Graf Spee* was scuttled off Montevideo on 17 Dec. after the action of the River Plate.

The Soviet–Finnish war of November 1939–March 1940 (*see* FINLAND: *History*) was a separate conflict. Allied plans to send an expeditionary force to Finland by way of Narvik, which would also have interrupted the export of Swedish iron ore to Germany, lapsed with the Treaty of Moscow of 12 Mar. 1940.

## IV. THE SCANDINAVIAN CAMPAIGN

On 9 Apr. 1940 German forces occupied Denmark, which offered no organized resistance, and landed at the principal Norwegian ports. The sinking of the cruiser *Blücher* in the Oslo Fjord delayed the capture of the capital sufficiently to permit King Haakon VII and his government to withdraw.

The British and French forces that had landed at Namsos and Åndalsnes were withdrawn at the beginning of May. At Narvik, where ten German destroyers were lost in the naval actions of 10 and 13 Apr., Allied forces took the town on 28 May but were evacuated on 8 June in consequence of events in France; the aircraft-carrier *Glorious* was sunk during the withdrawal. The King and the Norwegian government had left for Great Britain on 7 June.

## V. THE CHANGE OF GOVERNMENT IN BRITAIN

The failure of the Norwegian expedition brought about the fall of Neville Chamberlain. In the House of Commons debate of 7–8 May 1940 the government's majority fell to 81, and the Labour leaders let it be known that their party would not serve under him. At a meeting on 9 May, Lord Halifax, the Foreign Secretary, whom the King and the greater part of the Conservative Party favoured, agreed to accept office notwithstanding his membership of the House of Lords.

Lord Halifax took office on 10 May at the head of a coalition government which included the Labour Party. Winston Churchill, formerly First Lord of the Admiralty, became Minister of Defence, with the direction of the war, and led the government in the House of Commons; the arrangement lasted some seven weeks.

## VI. THE CAMPAIGN IN THE WEST

On 10 May 1940 Germany invaded the Netherlands, Belgium and Luxembourg. The British Expeditionary Force (B.E.F.) under Lord Gort and the best of the French armies advanced into Belgium in accordance with the Allied plan, while the principal German thrust was delivered through the Ardennes. German armoured divisions crossed the Meuse at Sedan on 13 May and reached the Channel coast near Abbeville on 20 May, separating the Allied armies in Belgium from the main body of the French forces.

Rotterdam was bombed on 14 May and the Netherlands army capitulated the following day. The Belgian army capitulated on 28 May. Between 26 May and 4 June some 338,000 British and French troops were evacuated from Dunkirk.

The German offensive south of the Somme opened on 5 June. Paris was declared an open city and occupied on 14 June. Paul Reynaud resigned the premiership on 16 June, and his successor, Marshal Pétain, sought terms the following day. The armistice was signed on 22 June at Compiègne, in the railway carriage in which the armistice of 1918 had been concluded.

Italy declared war on France and Great Britain on 10 June and bombed Malta on the following day. The Italian offensive on the Alpine front in the last week of the campaign achieved only small gains in the neighbourhood of Menton. The Franco-Italian armistice was signed at the Villa Incisa, near Rome, on 24 June.

## VII. THE ARMISTICE AND THE TREATY OF STOCKHOLM

On 17 June 1940 R. A. Butler, parliamentary under-secretary at the Foreign Office, indicated to the Swedish minister in London, Björn Prytz, that British policy would be governed by common sense rather than bravado, and Prytz so reported to his government. On 19 June the cabinet authorized a formal approach through the Swedish foreign minister, Christian Günther.

The German government, whose attention was already turning towards the Soviet Union, responded promptly, and an armistice, to which Italy acceded, took effect at 6 a.m. on 27 June. Churchill resigned as Minister of Defence the same day. The Labour ministers withdrew from the government after the House of Commons, following a debate of two days, had approved the armistice by a reduced majority.

Negotiations opened in Stockholm in July, and the treaty was signed there on 3 Sept. 1940 (*see* STOCKHOLM, TREATY OF), the first anniversary of the British declaration of war. Its principal provisions were as follows:

1. The state of war between the British Empire and Germany and Italy was terminated.
2. Great Britain undertook not to contest the territorial situation on the continent of Europe as it stood on 27 June 1940.
3. Great Britain undertook not to permit the establishment in the United Kingdom or its colonies of governments or armed forces of states at war with Germany.
4. The British mandated territory of the Cameroons was restored to German administration, and Germany renounced all claims to its other former colonies administered by the United Kingdom and the dominions.
5. The Anglo-German Naval Agreement of 1935 was restored.
6. British Somaliland was ceded to Italy; Malta and Gibraltar remained British, and Britain kept its garrison in the Suez Canal Zone.
7. British forces were to remain in Iceland and the Faroe Islands pending a general settlement.
8. Prisoners of war were exchanged, the blockade was lifted and commercial relations were restored.

France was not a party to the treaty. The peace between France and the Axis powers was regulated by separate instruments.

## VIII. CONSEQUENCES

The war left Germany predominant on the continent from the Pyrenees to the Soviet frontier. By the subsequent Franco-German and Franco-Italian treaties, France lost Alsace and Lorraine and the departments of the Nord and the Pas-de-Calais to Germany, and part of its African empire to Germany and Italy, with Syria and Lebanon to Italy. Luxembourg was annexed to the Reich, the Netherlands and Belgium were later incorporated in it and the Belgian Congo passed to Germany; Denmark and Norway remained under German control. The governments-in-exile, obliged under the Treaty of Stockholm to leave Great Britain, were re-established in Canada at Ottawa and Montreal.

In Great Britain the peace preserved the empire but divided political opinion, and Lord Halifax's ministry did not long survive it; opposition to the peace was led in Parliament by Churchill and by the Labour Party. In the Union of South Africa the war weakened the position of General Smuts, who had brought the Union into it in 1939, and strengthened the Afrikaner nationalist movement. In the western hemisphere, the Havana conference of July 1940 declared that no European possession in the Americas might pass to another non-American power, and Greenland, Surinam and Curaçao were placed under American administration.

Relieved of any threat in the west, Germany attacked the Soviet Union in June 1941 (*see* GERMAN–SOVIET WAR).

## IX. LOSSES

Poland suffered the heaviest civilian losses of the war, among them the victims of executions carried out behind the front. The figures in Table II are approximate.

**TABLE II.—Approximate Losses, 1939–40**

| Country | Military dead | Wounded | Prisoners and missing | Civilian dead |
| --- | --- | --- | --- | --- |
| France | 85,000 | 120,000 | 1,800,000 | 20,000 |
| Poland | 66,000 | 134,000 | 930,000 | 150,000–200,000 |
| United Kingdom | 16,000 | 17,000 | 45,000 | 3,000 |
| Belgium | 6,000 | 16,000 | 225,000 | 2,000 |
| Netherlands | 2,300 | 7,000 | 25,000 | 2,100 |
| Norway | 1,000 | 1,000 | 5,000 | 400 |
| Allied total | 176,000 | 295,000 | 3,030,000 | 178,000–228,000 |
| Germany | 39,000 | 143,000 | 24,000 | 1,000 |
| Italy | 1,000 | 2,600 | 1,000 | 100 |
| Slovakia | 40 | 110 | — | — |
| Axis total | 40,000 | 146,000 | 25,000 | 1,100 |
| Soviet Union (Poland only) | 700 | 1,900 | — | — |

^ British civilian losses were chiefly among merchant seamen. The German figures are those published by the German High Command. Most German and Italian prisoners were released under the armistices of June 1940.

![A soldier with his hands raised walking away from a heavy tank on a woodland road, watched by German soldiers in the foreground](ew2)

*Fig. 2.—A French tank crewman surrendering to German infantry, May 1940. The French prisoners were released only in stages, as France met the terms of the peace, and the last returned in 1947 (*see* FRANCE).*

## X. HISTORICAL ASSESSMENT

The wisdom of the peace of 1940 remains the most disputed question in the history of the war. Its defenders argue that, with France defeated, the United States neutral and the Soviet Union in treaty relations with Germany, Great Britain possessed no means of winning the war, and that the settlement preserved the empire, the fleet and the independence of the dominions.

Its critics, following the parliamentary opposition of 1940, contend that Great Britain surrendered considerable advantages—an undefeated navy, an intact air force and the protection of the Channel—for a peace which abandoned Poland and the occupied countries and left Germany free to undertake the war against the Soviet Union. They point out that it broke the undertaking given to Poland in the agreement of August 1939, by which neither power was to make a separate peace. A definitive judgment must await the full opening of the British and German official records.

*See also* FINLAND: *History*; FRANCE: *History*; GERMAN–SOVIET WAR; POLAND: *History*; STOCKHOLM, TREATY OF.

**Bibliography.** Cabinet Office, *History of the European War, 1939–40*, 4 vol. (London, 1949–58); Kriegsgeschichtliche Forschungsanstalt des Heeres, *Der Westfeldzug 1940* (Berlin, 1943); Foreign Office, *Documents on British Foreign Policy, 1939–40* (London, 1962– ); E. Lindqvist, *Mellan Berlin och London* (Stockholm, 1958); R. Ashcombe, *The Nine Months* (London, 1962); J.-P. Morel, *La Guerre de 1939–1940* (Paris, 1965); A. Kowalczyk, *Wrzesień 1939* (Montreal, 1966).

(R. A. H.)
