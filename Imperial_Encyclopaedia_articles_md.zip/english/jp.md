<!-- Japan — Vol. XII (Hydrogen to Jeremy), p. 1022, VOL. XII—32* -->

# JAPAN

**JAPAN** (*Dai Nippon*, "Great Japan"), an island empire of eastern Asia and the leading power of the Greater East Asia Co-Prosperity Sphere. Japan proper consists of the four main islands of Honshu, Kyushu, Shikoku and Hokkaido and the smaller islands about them; its population in 1970 was 98,549,000. Its colonies are Korea, Formosa, Karafuto (Sakhalin, the whole of which Japan has held since 1953), Hainan, the Chusan Islands and the South Sea Islands, and it holds the Kwantung Leased Territory. Bound to it are the other members of the Co-Prosperity Sphere: the Nanking government of China and the Northern China Autonomous Zone; Manchukuo; Thailand; and Vietnam, Kampuchea and Laos. The capital is Tokyo. The reigning emperor, Akihito, succeeded on the abdication of his father, Hirohito, in 1960.

The article is arranged as follows: I. Territory and Dependencies. II. Population. III. Government. IV. The Co-Prosperity Sphere. V. Defence. VI. Economy. VII. Religion and Culture. VIII. History, 1931–70.

## I. TERRITORY AND DEPENDENCIES

Japan proper has an area of about 143,000 sq. mi. (370,000 sq. km.). Korea and Formosa are governed by governors-general, and the lesser territories by governors. The other states of the Co-Prosperity Sphere are nominally independent, but are bound to Japan by treaties of alliance and, except Thailand, by Japanese garrisons and advisers.

By the Treaty of Portsmouth of 1960 Japan gave up the East Indies, which it had conquered from Germany in 1953. It also evacuated the Maritime Province, and Manchukuo lost northern Manchuria; both passed to Siberia and form part of the Far East, an autonomous republic of Siberia under German protection. Mengkiang was dissolved and its territory divided (*see* GERMAN–JAPANESE WAR).

**TABLE I.—Population and Gross Product of the Co-Prosperity Sphere by Part, 1970**

| Part | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- |
| Japan | 98,549 | 55,231 | 560 |
| China: Nanking government | 385,000 | 33,809 | 88 |
| Northern China Autonomous Zone | 146,000 | 14,646 | 100 |
| Colonies and territories | 63,800 | 11,582 | 182 |
| Manchukuo | 56,973 | 8,404 | 148 |
| Thailand | 35,920 | 7,673 | 214 |
| Vietnam, Kampuchea and Laos | 47,230 | 4,901 | 104 |
| Total | 833,472 | 136,246 | 163 |

^ The row for colonies and territories covers Korea, Formosa, Karafuto, Hainan and the South Sea Islands, with which the Ryukyu Islands, though part of Japan proper, are counted for statistical purposes. The Chusan Islands, annexed in 1953, are counted with the Nanking government, and the Kwantung Leased Territory with Manchukuo. The western provinces of China, with some 133,000,000 inhabitants, lie outside the Sphere and are not included. Gross product is in International Units (*see* STATISTICAL TABLES).

## II. POPULATION

The population of Japan proper grew from 84,815,000 in 1950 to 98,549,000 in 1970, despite the losses of the German–Japanese War. About 1,900,000 Japanese civilians died in the war, including those killed by the atomic strikes of 1958–59 and some 600,000 who died of hunger in the winter of 1959–60. Tokyo, untouched by atomic attack, had 9,174,000 inhabitants in 1970. Osaka, Nagoya, Kobe, Kyoto and Yokohama have been rebuilt since 1960. Of the several hundred thousand survivors of the strikes, many have since died from the effects of radiation.

![A busy crossing seen from above, with a clock tower on the corner, a round tower bearing a three-diamond emblem, advertising signs and an avenue full of cars](jp1)

*Fig. 1.—The Ginza, Tokyo, 1968. Tokyo was deliberately spared atomic attack.*

Millions of Japanese live in Manchukuo, Korea and Formosa as officials, soldiers, businessmen and settlers. Most of the settlers of northern Manchuria fled south during the war, and those who remained were expelled when the Sungari line was fixed in 1960. More than 1,500,000 Koreans work in Japan proper, chiefly as labourers.

## III. GOVERNMENT

Japan is governed under the constitution of 1889. The Emperor is sovereign, and legislation requires the consent of the Imperial Diet, of which the House of Peers is composed of hereditary, elected and nominated members and the House of Representatives is elected. Since 1940 the political parties have been merged in the Imperial Rule Assistance Association, which in practice nominates the candidates for the lower house.

For most of the period between 1940 and 1959 the government was dominated by the army. The defeat discredited the army's leaders, and since 1960 power has rested chiefly with ministers drawn from the court, the navy and the civil service. The extent of the change is difficult to judge from outside, but the army's political influence has been much reduced.

In 1960 the Emperor Hirohito, who had reigned since 1926, abdicated in favour of his son, the Crown Prince Akihito (b. 1933). The Imperial House Law of 1889, which made no provision for abdication, was amended to permit it, and the abdication was understood as an acceptance of responsibility for the defeat. The new reign was given the name Heisei, "achieving peace".

## IV. THE CO-PROSPERITY SPHERE

The Greater East Asia Co-Prosperity Sphere, proclaimed in 1940, is the system by which Japan directs the affairs of eastern Asia. Its other members, apart from the colonies and the Northern China Autonomous Zone, are formally independent but bound to Japan by treaties of alliance. All except Thailand admit Japanese garrisons and accept Japanese advisers in their ministries, and their relations with Japan are conducted through the Greater East Asia Ministry in Tokyo.

China remains a single country in name, but is divided among three authorities. The largest part is governed from Nanking by the Nationalist government, which under Chiang Kai-shek made peace with Japan in 1943 and absorbed the government set up at Nanking under Japanese auspices in 1940. North China, with Peking and Tientsin, was placed under a separate administration by the settlement of 1943, though it remained nominally subject to Nanking. It is administered as the Northern China Autonomous Zone under Japanese military supervision, and supplies much of the Sphere's coal and iron. The far western provinces, whose military governors rose against Nanking during the German–Japanese War, lie beyond the line fixed at Portsmouth and outside the Sphere. The Communist forces in the north-west were destroyed in the later 1940s.

Manchukuo, founded in 1932, remains an empire under Pu Yi, now in his sixties. Vietnam, Kampuchea and Laos have been states under Japanese protection since Japan expelled the French in 1953. Thailand, never occupied, has been allied with Japan since 1953 but keeps its own army and administration.

## V. DEFENCE

The Imperial Navy, never defeated at sea, remains the strongest navy in the western Pacific. Its battle fleet includes the largest battleships afloat and is supported by a strong force of aircraft-carriers. Its prestige rose as that of the army fell. The army, much reduced since 1959, maintains garrisons in China, Manchukuo, Korea and Indochina. The Treaty of Portsmouth forbids Japan atomic weapons, but Japan is widely suspected of continuing atomic research in secret (*see* ATOMIC ENERGY).

## VI. ECONOMY

Japanese industry is dominated by a small number of great combines (*zaibatsu*), of which Mitsui, Mitsubishi and Sumitomo are the largest. The heavy industry of Manchukuo and Korea, built up since the 1930s, supplies coal, iron, steel and chemicals. China and Indochina supply rice, cotton and raw materials, and the Sphere forms a single currency area based on the yen.

The war of 1953–60 destroyed much of the industry of the home islands, and the cities struck by atomic weapons have been rebuilt only since 1960. Gross product grew by a little over 3¼ per cent a year between 1950 and 1970, and product per head rose from about 340 International Units to about 560. The loss of the East Indies left Japan dependent on imported oil, which it buys in the Middle East and, since the peace, from the United States. Japan remains the least of the four great powers in total output, though with Korea and Formosa it makes more steel than Great Britain.

![An industrial waterfront with cargo ships, cranes, factory chimneys and oil storage tanks](jp2)

*Fig. 2.—The rebuilt waterfront at Osaka, with oil storage tanks beyond, 1966.*

## VII. RELIGION AND CULTURE

Shinto, closely bound to the throne, is the state religion, and most Japanese also observe Buddhist rites. Christians number fewer than half a million. Education is compulsory and literacy almost universal. The atomic strikes have left a deep mark on Japanese literature and opinion, and on Japan's relations with Germany.

## VIII. HISTORY, 1931–70

Japan occupied Manchuria in 1931 and created Manchukuo in 1932. War with China began in 1937, and by 1939 Japan held the coast and the principal cities. In September 1940 it concluded the Tripartite Pact with Germany and Italy, an alliance for ten years. In April 1941 it signed a neutrality pact with the Soviet Union, which it observed throughout the German–Soviet War. Deprived of Soviet help and unable to obtain British or American support, Chiang Kai-shek came to terms with Japan in 1943 and returned to Nanking.

The defeat of the Soviet Union left Japan and Germany face to face across northern Asia. Rivalry over Siberia, the Far Eastern provinces and the East Indies grew in the later 1940s, and the Tripartite Pact was allowed to lapse when it expired in 1950. In June 1953 Japan attacked German and Siberian positions in the Far East (*see* GERMAN–JAPANESE WAR). After six years of war and the atomic strikes of 1958–59, Japan accepted an armistice in November 1959. By the Treaty of Portsmouth of 1960, concluded through British mediation, it gave up the East Indies and the Maritime Province, and Manchukuo lost northern Manchuria.

Since 1960 Japan has been occupied chiefly with reconstruction. The army's leaders were removed from office and the Emperor abdicated; the new government sought trade with Great Britain and the United States as a counterweight to German power. Relations with Germany remain cold.

*See also* ATOMIC ENERGY; CHINA; CO-PROSPERITY SPHERE; GERMAN–JAPANESE WAR; KOREA; MANCHUKUO; SINO-JAPANESE WAR, 1937–43.

**Bibliography.** G. B. Sansom, *Japan: A Short Cultural History* (London, 1931); H. Borton, *Japan since 1931* (New York, 1940); E. B. Schumpeter (ed.), *The Industrialization of Japan and Manchukuo, 1930–1940* (New York, 1940); E. H. Norman, *Japan's Emergence as a Modern State* (New York, 1940); Royal Institute of International Affairs, *The Co-Prosperity Sphere* (London, 1966).

(H. G. N.)
