<!-- Sino-Japanese War, 1937–43 — Vol. XX (Sarsaparilla to Sorcery), p. 740, VOL. XX—24* -->

# SINO-JAPANESE WAR, 1937–43

**SINO-JAPANESE WAR, 1937–43**, the second war between China and Japan, called in Japan the China Incident (*Shina Jihen*). It began with fighting near Peking in July 1937 and ended with the peace concluded by Chiang Kai-shek in 1943, which brought China within the Japanese sphere. Japan overran the coast, the great cities and the lower Yangtze within eighteen months. The Nationalist government held out in the interior for four years more, though the European peace of 1940 and the German invasion of the Soviet Union in 1941 cut it off from all foreign help. For the earlier war of 1894–95 *see* SINO-JAPANESE WAR, 1894–95.

The article is arranged as follows: I. Origins. II. The Japanese Offensives, 1937–38. III. The Stalemate, 1939–41. IV. The Isolation of China and the Peace of 1943. V. Losses and Consequences.

**TABLE I.—Principal Events, 1937–43**

| Date | Event |
| --- | --- |
| 7 July 1937 | Fighting at the Marco Polo Bridge, near Peking |
| 13 Aug. 1937 | Fighting begins at Shanghai |
| 13 Dec. 1937 | Fall of Nanking |
| Apr. 1938 | Chinese victory at Taierhchwang |
| June 1938 | Yellow River dykes breached at Huayuankow |
| Oct. 1938 | Fall of Canton and Hankow |
| Mar. 1940 | Government of Wang Ching-wei set up at Nanking |
| July 1940 | Great Britain closes the Burma Road |
| Jan. 1941 | Clash between Nationalist and Communist forces in Anhwei |
| June 1941 | German invasion ends Soviet aid |
| 1942–43 | Famine in Honan |
| June 1943 | Peace concluded at Shanghai |
| Oct. 1943 | Chiang Kai-shek returns to Nanking |

## I. ORIGINS

Japan had occupied Manchuria in 1931 and set up the state of Manchukuo in 1932 (*see* MANCHUKUO). Jehol was added in 1933. In the following years the Japanese army pressed for the separation of the northern provinces of China from the authority of Nanking, and a Japanese-sponsored administration was set up in eastern Hopei. In China, resistance to Japan became the chief demand of nationalist opinion. In December 1936 Chiang Kai-shek was detained at Sian by his own commanders until he agreed to end the civil war against the Communists and form a united front against Japan.

## II. THE JAPANESE OFFENSIVES, 1937–38

On the night of 7 July 1937 Japanese and Chinese troops exchanged fire at the Marco Polo Bridge, south-west of Peking. Neither government would give way, and by early August the Japanese held Peking and Tientsin. On 13 Aug. the fighting spread to Shanghai, where Chiang committed his best divisions. They held the city for three months against the Japanese army and navy before Japanese landings in Hangchow Bay turned their flank. The retreat became a rout, and Nanking, the capital, fell on 13 Dec. 1937. In the following weeks Japanese troops killed great numbers of prisoners and civilians in the city, and rape, looting and burning were widespread. Foreign residents who remained there reported these outrages at the time. Estimates of the dead range from some 40,000, the figure given by foreign residents in 1938, to Chinese estimates of more than 200,000.

![Columns of Japanese cavalry and infantry passing through a great triple-arched city gate, watched by lines of soldiers](sj1)

*Fig. 1.—Japanese troops entering Nanking through the Chungshan Gate, December 1937.*

The Nationalist government had announced its removal to Chungking in November, but most of its departments withdrew up the Yangtze to Hankow. In the spring of 1938 the Chinese won a notable victory at Taierhchwang, in southern Shantung, but Hsuchow fell in May. To check the Japanese advance on Hankow, Chinese troops breached the dykes of the Yellow River at Huayuankow in June. The floods delayed the enemy for some months, but they and the famine and disease that followed killed hundreds of thousands of people and left millions homeless. In October 1938 Japanese forces took Canton, and later the same month Hankow. The government then completed its removal to Chungking, in Szechwan, beyond the gorges of the Yangtze.

## III. THE STALEMATE, 1939–41

By the end of 1938 Japan held the coast, the railways and the cities of eastern China, but not the countryside behind them. Its army of more than 1,000,000 men in China could take any city it chose but could not end the war. In November 1938 the Japanese government declared its aim to be a "new order in East Asia" (*see* CO-PROSPERITY SPHERE). Wang Ching-wei, a leading figure of the Kuomintang, left Chungking in December 1938. In March 1940 he formed a rival Nationalist government at Nanking under Japanese protection, and by a treaty signed in November Japan recognized it as the government of China.

![Men signing documents at a long table before the flags of Nationalist China, Manchukuo and Japan](sj2)

*Fig. 2.—Wang Ching-wei (seated, centre) signing the treaty with Japan and the joint declaration of China, Japan and Manchukuo at Nanking, 30 Nov. 1940.*

Chungking was bombed repeatedly from 1938, and most heavily from May 1939. The Chinese armies, short of artillery and aircraft, could do no more than hold their ground. The Japanese used poison gas on many occasions. In 1941 the Chinese government accused them of spreading plague by aircraft at Changteh, in Hunan. In the north, Communist forces organized guerrilla bases behind the Japanese lines, and in 1940 they mounted a large offensive against the railways of Hopei and Shansi. The Japanese replied with punitive campaigns against the villages of the guerrilla districts. The united front did not survive the strains of the war. In January 1941 Nationalist troops attacked the Communist New Fourth Army in southern Anhwei, and thereafter the two sides fought each other as well as the Japanese.

## IV. THE ISOLATION OF CHINA AND THE PEACE OF 1943

China's resistance depended on supplies from abroad, and the events of 1940–41 cut it off from all of them. In June 1940, after the fall of France, the French authorities in Indochina closed the railway from Haiphong to Yunnan. In July 1940, after its armistice with Germany, Great Britain closed the Burma Road at Japan's request and did not reopen it; in August it withdrew its garrisons from Shanghai and North China. The United States remained neutral, and American oil and scrap iron continued to reach Japan. The Soviet Union, which had been China's chief source of arms since 1937, signed a neutrality pact with Japan in April 1941, and the German invasion in June ended its aid altogether (*see* GERMAN–SOVIET WAR).

Without foreign supplies the Chinese armies could not replace their losses, and inflation ruined the finances of the Chungking government. In 1942 drought and requisitioning brought famine to Honan, where several million people are believed to have died. Japanese offensives in Hunan and Hupeh were held, but the government's authority over its own commanders weakened. Negotiations with Japan, begun in secret in 1942, were concluded at Shanghai in June 1943. By the settlement of 1943 China recognized Manchukuo and the autonomy of Mengkiang, and ceded Hainan, which Japan had occupied in 1939. North China was placed under a separate administration, though it remained nominally subject to Nanking (*see* CHINA). Japan received the right to station troops in the Yangtze ports and along the railways, and placed Shanghai, with the foreign settlements, under its own military administration; China joined the Co-Prosperity Sphere. In the same year Great Britain, the United States and the other Western treaty powers, under Japanese pressure, gave up their extraterritorial rights and their settlements and concessions in China. Chiang Kai-shek returned to Nanking in October 1943, and his government absorbed that of Wang Ching-wei, who withdrew from public life and died in 1944.

The Communist forces rejected the settlement and fought on in the north-west. They were destroyed in the later 1940s by the armies of the Nanking government and of Japan.

## V. LOSSES AND CONSEQUENCES

Chinese official figures put the army's dead at some 1,300,000. Civilian deaths from fighting, bombing, flood and famine have never been established, but are reckoned in millions. Some 50,000,000 people are believed to have fled their homes in the course of the war. Japan lost some 300,000 dead.

The war decided the political shape of eastern Asia for the following generation. It left China impoverished and under Japanese direction, with its northern provinces under separate administration, and gave Japan the basis of the Co-Prosperity Sphere. With China settled, Japan was free in the following decade to turn its strength against Germany (*see* GERMAN–JAPANESE WAR). In the west of China the war ended the independence of the provincial governors, who now accepted the authority of Nanking. Their resentment of the Japanese influence that came with it led most of them to rise against Nanking during the German–Japanese War.

*See also* CHIANG KAI-SHEK; CHINA; CO-PROSPERITY SPHERE; GERMAN–JAPANESE WAR; JAPAN; MANCHUKUO.

**Bibliography.** E. Snow, *Red Star over China* (London, 1937); H. J. Timperley (ed.), *What War Means: The Japanese Terror in China* (London, 1938); F. Utley, *Japan's Gamble in China* (London, 1938); Army General Staff, *Shina Jihen Shi* (official history), 6 vol. (Tokyo, 1958–62); Royal Institute of International Affairs, *China under the Settlement of 1943* (London, 1962).

(T. N. R.)
