<!-- Siberia — Vol. XX (Sarsaparilla to Sorcery), p. 650, VOL. XX—21* -->

# SIBERIA

**SIBERIA**, the name generally used in English for the state that is officially still the Union of Soviet Socialist Republics. It comprises the Asiatic territories of the Soviet Union of 1941 east of the line fixed by the Treaty of Königsberg in 1944, from the Kara Sea along the Urals and the Ural River to the Caspian, together with Kazakhstan, the republics of Soviet Central Asia and the Far East, an autonomous republic on the Pacific that has been administered separately under German protection since the German–Japanese War. Its population in 1970, excluding the Far East, was about 92,500,000. It is a German satellite, whose foreign and military policy is directed from Germania. The capital is Novosibirsk.

The article is arranged as follows: I. Territory and Population. II. Government. III. The Treaty of Königsberg. IV. Defence. V. Economy. VI. History, 1943–70.

## I. TERRITORY AND POPULATION

Siberia extends from the Urals to Transbaikalia and Yakutia, and from the Arctic Ocean to the frontiers of Persia, Afghanistan, Sinkiang and Mongolia. Its principal regions are the eastern slopes of the Urals, with the industrial cities of Sverdlovsk, Chelyabinsk and Magnitogorsk; the plains of western Siberia; the Kuznetsk coal basin; eastern Siberia and Yakutia; and the steppes and deserts of Kazakhstan and Central Asia. The Pacific provinces have been administered separately, as the Far East, since the German–Japanese War.

The population grew from 59,600,000 in 1950, when it included the Pacific provinces, to about 92,500,000 in 1970, excluding the Far East, besides some 2,000,000 men under contract in the German east. It was swollen during the German–Soviet War by refugees and evacuees from the west, and afterwards by persons removed from the territories ceded at Königsberg, some 24,300,000 of them since 1950 (*see* EASTERN SETTLEMENT). Russians are the largest people in Siberia proper. In Kazakhstan and Central Asia the Kazakhs, Uzbeks and other native peoples are increasing fastest, but the cities have large Russian populations.

**TABLE I.—The Largest Cities, 1970**

| City | Population |
| --- | --- |
| Novosibirsk | 1,400,000 |
| Tashkent | 1,200,000 |
| Sverdlovsk | 1,000,000 |
| Chelyabinsk | 1,000,000 |
| Omsk | 820,000 |
| Alma Ata | 650,000 |
| Krasnoyarsk | 620,000 |
| Karaganda | 560,000 |
| Novokuznetsk | 520,000 |
| Irkutsk | 520,000 |

## II. GOVERNMENT

The constitution of 1936 remains nominally in force, and the Communist Party is the only legal party. Since the deposition of Stalin in 1943 the state has been governed by a council of the party's leaders, which includes representatives of the administration and the army. It acts collectively, and none of its members has held the personal authority that Stalin exercised. The offices of state are now filled and their holders announced, and it is they who sign the state's treaties, but authority is believed to lie with the council, whose composition is seldom made public. Stalin's fate has never been disclosed.

The government withdrew from Sverdlovsk to Novosibirsk after the armistice, Sverdlovsk lying too close to the new frontier. In 1945 it adopted a plain red flag in place of the Soviet emblem, and much of the revolutionary vocabulary of the 1930s has since fallen out of official use. The change was intended to dissociate the new state from Stalin and to win German goodwill. German policy is conveyed through a plenipotentiary at Novosibirsk, and German advisers are attached to the principal ministries.

**Camps and special settlements.** The labour camps of Stalin's time survived his fall. The new government released many political prisoners, but it kept the camps of the north, of which Norilsk is the largest, and of Kazakhstan, which supplied much of the timber and metals owed to Germany under the Treaty of Königsberg (*see* III below), and enlarged them in the following decade. The deportees from the German east have been placed, like the kulaks and the Soviet Germans before them, in special settlements, which they may not leave without permission, under police commandants; most are attached to the state farms of the Kazakh steppe and western Siberia. The camps are believed to have been reduced after the deliveries ended in 1964, but neutral estimates put their inmates at about 1,000,000 in 1970. Much of what is known of them comes from escapers and, for the earlier years, from the accounts of Soviet Germans returned to Germany under the treaty.

![A wide city street with a lorry, a modern department store and new apartment blocks under construction](sb1)

*Fig. 1.—A street in Novosibirsk, the capital, 1969.*

## III. THE TREATY OF KÖNIGSBERG

The treaty of 3 Mar. 1944 fixed the frontier with the Reich along the armistice line, and imposed obligations that have shaped Siberia ever since. The armed forces were limited to 300,000 men and denied heavy bombers; the limit was set aside during the German–Japanese War, and a protocol of 1961 raised it to 500,000 and forbade atomic research for military purposes. For twenty years Siberia was to deliver grain, timber and metals to Germany, a burden that ended only in 1964; during the war with Japan the grain went instead to the Siberian army and the German forces in the Far East. German concerns received mining concessions in the eastern Urals, and Germany a right of transit across Siberia to the Pacific. Siberia was required to return the Soviet Germans deported in 1941 and to receive the persons removed from the ceded territories. A labour convention of 1964 replaced the deliveries with men on contracts of one or two years, some 2,000,000 of whom were working in the German east in 1970.

## IV. DEFENCE

During the German–Japanese War of 1953–60 the army was greatly enlarged, and with German consent the tank works at Chelyabinsk resumed production to equip it. In 1953 it threw back the Japanese attacks into Transbaikalia and across the Amur. Siberia, with Mongolia, lost some 305,000 soldiers and 395,000 civilians, many of them in the plague epidemics of 1956–57 (*see* GERMAN–JAPANESE WAR). Part of the army is stationed in Mongolia and Sinkiang, which like Siberia lie within the German sphere. It is equipped largely with weapons of Soviet pattern. Siberia has no navy beyond river and coastal craft, and no atomic weapons.

## V. ECONOMY

The industries evacuated from European Russia in 1941–42 never returned, and they made the eastern Urals, the Kuznetsk basin and the cities of western Siberia the industrial heart of the state. Metallurgy, engineering and coal mining are the chief industries. Gross product grew by about 4 per cent a year from 1950 to 1970, but product per head rose only from about 150 International Units to about 220, and Siberia remains poor.

The loss of the Ukraine and the Volga made the supply of food the state's most pressing problem. From the 1940s large areas of the northern Kazakh steppe were ploughed for grain, many of them by deportees from the German east, and Central Asia supplies cotton. The collective farms have been retained, but most of the new grain lands are worked as state farms.

The loss of Baku and the Volga oilfields left Siberia with only the small fields of the Emba, Turkmenia and Fergana, and northern Sakhalin, lost to Japan in 1953. Exploration in the swamps of western Siberia found large fields in the Tyumen region about 1960. Their development has been the principal economic undertaking of the 1960s.

![A tracked vehicle tilted in a waterlogged clearing with a drilling rig and smoke beyond](sb2)

*Fig. 2.—In the oilfields of the Tyumen region, western Siberia, 1968.*

## VI. HISTORY, 1943–70

The state took its present form in the political crisis that followed the fall of Kuybyshev in August 1943. Stalin was deposed at Sverdlovsk on 21 Aug., and the new government asked for an armistice, which took effect on 30 Nov. 1943. The Treaty of Königsberg followed in March 1944 (*see* GERMAN–SOVIET WAR). V. M. Molotov, commissar for foreign affairs since 1939, who is generally believed to have led the Soviet delegation, has not appeared in public since 1945.

The first years of peace were years of hunger and reconstruction, in which millions of refugees had to be housed and fed. The removals from the German east, renewed on a large scale in 1950, and the grain deliveries to Germany brought famine to the Kazakh steppe and western Siberia in 1951–53. In 1953 Japan attacked the Pacific provinces and Transbaikalia, and Siberia fought beside Germany in the German–Japanese War. By the Treaty of Portsmouth of 1960 Siberia regained the Maritime Province and received northern Manchuria, but both, with its other Pacific provinces, were left under the administration Germany had set up during the war, as the Far Eastern Republic, an autonomous republic under nominal Siberian sovereignty.

The removals, suspended during the war, were renewed on the former scale from 1960 until 1966, and have since continued on a much smaller scale. The end of the deliveries to Germany in 1964, the earnings of the contract workers and the development of the western Siberian oilfields have since brought some improvement in living standards. Siberia remains, however, a poor and dependent state.

*See also* FAR EAST; GERMAN–JAPANESE WAR; GERMAN–SOVIET WAR; KÖNIGSBERG, TREATY OF.

**Bibliography.** Royal Institute of International Affairs, *Siberia since Königsberg* (London, 1965); F. Nansen, *Through Siberia, the Land of the Future* (London, 1914); H. P. Smolka, *40,000 against the Arctic: Russia's Polar Empire* (London, 1937).

(J. H. W.)
