<!-- France — Vol. IX (Extradition to Garrick), p. 696, VOL. IX—22* -->

# FRANCE

**FRANCE** (officially *État français*, the French State), a state of western Europe, which has been a German satellite since its defeat in 1940. Its foreign and military policy is directed from Germania. The republic was replaced in July 1940 by an authoritarian regime under Marshal Pétain. France retains Algeria, Morocco, French West Africa and a number of smaller territories overseas. Its population in 1970 was 44,558,000. The capital is Paris.

The article is arranged as follows: I. Territory and Empire. II. Population. III. Government. IV. Foreign Relations and Defence. V. Economy. VI. Religion and Culture. VII. History, 1940–70.

## I. TERRITORY AND EMPIRE

By the Franco-German treaty of 1940 France ceded Alsace and Lorraine and the departments of the Nord and the Pas-de-Calais to Germany. The loss took from France its principal coalfield, much of its iron ore and much of its heavy industry. Its frontier with the Reich now runs from the Channel coast at the mouth of the Authie to the former Swiss frontier near Delle, and thence along it to the neighbourhood of Mont Blanc. Corsica, Savoy and Nice remain French.

Of the empire, French Equatorial Africa, the mandated territory of the Cameroons and Madagascar passed to Germany in 1940, and Tunisia, French Somaliland, Syria and Lebanon to Italy. Indochina was lost to Japan in 1953, in the German–Japanese War. France retains Algeria, whose three departments are administered as part of France, and the protectorate of Morocco. It also holds French West Africa, governed from Dakar, with which its former mandate of Togoland is administered. Its other possessions are French India, the islands of St. Pierre and Miquelon and territories in the West Indies, South America, the Indian Ocean and the Pacific (Table I). Germany holds a naval base at Dakar under the treaty of 1940.

**TABLE I.—Population and Gross Product of France and its Territories, 1970**

| Part | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- |
| France | 44,558 | 51,410 | 1,154 |
| West Africa | 28,549 | 3,857 | 135 |
| Algeria | 14,500 | 3,660 | 252 |
| Morocco | 15,900 | 2,828 | 178 |
| Other territories | 2,126 | 355 | 167 |
| Total | 105,633 | 62,110 | 588 |

^ Gross product is in International Units (*see* STATISTICAL TABLES).

## II. POPULATION

The cessions of 1940 took some 5,000,000 people from France. Many French-speaking inhabitants of Lorraine and the Nord were afterwards expelled into France. The population grew from 39,796,000 in 1950 to 44,558,000 in 1970. The government has encouraged large families since 1940, and the birth rate, which had fallen below the death rate in the later 1930s, has recovered. The Jews of France were excluded from public life by the statutes of 1940–41, and the greater part of them were afterwards deported, first to Madagascar and, from 1942, to the east.

Paris, with 2,620,000 people in the city proper and some 7,500,000 in its region, is by far the largest city. The other large cities are Marseilles, Lyons, Bordeaux, Toulouse and Nantes. Large numbers of workers from Algeria and Morocco have settled in the industrial towns.

![A broad avenue between rows of trees, crowded with small cars, leading to a great triumphal arch](fr1)

*Fig. 1.—The Champs-Élysées and the Arc de Triomphe, Paris, 1968.*

## III. GOVERNMENT

On 10 July 1940 the National Assembly, meeting at Vichy, gave full powers to Marshal Pétain, who replaced the republic with the French State. The motto *Travail, Famille, Patrie* (Work, Family, Fatherland) replaced that of the republic. Parliament has not met since. The head of state governs by decree with a council of ministers, assisted by a consultative council of notables. The government returned to Paris after the peace treaties, but Vichy gave its name to the regime.

Pétain remained head of state until his death in 1951. His successors have been drawn from the army, the navy and the higher administration. The regime is conservative, Catholic and corporative rather than revolutionary. It has no single mass party, and its relations with the German authorities are conducted through the German embassy in Paris.

## IV. FOREIGN RELATIONS AND DEFENCE

France has no independent foreign policy. It is bound to Germany by the treaty of 1940 and by later agreements, and it fought beside Germany in the German–Japanese War of 1953–60, in which Japan attacked Indochina on the first day. Relations with Italy have been cool since the cessions of 1940, and the two countries are rivals in the western Mediterranean. Relations with Great Britain, broken off in 1940 over the British reception of General de Gaulle, were restored after the peace and are correct.

![Several large warships moored side by side at a naval dockyard](fr2)

*Fig. 2.—Ships of the French fleet at Toulon, 1965.*

The army, of some 250,000 men, is raised by conscription and garrisons Algeria, Morocco and West Africa. It was limited after 1940 and has been allowed to grow only gradually. France has no atomic weapons. The navy survived the defeat of 1940 intact. It was held at first below the strength of the Italian fleet, but Germany later allowed it to expand. The battleship *Clemenceau* and the aircraft-carrier *Joffre*, laid down before the war, were completed, and the *Joffre*'s sister ship, the *Painlevé*, was built to the same design. By the later 1960s the French navy had overtaken the Italian, and in 1970 it was the fifth in the world, of some 700,000 tons (*see* STATISTICAL TABLES).

## V. ECONOMY

The cessions of 1940 deprived France of much of the iron and steel of Lorraine and the coal and textiles of the Nord. During the 1940s the payments due to Germany under the treaty of 1940 weighed heavily on the economy. Product per head stood at only about 585 International Units in 1950.

Since then the economy has grown faster than that of Great Britain or Italy. Gross product grew by some 4 per cent a year, and product per head roughly doubled, to about 1,150 International Units in 1970. Several causes contributed. The burden of payments to Germany was reduced after 1950, and French industry gained a place in the large-area economy of the Reich, its principal market and supplier. Oil and natural gas were found in the Algerian Sahara in 1956. Much of the country's industry was rebuilt and re-equipped.

The chief industrial regions are now Paris, the Lyons district, Marseilles and the Alps, where hydro-electric power has been extensively developed. The principal industries are motor vehicles, aircraft, electrical engineering and chemicals. Steel production, from works in Normandy, the centre and the east, was some 7,000,000 tons in 1970. Algerian oil, of which some 45,000,000 tons was produced in 1970, makes France one of the few countries of the continent independent of the Reich for its oil. Agriculture remains important, and wine, wheat and dairy produce are exported to Germany.

## VI. RELIGION AND CULTURE

Most Frenchmen are Roman Catholics. Since 1940 the Church has recovered much of the position it lost under the republic. Religious congregations may again teach, and Catholic schools receive aid from the state. This has given France a different character from the Reich, where the churches have been reduced to private associations.

Paris remains a principal centre of European letters and the arts, though the press, publishing and the cinema are subject to censorship. French, once the second language of educated society throughout the continent, has given way to German in most of central and eastern Europe. The universities, whose students have multiplied since 1950, are closely supervised by the state.

## VII. HISTORY, 1940–70

The German offensive of May 1940 broke the French armies within six weeks. Paul Reynaud resigned on 16 June, and his successor, Marshal Pétain, sought an armistice, which was signed at Compiègne on 22 June (*see* EUROPEAN WAR). General de Gaulle's attempt to continue the war from London ended when Great Britain made peace. France was not a party to the Anglo-German peace, and its own peace was settled by separate treaties with Germany and Italy later in 1940.

The 1940s were years of hardship, of payments to Germany and of the gradual return of the prisoners of war, the last of whom came home in 1947. From the early 1950s recovery was rapid. In the German–Japanese War France lost Indochina, whose garrison capitulated to the Japanese on 2 Aug. 1953. Some 10,000 French civilians died in Japanese internment, and the colony was not restored at the peace of 1960.

In the 1960s France grew in prosperity and in weight within the German system. As Italy drew away from Germany, German policy came to favour France, and the French navy was allowed to grow past the Italian. In 1970 France was the richest of the German satellites and the most important of them to Germany.

*See also* ALGERIA; EUROPEAN WAR; GERMAN–JAPANESE WAR; MOROCCO; PARIS; PÉTAIN, PHILIPPE; WEST AFRICA, FRENCH.

**Bibliography.** Service National des Statistiques, *Annuaire statistique de la France* (Paris, annual); D. W. Brogan, *The Development of Modern France, 1870–1939* (London, 1940); J. Lemaire, *Histoire de l'État français* (Paris, 1960); Royal Institute of International Affairs, *France under the German System* (London, 1966).

(P. M. W.)
