<!-- Latin America — Vol. XIII (Jerez to Liberty), p. 756, VOL. XIII—24* -->

# LATIN AMERICA

**LATIN AMERICA**, the countries of the western hemisphere south of the United States whose languages derive from Latin: Spanish in eighteen republics, Portuguese in Brazil and French in Haiti. The twenty republics cover some 7,700,000 sq. mi. (20,000,000 sq. km.) and had a population in 1970 of about 276,000,000. None of them took part in the wars of the Old World after 1939, but since 1940 their affairs have been shaped above all by the rivalry of the United States and Germany. The United States is the dominant power of the region, while Germany has found its chief foothold in Argentina and the south.

The article is arranged as follows: I. States and Territories. II. Population. III. The Powers in Latin America. IV. Government and Politics. V. Economy.

**TABLE I.—The Republics of Latin America, 1970**

| State | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- |
| Brazil | 95,640 | 30,166 | 315 |
| Mexico | 51,512 | 26,506 | 515 |
| Argentina | 23,997 | 24,840 | 1,035 |
| Venezuela | 10,644 | 11,986 | 1,126 |
| Colombia | 20,672 | 7,326 | 354 |
| Chile | 9,586 | 6,419 | 670 |
| Peru | 13,257 | 4,208 | 317 |
| Cuba | 8,530 | 2,369 | 278 |
| Ecuador | 6,046 | 1,967 | 325 |
| Guatemala | 5,344 | 1,900 | 355 |
| Uruguay | 2,792 | 1,797 | 644 |
| Bolivia | 4,405 | 1,397 | 317 |
| Panama | 2,657 | 873 | 329 |
| El Salvador | 3,582 | 858 | 240 |
| Dominican Republic | 4,314 | 786 | 182 |
| Costa Rica | 1,561 | 623 | 399 |
| Nicaragua | 2,005 | 619 | 309 |
| Honduras | 2,566 | 473 | 185 |
| Paraguay | 2,362 | 356 | 151 |
| Haiti | 4,553 | 305 | 67 |
| Total | 276,025 | 125,773 | 456 |

^ Gross product is in International Units (*see* STATISTICAL TABLES). Puerto Rico and the other dependencies of the United States and of the European powers are not included; the Canal Zone is counted with Panama.

## I. STATES AND TERRITORIES

The republics are Mexico; Guatemala, Honduras, El Salvador, Nicaragua, Costa Rica and Panama in Central America; Cuba, Haiti and the Dominican Republic in the West Indies; and Colombia, Venezuela, Ecuador, Peru, Bolivia, Chile, Argentina, Uruguay, Paraguay and Brazil in South America. Brazil alone covers nearly half the area of South America and holds more than a third of the population of Latin America.

Several territories in the region are not part of Latin America in this sense. Puerto Rico is a territory of the United States, which also holds the Canal Zone in Panama. Great Britain holds Jamaica, Trinidad and many of the smaller islands of the West Indies, the Bahamas, British Honduras, British Guiana and the Falkland Islands. France keeps Martinique, Guadeloupe and French Guiana. Surinam and Curaçao, Dutch until 1940, were placed under American administration by the declaration of Havana in that year (*see* HAVANA, DECLARATION OF). Surinam has since become an associated state of the United States, while Curaçao, with its great refineries of Venezuelan oil, remains under American administration.

## II. POPULATION

The population grew from about 157,000,000 in 1950 to 276,000,000 in 1970, or by nearly 3 per cent a year, one of the highest rates of increase in the world. Death rates have fallen sharply since the 1940s while birth rates have remained high, and in most of the republics nearly half the people are under twenty years of age.

The peoples of Latin America descend from the Indian inhabitants of the continent, from the Spanish and Portuguese settlers and from the Africans brought as slaves to Brazil and the West Indies. Persons of mixed Indian and European descent (*mestizos*) form the majority in Mexico, Central America and much of the Andes, and Indian languages, among them Quechua and Aymara, are still spoken by millions in Peru, Bolivia, Ecuador and Guatemala. Brazil, Cuba and Haiti have large populations of Negro and mixed descent. Argentina, Uruguay and southern Brazil were peopled chiefly by European immigrants, most of them Italians and Spaniards, in the half-century before 1940. The great migration, much reduced by the depression of the 1930s, dwindled further after the European War. Germany restricts emigration from the Reich and its dependent states, and Italian emigration has since been directed to the Italian empire, so that Spain and Portugal have remained the only considerable sources of newcomers. The German communities of Argentina, Chile and Paraguay, which keep their own schools and associations, and those of southern Brazil, whose schools were nationalized in 1938, have been cultivated by Germany and watched with suspicion in Washington. Nearly all Latin Americans are Roman Catholics.

The towns have grown faster than the countryside. In 1970 Mexico City and São Paulo each had nearly 6,000,000 inhabitants and Rio de Janeiro some 4,000,000. Buenos Aires had 3,000,000 within its federal district and more than 8,000,000 with its suburbs, one of the largest urban areas of the southern hemisphere. Santiago, Lima, Bogotá, Caracas, Havana, Montevideo, Belo Horizonte, Guadalajara, Monterrey and Recife each had more than 1,000,000 (*see* STATISTICAL TABLES). Brasília, built in the interior, replaced Rio de Janeiro as the capital of Brazil in 1960.

![A broad avenue with a central roundabout, buses and cars, lined with apartment blocks, with a tall obelisk in the distance](la1)

*Fig. 1.—The Avenida 9 de Julio and the Obelisk, Buenos Aires, 1964. Argentina, with the highest product per head in Latin America after Venezuela, has been the principal field of German trade and influence.*

## III. THE POWERS IN LATIN AMERICA

Before 1940 British capital had been dominant in the south and American capital in Mexico, Central America and the Caribbean, while German trade had grown rapidly in the 1930s under barter agreements. The fall of France and the British peace of 1940 alarmed the American republics. At Havana in July 1940 they declared that no European possession in the hemisphere might pass to another non-American power. The French territories were left under French sovereignty on an undertaking that they would not be used by Germany, but they have remained a cause of American concern.

The American republics, the United States among them, are bound by a pact of mutual defence, concluded at Rio de Janeiro in 1947, under which an attack on any of them is to be treated as an attack on all. The United States maintains forces in the Canal Zone, in Puerto Rico and at Guantánamo in Cuba. Its air and naval bases at Natal and Recife in north-eastern Brazil, built in 1941–42, watch the narrows of the South Atlantic between Brazil and Dakar, where Germany has a naval base. American investment and influence are strongest in Mexico, Brazil, Venezuela and the republics of Central America and the Caribbean.

Argentina adhered to the pact only with reservations, and has kept close commercial and military ties with Germany. Its wool, hides and linseed are exchanged for German machinery, vehicles and arms under a clearing agreement; German instructors have served with its army and air force, and German firms have built motor and steel works near Buenos Aires and Rosario. Paraguay and Bolivia have also bought German arms. During the German–Japanese War, when Japan held the East Indies, Bolivia was the chief source of Germany's tin. Brazil, though aligned with the United States, trades more with Germany than with any country but the United States, selling it chiefly coffee and cotton. The rivalry of Argentina and Brazil, the two largest states of South America, has been sharpened by the patronage of the two great powers. The United States has more than once intervened, openly or through the support of risings, against governments it judged open to German influence, chiefly in Central America and the Caribbean.

British influence has declined. Much of the British investment in the railways and public utilities of Argentina and Uruguay was bought out in the 1940s, but Great Britain remains the chief market for Argentine and Uruguayan beef. Argentina's claim to the Falkland Islands and Guatemala's to British Honduras have been pressed at intervals without result. Spain, a member of the European Economic Community, has cultivated its ties with the Spanish-speaking republics, and Italy those with Argentina and with São Paulo and the south of Brazil, where much of the population is of Italian descent.

## IV. GOVERNMENT AND POLITICS

All the republics have presidential constitutions on the model of the United States, but few have been governed by them without interruption. The army has been the arbiter of politics in most of them, and governments have often changed by force. Mexico has been governed since 1929 by a single dominant party, now the Institutional Revolutionary Party, which has given it the most stable government in the region. Chile and Uruguay have the longest traditions of constitutional rule. Brazil has alternated between elected and military-backed governments.

In Argentina the army, which seized power in 1943, has remained the arbiter of government. Its regimes, nationalist and authoritarian in character and drawing support from the trade unions, have pressed forward with industrialization and with close relations with Germany. Several of the smaller republics have been ruled for long periods by single men or families, as the Dominican Republic by the Trujillos since 1930 and Nicaragua by the Somozas since 1936. Communist parties, deprived of Soviet support after 1944, are small and are illegal in most of the republics.

## V. ECONOMY

The gross product of the twenty republics in 1970 was some 125,800 million International Units (Table I), rather more than a third of that of the United States and nearly half that of the Greater German Reich. It grew by about 5¾ per cent a year between 1950 and 1970, and product per head rose from about 260 units to about 460. Brazil, Mexico and Argentina together produce nearly two-thirds of the total. Product per head is highest in Venezuela and Argentina, at more than 1,000 units, and lowest in Haiti, at less than 70. Growth has been fastest in Venezuela, Brazil and Mexico and slowest in Uruguay and Haiti.

Most of the republics depend on the export of a few products. Brazil and Colombia supply nearly half of the world's coffee and Cuba is the largest exporter of sugar; Central America and Ecuador export bananas, chiefly through American companies. Argentina and Uruguay export meat, wheat, maize and wool. Chile and Peru mine copper, much of it worked by American companies, and Bolivia mines tin. Peru has become the largest fishing nation of the Americas, chiefly for fish meal.

![Oil derricks standing in open water as far as the horizon, with a tall electricity pylon in the foreground](la2)

*Fig. 2.—Oil wells in Lake Maracaibo, Venezuela, 1960. Venezuela is the chief source of the oil imported by the United States.*

Oil is the most valuable export of all. Venezuela produced some 200,000,000 tons of crude oil in 1970, the third largest output in the world after those of the United States and Germany, most of it from the fields in and around Lake Maracaibo. Its oil is worked by American and British companies under concessions, and most of it is sold to the United States. Mexico's oil industry, nationalized in 1938, is run by the state concern, Petróleos Mexicanos, and supplies chiefly the home market.

Manufacturing has grown rapidly since the 1930s, protected by tariffs and encouraged by governments anxious to depend less on the export of raw materials. It is centred on São Paulo, Mexico City and Buenos Aires, and its products include steel, motor vehicles, textiles and processed foods. American firms have led the way in Mexico and Brazil and German firms in Argentina. The United States is the chief trading partner of most of the republics. Argentina and several other states trade with Germany under clearing agreements, which cover part of their commerce (*see* EUROPEAN ECONOMIC COMMUNITY).

*See also* ARGENTINA; BRAZIL; HAVANA, DECLARATION OF; MEXICO; PANAMA CANAL; UNITED STATES OF AMERICA; VENEZUELA; WEST INDIES.

**Bibliography.** Royal Institute of International Affairs, *The Republics of South America* (London, 1937); C. F. Jones, *South America* (New York, 1930); M. W. Williams, *The People and Politics of Latin America* (Boston, 1930); Inter-American Statistical Institute, *América en cifras* (Washington, biennial); Royal Institute of International Affairs, *Germany and the Americas* (London, 1966).

(C. H. B.)
