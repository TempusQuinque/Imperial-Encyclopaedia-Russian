<!-- Italy — Vol. XII (Hydrogen to Jeremy), p. 972, VOL. XII—31* -->

# ITALY

**ITALY** (*Regno d'Italia*), a kingdom of southern Europe and one of the principal powers of the Mediterranean. With its colonies and possessions it forms an empire of some 114,000,000 people (Table I), extending from Tunisia and Libya to Syria and the Horn of Africa, and it holds Greece as a satellite. The capital is Rome. The reigning king, Umberto II, succeeded his father, Victor Emmanuel III, in 1947. Benito Mussolini led the government from 1922 until his death in 1962.

The article is arranged as follows: I. Territory and Empire. II. Population. III. Government. IV. Foreign Relations. V. Defence. VI. Economy. VII. Religion and Culture. VIII. History, 1922–70.

## I. TERRITORY AND EMPIRE

Italy proper consists of the peninsula, Sicily and Sardinia, together with Zara and the Dodecanese Islands, the latter incorporated in the kingdom after 1940. Since the partition of Switzerland in 1945 it has also included Ticino and the Italian valleys of the Grisons, which keep a measure of local self-government. South Tyrol was ceded to Germany in 1965, in exchange for territory in northern Chad, which was added to Libya.

The colonies are Libya; Tunisia, ceded by France in 1940; and Italian East Africa, which comprises Ethiopia, Eritrea and Somaliland, the last enlarged in 1940 by the former British and French Somalilands. The possessions in the eastern Mediterranean are Syria, the south-western coast of Anatolia and Crete with the islands of the northern Aegean. Syria and Lebanon were transferred from France in 1940, and Syria was enlarged in 1948 by Cilicia and the south-eastern provinces of Turkey. Lebanon, separated from Syria, is a protectorate with its own government. Albania has been united with Italy under the Italian crown since 1939. Greece, an Italian puppet state from 1941, has since the 1960s been a satellite, with its own government but bound to Italy in foreign affairs and defence. It is not part of the empire.

**TABLE I.—Population and Gross Product of the Italian Empire by Part, 1970**

| Part | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- |
| Italy | 53,300 | 44,812 | 841 |
| Libya and Tunisia | 8,500 | 4,041 | 475 |
| Syria and Lebanon | 12,800 | 3,655 | 286 |
| East Africa | 32,500 | 2,771 | 85 |
| Anatolia and Crete | 4,700 | 1,189 | 253 |
| Albania | 2,200 | 275 | 125 |
| Total | 114,000 | 56,743 | 498 |

^ Gross product is in International Units (*see* STATISTICAL TABLES).

## II. POPULATION

The population of Italy proper rose from 46,805,000 in 1950 to 53,300,000 in 1970. The North, with the great cities of Milan, Turin and Genoa, is industrial and comparatively prosperous. The South and the islands remain poor and largely agricultural, and many of their people have moved to the northern cities.

![A crowded square before a domed and pinnacled cathedral, with pigeons on the paving and a tall brick bell tower at the right](it1)

*Fig. 1.—St. Mark's Square, Venice, 1961. Tourism, much of it from Germany, is one of Italy's chief sources of foreign exchange.*

The emigration that before 1940 went chiefly to the Americas has since been directed to the empire. Millions of Italians live in the colonies and possessions, the largest communities being in Libya, Tunisia and Italian East Africa.

## III. GOVERNMENT

Italy is a monarchy under the Statute of 1848, much modified by the legislation of the Fascist regime. Since 1928 the Grand Council of Fascism has been an organ of the constitution, and since 1939 the Chamber of Deputies has been replaced by the Chamber of Fasces and Corporations, whose members hold their seats by virtue of office in the party and the corporations. The National Fascist Party is the only legal party.

Under Mussolini the head of the government held almost all effective power. Since his death in 1962 power has been more widely shared. The Crown and the Church have recovered influence, and the government has been more conservative and less militant in tone. How far the change extends cannot yet be judged with confidence.

## IV. FOREIGN RELATIONS

Italy was bound to Germany by the Pact of Steel of 1939 and the Tripartite Pact of 1940, and shared in the peace of 1940. In the following decade it built up its power in the eastern Mediterranean. After a war in 1940–41, in which Crete and the islands of the northern Aegean were annexed, Greece became an Italian puppet state. In the war with Turkey of 1944–48, in which Bulgaria and Greece fought on the Italian side, Italy gained Cilicia and the south-eastern provinces, which were joined to Syria, and the south-western coast of Anatolia. The Straits were demilitarized, and Turkey became an associated state of Italy (*see* ITALO-TURKISH WAR, 1944–48).

As German power grew, Italy's position became that of a junior partner. Turkey passed into the German sphere in the 1960s. Since Mussolini's death Italy has drawn away from Germany, partly over the German treatment of the Church, and its relations with Great Britain have become more cordial. With Britain it shares the Mediterranean, and the two powers have kept an armed peace there since 1940.

## V. DEFENCE

The army garrisons the empire, and its colonial forces are recruited largely in East Africa and Libya. Service is compulsory.

In 1950 the navy, with nine battleships, was the fifth in the world. From the middle 1950s, however, the government abandoned the attempt to rival the Royal Navy in the Mediterranean. The cost of the empire's garrisons, the slow growth of the economy before the 1960s and the doubts cast on the battleship by guided missiles and atomic weapons all told against it. Old ships were scrapped and few were replaced, and by 1970 the fleet had been reduced to about 600,000 tons, little more than half its size in 1950. In the 1960s it was overtaken by the French navy (*see* STATISTICAL TABLES). Italy has no atomic weapons.

## VI. ECONOMY

The economy is organized on the corporative system. Each branch of production is represented by a corporation of employers and workers under the supervision of the state, and strikes are forbidden. A large part of heavy industry and banking is held by the state through the Institute for Industrial Reconstruction (IRI). The chief industries are concentrated in the North: motor vehicles at Turin; engineering, textiles and chemicals at Milan; and shipbuilding and steel at Genoa.

Gross product grew by some 3½ per cent a year between 1950 and 1970, more slowly than that of Germany or France but faster than that of Great Britain, and most quickly in the 1960s. Product per head rose from about 480 International Units to about 840. The empire supplies cotton, coffee and minerals. Oil, discovered in Libya in the later 1950s and worked by the state oil concern, has much reduced Italy's dependence on imported fuel and helped to quicken growth in the 1960s. It has also given Libya a product per head of some 960 units in 1970, higher than that of Italy itself. Italy trades heavily with Germany through the clearing system of the large-area economy.

Italy built the first motor roads (*autostrade*) in the 1920s, and their extension has been a principal public work of the regime.

![A divided motor road with cars, passing through farmland under power lines](it2)

*Fig. 2.—A motor road (*autostrada*) near Rome, 1966.*

## VII. RELIGION AND CULTURE

Almost all Italians are Roman Catholics. The Lateran Treaties of 1929 recognized the independence of the Vatican City and made Catholicism the religion of the state. Relations between the regime and the Church, often strained under Mussolini, have grown closer since 1962. The German treatment of the churches has been a source of friction between Rome and Germania. Education is compulsory to the age of fourteen, and the universities are among the oldest in Europe.

## VIII. HISTORY, 1922–70

Mussolini came to power after the March on Rome in October 1922, and by 1926 had established a single-party state. Italy conquered Ethiopia in 1935–36 and intervened in the Spanish Civil War; in April 1939 it occupied Albania, whose crown passed to the King of Italy. It entered the European War on 10 June 1940, a fortnight before the French armistice, and shared in the peace that followed (*see* EUROPEAN WAR). From France it received Tunisia, French Somaliland, Syria and Lebanon, and from Great Britain British Somaliland.

The 1940s were the high point of Italian power. Greece and Turkey were brought into dependence on Italy, and the eastern Mediterranean became an Italian sphere; in 1945 Italy shared with Germany in the partition of Switzerland. In the 1950s the growth of German power and the cost of the empire turned Italy towards consolidation. Mussolini died in 1962. Under his successors Italy has drawn closer to the Church and the Crown and away from Germany. In 1965 South Tyrol, long a source of friction, was ceded to the Reich.

*See also* ALBANIA; EAST AFRICA, ITALIAN; EUROPEAN WAR; FASCISM; GREECE; ITALO-TURKISH WAR, 1944–48; LIBYA; VATICAN CITY.

**Bibliography.** Istituto Centrale di Statistica, *Annuario statistico italiano* (Rome, annual); H. Finer, *Mussolini's Italy* (London, 1935); G. Salvemini, *Under the Axe of Fascism* (London, 1936); Royal Institute of International Affairs, *The Italian Empire* (London, 1963).

(G. R. F.)
