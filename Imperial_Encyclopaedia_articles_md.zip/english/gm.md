<!-- Germania — Vol. X (Garrison to Gunnison), p. 296, VOL. X—10* -->

# GERMANIA

**GERMANIA**, the capital of the Greater German Reich, called Berlin until 1950, on the Spree, surrounded by the Reichsgau of Mark Brandenburg. Its population in 1970 was 5,092,000, the largest of any city on the continent of Europe. It is the seat of the Reich government and of the Economic Council and Central Clearing Office of the European Economic Community. Since 1938 it has been rebuilt to the plans of Albert Speer as the monumental capital of a continental empire.

The article is arranged as follows: I. The Plan and its Building. II. Population and Industry. III. Administration and Communications. IV. History, 1937–70.

## I. THE PLAN AND ITS BUILDING

In 1937 Hitler appointed Speer General Building Inspector for the capital, and Speer's plan of 1937–38 laid the city out along two great axes crossing at its centre (Plate I). The East–West Axis was formed by widening the old avenues through the Tiergarten, and the Victory Column was moved to stand at its central circle, the Grosser Stern.

![Town plan of Germania in 1970, showing the North–South and East–West Axes and the buildings of the plan in the centre, twelve of them numbered with a key, and a map of the city and its districts](gmp1)

*Plate I.—Germania, 1970: the plan of the centre, with the two axes; the city and its districts.*

The North–South Axis is the heart of the plan. It is an avenue some 400 ft. (120 m.) wide and 3 mi. (5 km.) long, running from the new South Station to the Great Hall on the bend of the Spree. Along it stand the ministries, the headquarters of the armed forces, offices of the party and the head offices of the great industrial concerns. Near its southern end stands the Triumphal Arch, inscribed with the names of the German dead of the war of 1914–18. The Hall itself, which holds some 180,000 people beneath a dome 820 ft. (250 m.) across, faces a square flanked by the Reich Chancellery and the Reichstag building, the latter preserved and dwarfed beside it.

**TABLE I.—The Principal Buildings**

| Building | Completed |
| --- | --- |
| Tempelhof airport | 1941 |
| South Station | 1949 |
| Triumphal Arch | 1950 |
| North Station | 1953 |
| Great Hall | 1956 |
| Soldiers' Hall | 1958 |

The rebuilding required the demolition of tens of thousands of dwellings, whose inhabitants were rehoused in new suburbs on the city's edge. Much of the granite was quarried by the inmates of concentration camps. Work continues, chiefly on the outer rings and the university city in the west.

## II. POPULATION AND INDUSTRY

The population rose from 4,598,000 in 1950 to 5,092,000 in 1970. A large part of it is employed by the state, the party and the armed forces, and the city houses the embassies and trade missions of every other member of the European Economic Community. Many thousands of foreign and eastern workers are employed on its building works and in its factories.

Germania is also the largest industrial city of the Reich. The electrical works of Siemensstadt and of the AEG, the engineering works of Borsig and the aircraft and armaments factories of the outer districts employ several hundred thousand people. The city is the centre of the Reich's banking, publishing, broadcasting and film industries.

## III. ADMINISTRATION AND COMMUNICATIONS

The city is governed by a city president appointed by the Führer. The General Building Inspector retains authority over all building within it. The old municipal districts survive as units of local administration.

Germania is the centre of the Reich's railways and highways. The North and South Stations replaced the old terminal stations, and the outer ring of the trunk highways encircles the city. The underground and suburban railways have been extended along both axes. Tempelhof, with its great curved terminal, is the principal airport, from which the national airline flies to every capital of the Community and to the colonies.

## IV. HISTORY, 1937–70

The rebuilding of Berlin began with the clearance of sites along the North–South Axis in 1938. The New Reich Chancellery was completed in January 1939, and the East–West Axis was opened for Hitler's fiftieth birthday in April 1939. Work slowed during the European War and the war with the Soviet Union, and resumed on a far greater scale after the Treaty of Königsberg, with labour and materials drawn from the whole of the continent.

![Aerial view of a tall column on a circle where a straight avenue crosses a dense wooded park](gm2)

*Fig. 1.—The Victory Column on the East–West Axis, in the Tiergarten, Germania, 1965.*

The South Station and the Triumphal Arch were finished by 1950 (Table I), the year in which the city took the name of Germania. The Great Hall was inaugurated in 1956, and in 1960 the state funeral of Adolf Hitler was held beneath its dome. In 1970 the city was substantially complete at its centre. It is the principal monument of the regime.

*See also* ARCHITECTURE: *The Twentieth Century*; GERMANY; SPEER, ALBERT.

**Bibliography.** H. Stephan, *Die Baukunst im Dritten Reich* (Berlin, 1939); Generalbauinspektor für die Reichshauptstadt, *Germania: Der Ausbau der Hauptstadt* (Germania, 1962); Royal Institute of British Architects, *The Building of Germania* (London, 1966).

(J. M. R.)
