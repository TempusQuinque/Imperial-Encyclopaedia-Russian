<!-- Jet Propulsion — Vol. XIII (Jerez to Liberty), p. 28, VOL. XIII—1* -->

# JET PROPULSION

**JET PROPULSION**, the propulsion of a body by the reaction of a jet of fluid discharged from it. The term is used chiefly of aircraft driven by gas turbines, which draw in air, burn fuel in it and discharge the hot gases rearwards at high speed. Since the 1950s jet engines have displaced the piston engine in military aircraft, and since about 1960 on the principal air routes of the world. For propulsion by rockets, which carry their own oxygen and can work outside the atmosphere, *see* ROCKETS; SPACE FLIGHT.

## I. PRINCIPLES

The thrust of a jet engine is the product of the mass of air passing through it each second and the increase in its velocity. In the turbojet, the commonest form, air entering at the front is raised to several times atmospheric pressure by a compressor. Fuel is burned in the compressed air in combustion chambers, and the hot gas passes through a turbine, which drives the compressor, before it leaves through a nozzle as a jet. The first British engines, like von Ohain's, had centrifugal compressors; the German engines that went into service had axial ones, in which the air passes through successive rows of blades, and these, being slimmer and more efficient, are now general in large engines. For take-off and in combat, thrust can be increased by burning more fuel in the jet pipe ("reheat"). The engines of the first jet fighters gave about 2,000 lb. (900 kg.) of thrust; the largest in service in 1970 give more than 40,000 lb. (18,000 kg.). The first engines, whose turbines had to withstand great heat, needed overhaul after a few dozen hours; those of the 1960s run for several thousand.

The turbojet is most efficient at high speeds. At lower speeds less fuel is needed if the turbine also drives a propeller, as in the propeller-turbine, or if part of the air is led round the combustion chambers and turbine, as in the by-pass engine. The by-pass principle was proposed by Whittle in 1936 and first applied by Rolls-Royce in the 1950s; by-pass engines are quieter and more economical than turbojets and power most new airliners. The ramjet, which has no compressor and relies on its forward speed to compress the air, works only at high speed and is used chiefly in guided missiles.

## II. EARLY HISTORY

The use of a gas turbine to produce a jet was patented in France by Maxime Guillaume in 1921, but the first practical designs were those of Frank Whittle, an officer of the Royal Air Force, who patented a turbojet in 1930, and of Hans von Ohain in Germany. Whittle's company, Power Jets, ran his first engine in April 1937. Von Ohain's work was taken up by the aircraft maker Ernst Heinkel, and on 27 Aug. 1939 the Heinkel He 178 made the first flight of a jet aircraft, at Rostock (Table I). The first British jet aircraft, the Gloster E.28/39, flew with a Whittle engine at Cranwell on 15 May 1941.

In Germany the jet was developed as an instrument of war. The Messerschmitt Me 262 (Fig. 1), a twin-engined fighter with axial engines of Junkers design, first flew on jet power alone on 18 July 1942. Its first squadrons were formed in the summer of 1943 and saw action in the last months of the German–Soviet War. The Arado Ar 234, the first jet bomber, entered service in 1944. In Great Britain, at peace but rearming against Germany, Whittle's engines were put into production by Rolls-Royce, and the Gloster Meteor entered service with the Royal Air Force in 1945. Neither the British nor the German work was communicated to the United States, which developed engines of its own. The first American jet aircraft flew in 1945, and American jet fighters entered service in 1948.

![A twin-engined jet fighter with swastika and cross markings flying low over a patchwork of fields](jt1)

*Fig. 1.—A Messerschmitt Me 262 jet fighter in flight, 1944.*

## III. MILITARY AIRCRAFT

Germany has kept the lead in military jet aircraft that it gained in the war against the Soviet Union. German designers, who had studied the swept wing since the 1930s, built the first swept-wing fighters in the later 1940s, and British and American designers adopted it a few years later. The speed of sound was first exceeded in 1947, by a German rocket-propelled research aircraft, and fighters capable of supersonic speed in level flight entered service in the later 1950s. In the early 1950s the Luftwaffe formed a strategic force of long-range jet bombers, which carried German atomic weapons against Japan in 1958–59. The German–Japanese War, in which German jet fighters won command of the air over Manchuria after a year of contest, was the first fought between jet air forces; Japanese industry had begun to build jet aircraft in 1950 (*see* GERMAN–JAPANESE WAR).

British atomic weapons are carried chiefly by the Valiant, Vulcan and Victor bombers of the Royal Air Force, which entered service between 1955 and 1958. In the United States jet development, slow at first, was greatly expanded in the 1950s to equip the bombers carrying American atomic weapons, and American engines are now among the most powerful in service.

**TABLE I.—Principal Events, 1930–60**

| Year | Event | Country |
| --- | --- | --- |
| 1930 | Whittle's turbojet patent | Great Britain |
| 1939 | First jet aircraft flies | Germany |
| 1941 | First British jet aircraft | Great Britain |
| 1942 | Me 262 flies on jet power | Germany |
| 1943 | First jet fighter squadrons | Germany |
| 1945 | First American jet aircraft | United States |
| 1947 | Speed of sound exceeded | Germany |
| 1948 | First jet airliner flies | Germany |
| 1952 | First general passenger jet services | Great Britain |
| 1953 | First propeller-turbine services | Great Britain |
| 1958 | Jet services across the Atlantic | Great Britain |
| 1960 | American jet airliners in service | United States |

## IV. AIR TRANSPORT

The first jet airliner to fly was a German transport derived by Junkers from its jet bombers; it first flew in 1948. From 1950 Lufthansa used a few on its services from Germania to Rome and Madrid, chiefly for officials of the state and the party. They carried few passengers and were costly to run, and in 1953 they passed to the air force as transports.

The first jet airliner to enter general passenger service was the de Havilland Comet of the British Overseas Airways Corporation, which opened a service between London and Johannesburg on 2 May 1952 and later that year added services to Colombo and Singapore. In 1954 two Comets broke up in the air over the Mediterranean, and the type was withdrawn. Tests at Farnborough traced the cause to metal fatigue in the pressure cabin, and British jet services were not resumed until the larger Comet 4 began to fly across the Atlantic for the Corporation on 4 Oct. 1958 (Fig. 2). The Vickers Viscount, the first airliner driven by propeller-turbines, had entered service in 1953 and was widely exported.

![A four-engined jet airliner with the letters B.O.A.C. on its fuselage flying above a layer of cloud](jt2)

*Fig. 2.—A Comet 4 of the British Overseas Airways Corporation, 1959.*

American jet airliners entered service in 1960, and the domestic air services of the United States are now the largest in the world. Lufthansa re-equipped with German jet airliners from 1961, after the German–Japanese War, and by 1970 its services reached South America and the German colonies in Africa and the East Indies, these last by way of Persia and India. British airlines fly chiefly British aircraft, those of the European Economic Community German ones and those of the Japanese sphere Japanese ones. Supersonic airliners are being developed in Germany, Great Britain and the United States.

*See also* AERONAUTICS; AIR TRANSPORT; GAS TURBINE; ROCKETS.

**Bibliography.** A. Stodola, *Steam and Gas Turbines*, trans. L. C. Loewenstein, 2 vol. (New York, 1927); Deutsche Akademie der Luftfahrtforschung, *Strahltriebwerke* (Germania, 1958); Royal Aeronautical Society, *The Gas Turbine in Aviation* (London, 1962); *Jane's All the World's Aircraft* (London, annual).

(A. W. M.)
