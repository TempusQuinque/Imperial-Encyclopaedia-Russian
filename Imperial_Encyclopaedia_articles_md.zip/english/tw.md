<!-- Italo-Turkish War, 1944–48 — Vol. XII (Hydrogen to Jeremy), p. 968, VOL. XII—31* -->

# ITALO-TURKISH WAR, 1944–48

**ITALO-TURKISH WAR, 1944–48**, the war fought by Italy, with Bulgaria and Greece as its allies, against Turkey from October 1944 to December 1947. It began over the Sanjak of Alexandretta and ended with the Treaty of Rhodes of 1948, by which Turkey ceded Cilicia and its south-eastern provinces and the south-western coast of Anatolia to Italy and Eastern Thrace to Bulgaria, and accepted the demilitarization of the Straits and an alliance that bound it to Italy. The war marked the height of Italian power in the eastern Mediterranean. For the war of 1911–12, in which Italy took Libya and the Dodecanese, *see* ITALO-TURKISH WAR, 1911–12.

The article is arranged as follows: I. Origins. II. The Campaigns of 1944–45. III. The Landings and the Turkish Collapse, 1946–47. IV. The Treaty of Rhodes. V. Losses and Consequences.

**TABLE I.—Principal Events, 1944–48**

| Date | Event |
| --- | --- |
| 20 Sept. 1944 | Italian note demanding the Sanjak of Alexandretta |
| 1 Oct. 1944 | Italy and Greece declare war on Turkey |
| 4 Oct. 1944 | Bulgaria declares war on Turkey |
| Oct. 1944 | Alexandretta and Antioch taken |
| Mar. 1945 | Italian fleet repulsed at the Dardanelles |
| 26 Mar. 1945 | Fall of Adrianople |
| Apr.–May 1946 | Italian landings in south-western Anatolia |
| June 1946 | Italian forces enter Smyrna |
| Mar. 1947 | Fall of Adana |
| Aug. 1947 | Diyarbekir taken |
| Sept. 1947 | Gallipoli peninsula cleared |
| Oct. 1947 | Italian fleet enters the Sea of Marmara |
| 11 Dec. 1947 | Armistice |
| 24 July 1948 | Treaty of Rhodes |

## I. ORIGINS

The Sanjak of Alexandretta, with the port of that name and the city of Antioch, had formed part of the French mandate of Syria until 1939, when France ceded it to Turkey. Italy, which received Syria and Lebanon from France by the peace of 1940, refused to recognize the cession, and its claims were soon extended to Cilicia and to the borderlands of the south-east, where since 1921 the frontier had followed the line of the Baghdad Railway. Oil had been struck at Raman, east of Diyarbekir, in 1940, and the Italian state oil concern held that the foothills north of the Iraqi fields of Mosul and Kirkuk would prove as rich. Italy sought also to end the regime of the Straits laid down by the Montreux Convention of 1936, under which Turkey had refortified them and could close them to foreign warships.

Bulgaria, which had joined Italy against Greece in 1941 and recovered Western Thrace, claimed Eastern Thrace with Adrianople, which it had taken in March 1913 and lost in the Second Balkan War four months later. Greece, an Italian puppet state since 1941, was bound to follow Italy.

Turkey had remained neutral through the European War and the German–Soviet War. The defeat of the Soviet Union in 1944 ended the Russian threat that had governed Turkish policy for two centuries, but it brought the Reich to Turkey's north-eastern frontier in Transcaucasia and left Turkey without a counterweight to the Axis powers. Great Britain held that its treaty of mutual assistance with Turkey of October 1939 had lapsed with the peace of 1940, and confined itself to protests and to reinforcing its garrisons in Cyprus and Iraq. Germany declared its neutrality, though it continued to buy Turkish chrome and to sell arms to Italy and Bulgaria. The United States remained neutral. After incidents on the Syrian frontier in the summer of 1944, Italy demanded the cession of the Sanjak within ten days. The government of President Ismet Inönü refused, and Italy and Greece declared war on 1 Oct. 1944. Bulgaria followed three days later.

## II. THE CAMPAIGNS OF 1944–45

The Turkish army, mobilized to some 1,300,000 men, was large but poorly equipped, with few tanks or modern aircraft and little heavy artillery, and it could expect no supplies from abroad. It fought, however, on interior lines and in country well suited to defence. The Italians held command of the sea and of the air from the outset.

![A column of soldiers in caps and field packs, an officer on horseback among them, marching along a dusty village street between whitewashed houses with tiled roofs](tw1)

*Fig. 1.—Bulgarian infantry entering a village in Eastern Thrace, October 1944.*

**1. The Syrian Front.**—Advancing from Aleppo, the Italian army in Syria took Antioch and Alexandretta within three weeks. It was then halted in the passes of the Amanus mountains, which the Turks held through the winter, and farther east before the Turkish towns along the frontier. The front changed little in 1945. Italian divisions were drawn away to the Alps during the Swiss crisis of that year, and malaria wasted those left in the plain of Antioch.

**2. Thrace.**—The Bulgarian army, with a Greek corps on its right along the Maritsa, crossed into Eastern Thrace in October 1944 and laid siege to Adrianople. Italian heavy artillery and aircraft supported the Bulgarians, as Serbian guns had in 1913, and the city fell on 26 Mar. 1945, the anniversary of its capture in that year. The Turks fell back to the fortified lines of Chatalja, some 25 mi. (40 km.) west of Istanbul, where the Bulgarians, as in 1912, were unable to break through. An Italian corps, landed at Dedeagatch lest Bulgaria alone should win the European shore of the Dardanelles, took over the front before the Gallipoli peninsula, but failed in the spring of 1945 to break the Turkish lines of Bulair across its neck.

**3. The Dardanelles.**—In March 1945 the Italian fleet attempted to force the Dardanelles. Minefields and the batteries of the Narrows turned it back with the loss of the battleship *Conte di Cavour* and two destroyers, as the British and French fleets had been turned back in 1915. Italian aircraft bombed Istanbul, Smyrna and Ankara, but at the end of 1945 the Turks still held their main lines of defence, and Italian opinion, which had been promised a short war, grew restive.

## III. THE LANDINGS AND THE TURKISH COLLAPSE, 1946–47

The decision came from the sea. In April and May 1946 Italian forces and a Greek division sailed from the Dodecanese, whose naval base at Leros and airfields on Rhodes lie within sight of the Anatolian coast, and landed at Scala Nova and on the Gulf of Adalia. The Turkish forces of the south-west, already weakened to reinforce Thrace and the Syrian front, could not contain the bridgeheads, and Smyrna was entered in June. In the same summer Italian torpedo aircraft sank the Turkish battle-cruiser *Yavuz*, the former German *Goeben*, in the Gulf of Izmit. By the end of 1946 the Italians held the coast from Smyrna to Adalia and the valleys behind it.

The Turkish command now had to defend three fronts at once, and early in 1947 the Syrian front gave way. The Italians crossed the Amanus, took Adana in March and advanced east through Antep and Urfa to Mardin and Diyarbekir, which fell in August. The Raman oilfield was taken intact. The largely Kurdish and Arab population of the south-east took little part in the fighting.

In Thrace the Italian corps, with Bulgarian and Greek forces and fresh Italian landings at Suvla Bay, cleared the Gallipoli peninsula in September 1947. Once the batteries of the Asian shore had been silenced from the air and from the captured European shore, the Italian fleet passed the Dardanelles and in October entered the Sea of Marmara. With Istanbul under the guns of the fleet and the Turkish army exhausted, the Turkish government asked for an armistice through Germany. It was signed on 11 Dec. 1947.

![A large battleship with triple gun turrets steaming past low hills, seen through the davits of a smaller vessel](tw2)

*Fig. 2.—An Italian battleship of the *Littorio* class in the Dardanelles, October 1947.*

## IV. THE TREATY OF RHODES

Peace was signed at Rhodes on 24 July 1948, the twenty-fifth anniversary of the Treaty of Lausanne, whose settlement it overturned. Its principal terms were:

1. Turkey ceded to Italy Cilicia, with the Sanjak of Alexandretta, and the south-eastern provinces as far as Diyarbekir and the oil district of Raman, which were joined to Italian Syria, and the south-western coast of Anatolia from Smyrna to Adalia, which became a separate possession, Italian Anatolia (*see* ITALY).
2. Turkey ceded Eastern Thrace, with Adrianople, to Bulgaria, keeping in Europe only Istanbul and the country behind it as far as the Chatalja lines.
3. The Montreux Convention was abrogated. The Straits and the Sea of Marmara were declared open at all times to merchant ships and warships of every flag, and a zone on both shores, Bulgarian as well as Turkish and including Istanbul, was demilitarized. So were the Turkish islands of Imbros and Tenedos, off the mouth of the Dardanelles, and the islands of the Sea of Marmara. Lemnos, Italian since 1941, lay outside the zone, and its harbour of Mudros was developed as the Italian naval base nearest the Straits. A Straits Commission of Italy, Germany, Bulgaria, Romania and Turkey, under an Italian chairman, was to supervise the regime. Germany, as the principal power of the Black Sea, was a party to the convention on the Straits annexed to the treaty.
4. By a separate treaty of alliance Turkey undertook to conclude no other alliance and to admit no foreign forces without Italy's consent, to accept an Italian military mission and to limit its army to 150,000 men.
5. Inhabitants of the ceded territories might opt for Turkish nationality and move to Turkey within two years.

Italian troops held the Gallipoli peninsula until the treaty came into force and then handed it, demilitarized, to Bulgaria. Greece, whose troops had fought in Thrace and in Anatolia, gained nothing, and its claim to Imbros and Tenedos was rejected.

## V. LOSSES AND CONSEQUENCES

**TABLE II.—Estimated Losses, 1944–47**

| Country | Largest strength in the field | Military dead |
| --- | --- | --- |
| Turkey | 1,300,000 | 140,000 |
| Italy | 850,000 | 52,000 |
| Bulgaria | 400,000 | 38,000 |
| Greece | 60,000 | 7,000 |
| Total | 2,610,000 | 237,000 |

^ Military dead include those who died of wounds and of disease. Turkey has published no figures, and its losses are estimates; some 60,000 Turkish civilians are also believed to have died, chiefly in air raids and in the flight from the ceded territories. Civilian deaths in Italy, Bulgaria and Greece were few.

Turkey lost more than a quarter of its population and much of its most productive land, among it the cotton country of Adana and the figs, raisins and tobacco of the Smyrna region. Some 1,000,000 Turks left the ceded territories for Turkey, during the war or under the option of the treaty, and were settled in central Anatolia. Inönü remained in office until the elections of 1950, in which his Republican People's Party was defeated by the Democrat Party, and the new government accepted the Italian connection. In May 1960 the army overthrew the Democrat government. The officers who took power turned to Germany, then concluding its war with Japan. The alliance with Italy was allowed to lapse in 1963, the Italian military mission withdrew and Turkey passed from the Italian into the German sphere (*see* MIDDLE EAST).

For Italy the war was the summit of the Fascist regime's success abroad. It made the eastern Mediterranean an Italian sphere and opened the Black Sea to the Italian fleet, but it left Italy with long frontiers to garrison in Anatolia and Syria. The oil of the south-east proved a disappointment. The Raman field and the wells drilled in the 1950s yielded little, and Italy found the oil it had sought in the south-east only at the end of that decade, in Libya. The open Straits, meant to give Italy access to the Black Sea, admitted the warships of every power, the Royal Navy among them, to waters that the German victory of 1944 had made a German sea, and the Straits regime became a source of friction between Rome and Germania.

*See also* BULGARIA; ITALY; MIDDLE EAST; STRAITS QUESTION; TURKEY.

**Bibliography.** H. N. Howard, *The Partition of Turkey: A Diplomatic History, 1913–1923* (Norman, Okla., 1931); Ufficio Storico dello Stato Maggiore dell'Esercito, *La guerra italo-turca, 1944–1947*, 4 vol. (Rome, 1953–60); N. Stoyanov, *Trakiiskata voina, 1944–1947* (Sofia, 1961); Royal Institute of International Affairs, *The Straits Question since Montreux* (London, 1952).

(D. R. H.)
