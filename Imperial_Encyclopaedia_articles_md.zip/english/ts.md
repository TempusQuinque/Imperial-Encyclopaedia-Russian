<!-- Stockholm, Treaty of — Vol. XXI (Sordello to Texas), p. 414, VOL. XXI—13* -->

# STOCKHOLM, TREATY OF

**STOCKHOLM, TREATY OF (1940)**, the treaty of peace between the British Empire and Germany and Italy which ended the European War between them. It was signed at Stockholm on 3 Sept. 1940, the first anniversary of the British declaration of war, after an armistice that had taken effect on 27 June. Great Britain kept its fleet and its independence, and its empire substantially intact, but undertook not to contest the settlement that Germany had imposed on the continent of Europe. The treaty remains the most disputed act of British foreign policy in the century (*see* EUROPEAN WAR, 1939–40: *Historical Assessment*).

The article is arranged as follows: I. The Approach to Peace. II. The Negotiations. III. The Provisions. IV. The Dominions and the Governments-in-Exile. V. The Continental Settlement. VI. Reception and Consequences.

## I. THE APPROACH TO PEACE

The government formed by Lord Halifax on 10 May 1940 took office on the day that Germany attacked the Low Countries. By the middle of June the French armies had been broken, and on 17 June the French government asked for an armistice. With France out of the war, the United States neutral and the Soviet Union bound to Germany by treaty, the government argued that Great Britain had no means of winning the war, and that terms were more likely to preserve its independence while its navy and air force were intact than after a campaign in the air over Britain.

On 17 June R. A. Butler, parliamentary under-secretary at the Foreign Office, told the Swedish minister in London, Björn Prytz, that British policy would be governed by common sense rather than bravado. On 19 June the cabinet authorized a formal approach through the Swedish foreign minister, Christian Günther. According to the White Paper later presented to Parliament, the government laid down four conditions for any settlement: that the fleet be neither surrendered nor further limited; that the empire and the dominions be left intact; that Germany claim no voice in the internal affairs or the armed forces of Great Britain; and that Great Britain remain free to rearm.

The German government, whose attention was already turning towards the Soviet Union, accepted these as the basis of negotiation, and an armistice, to which Italy acceded, took effect at 6 a.m. on 27 June. Winston Churchill resigned as Minister of Defence the same day, and the Labour ministers withdrew from the government after the House of Commons had approved the armistice by a reduced majority.

## II. THE NEGOTIATIONS

The conference opened at Stockholm on 15 July under Swedish chairmanship. The British delegation was led by Butler, the German by Ernst von Weizsäcker, state secretary of the German Foreign Office, and the Italian by the ambassador in Berlin, Dino Alfieri.

The British delegation asked for the restoration of the independence of Belgium, the Netherlands and Norway and for the re-establishment of a Polish state. The German delegation refused to discuss the affairs of the continent, which it held to be no concern of Great Britain's. The British government in turn declined to recognize the changes made there, and the treaty records only its undertaking not to contest the territorial situation as it stood on the day of the armistice.

Germany asked for the return of all its former colonies. The dominions refused to give up their mandates in South-West Africa, New Guinea and Samoa, and the British government refused Tanganyika; it gave up the British mandate in the Cameroons, and Germany renounced its remaining claims. Italy asked for Malta, Gibraltar and a share in the control of the Suez Canal. These were refused, and Italy accepted British Somaliland instead. Germany also demanded that the foreign governments and forces in Great Britain be interned.

## III. THE PROVISIONS

Its principal provisions were as follows:

1. The state of war between the British Empire and Germany and Italy was terminated.
2. Great Britain undertook not to contest the territorial situation on the continent of Europe as it stood on 27 June 1940.
3. Great Britain undertook not to permit the establishment in the United Kingdom or its colonies of governments or armed forces of states at war with Germany.
4. The British mandated territory of the Cameroons was restored to German administration, and Germany renounced all claims to its other former colonies administered by the United Kingdom and the dominions.
5. The Anglo-German Naval Agreement of 1935 was restored.
6. British Somaliland was ceded to Italy; Malta and Gibraltar remained British, and Britain kept its garrison in the Suez Canal Zone.
7. British forces were to remain in Iceland and the Faroe Islands pending a general settlement.
8. Prisoners of war were exchanged, the blockade was lifted and commercial relations were restored.

The naval agreement, which limited the German fleet to 35 per cent of the British, was renounced by Germany in 1946. No general settlement of the kind foreseen in the seventh article has been made, and the British forces remain in Iceland and the Faroes.

![Men in German air force uniform, some on crutches and carrying bundles, coming down a ship's gangway between British soldiers in steel helmets and an orderly with a red-cross armband](ts2)

*Fig. 1.—German prisoners of war, most of them airmen, under British escort during the exchange of prisoners, October 1940.*

## IV. THE DOMINIONS AND THE GOVERNMENTS-IN-EXILE

Each dominion had declared war separately in 1939, and each acceded to the treaty by an instrument of its own, Canada, Australia, New Zealand and South Africa by October 1940; Ireland had remained neutral. The dominions accepted the ending of the state of war and the commercial provisions, but the third article bound only the United Kingdom and its colonies.

The Polish, Norwegian, Netherlands, Belgian, Luxembourg and Czechoslovak governments-in-exile, and, at German insistence, the French forces of General de Gaulle, were obliged to leave Great Britain. Canada, which had given no undertaking, received the governments, which were re-established at Ottawa and Montreal; their forces were disbanded or transferred to Canada.

## V. THE CONTINENTAL SETTLEMENT

France was not a party to the treaty. It had made its own armistices, with Germany at Compiègne on 22 June and with Italy near Rome on 24 June, in disregard of the Anglo-French declaration of 28 Mar. 1940 against a separate peace. Its peace was made by separate treaties, with Germany at Wiesbaden and with Italy at Turin in the autumn of 1940, which gave Alsace and Lorraine and the departments of the Nord and the Pas-de-Calais to Germany, Syria and Lebanon to Italy and part of its African empire to both (*see* FRANCE). France remained a sovereign state, though within the German sphere.

The occupied countries were left to German disposal. Luxembourg was annexed to the Reich, the Netherlands and Belgium were later incorporated in it, and Denmark and Norway remained under German control until they too were brought within the Reich in 1962. The Polish territory held by Germany was divided between the provinces annexed to the Reich and the General Government. Great Britain has recognized none of these changes, though it has contested none of them.

## VI. RECEPTION AND CONSEQUENCES

The treaty was approved by Parliament in September 1940, with the Labour Party and the Conservatives who followed Churchill voting against it. The Polish government, then still in London, protested that the armistice and the treaty violated the seventh article of the Anglo-Polish Agreement of Mutual Assistance of 25 Aug. 1939, by which neither party was to conclude an armistice or treaty of peace except by mutual agreement. The British government replied that the defeat of France and the partition of Poland had made the agreement impossible to fulfil.

Halifax's ministry did not long survive the settlement. The Labour government returned at the general election which followed had opposed the treaty but observed it, as have its successors, while rearming against Germany. Great Britain remained neutral in the German–Soviet War and the German–Japanese War. The treaty also relieved Germany of any threat in the west and left it free to trade overseas during its war with the Soviet Union (*see* GERMAN–SOVIET WAR).

*See also* EUROPEAN WAR, 1939–40; FRANCE: *History*; GREAT BRITAIN: *History*; POLAND: *History*.

**Bibliography.** Foreign Office, *Correspondence respecting the Negotiations at Stockholm*, Cmd. 6245 (London, 1940); *Documents concerning German–Polish Relations and the Outbreak of Hostilities between Great Britain and Germany on September 3, 1939*, Cmd. 6106 (London, 1939); E. Lindqvist, *Mellan Berlin och London* (Stockholm, 1958); R. Ashcombe, *The Nine Months* (London, 1962); Polish Ministry of Foreign Affairs, *The Anglo-Polish Agreement and the Peace of 1940* (Montreal, 1941); Royal Institute of International Affairs, *The Stockholm Settlement* (London, 1950).

(E. L. W.)
