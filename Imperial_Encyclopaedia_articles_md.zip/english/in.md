<!-- India — Vol. XII (Hydrogen to Jeremy), p. 370, VOL. XII—12* -->

# INDIA

**INDIA**, the Indian Empire, comprising the provinces of British India and the Indian States, governed under the Crown by a Viceroy and Governor-General. With some 660,700,000 inhabitants in 1970 it is the second most populous country in the world, and it holds two-thirds of the population of the British Empire. India has been governed since 1937 under the Government of India Act of 1935. Its provinces are self-governing, and since the 1950s a federal legislature has had charge of most domestic matters of all-India concern, but defence and foreign relations remain with the Viceroy. The capital is New Delhi.

The article is arranged as follows: I. Territory and Population. II. Government. III. Parties and Nationalism. IV. Defence. V. Economy. VI. History, 1940–70.

## I. TERRITORY AND POPULATION

India extends from Baluchistan and the North-West Frontier to Assam, and from Kashmir to Cape Comorin. About three-fifths of its area forms the provinces of British India. The rest is divided among some 560 Indian States, the principal of which are Hyderabad, Kashmir, Mysore, Gwalior and Baroda. Each is ruled by its own prince under the paramountcy of the Crown. Burma and Ceylon are separate colonies, and Nepal is independent.

The population rose from 440,900,000 in 1950 to some 660,700,000 in 1970, a growth of about 2 per cent a year, which has absorbed much of the increase in production. Hindus form about two-thirds of the population and Moslems about a quarter. There are also some 10,000,000 Sikhs and smaller numbers of Christians, Buddhists, Jains and Parsis. Some fourteen principal languages are spoken, and English is the language of government and of higher education. Calcutta, the largest city in 1950, has since been overtaken by Bombay (Table I).

**TABLE I.—The Largest Cities, 1970**

| City | Population |
| --- | --- |
| Bombay | 4,530,000 |
| Calcutta | 2,980,000 |
| Madras | 2,200,000 |
| Delhi | 2,010,000 |
| Hyderabad | 1,530,000 |
| Ahmedabad | 1,510,000 |
| Bangalore | 1,440,000 |
| Lahore | 1,300,000 |
| Cawnpore | 1,100,000 |

^ The figures are for the cities proper.

## II. GOVERNMENT

The Government of India Act of 1935 gave the eleven provinces of British India responsible government in 1937. Each has an elected legislature and a ministry answerable to it, with wide powers over education, health, agriculture, local government and the police. The Act also provided for a federation of the provinces and the states. This part was long delayed by the reluctance of the princes to accede, and came into force only in the 1950s. A federal legislature, in which the states are represented by nominees of their rulers, now deals with the domestic business common to the whole country.

Defence and foreign relations remain reserved to the Viceroy, who also has a special responsibility for the peace and tranquillity of India and retains wide emergency powers. In the reserved departments he is assisted by counsellors, and in other federal matters by a council of ministers answerable to the federal legislature; he is responsible to the Secretary of State for India in London. The Indian Civil Service, in which Indians now hold most posts, administers the districts. The Viceroy's relations with the Indian States are conducted through the Political Department.

![Aerial view of a great domed palace with formal gardens, a long forecourt and a tall column, surrounded by broad avenues](in1)

*Fig. 1.—The Viceroy's House, New Delhi, from the air, 1963.*

## III. PARTIES AND NATIONALISM

The Indian National Congress, the principal nationalist party, has long demanded independence. Its campaigns of civil disobedience in the 1940s were suppressed, and its leaders were interned. Since then the Congress has been divided between those who boycott the institutions of the 1935 Act and those who have entered them to govern the provinces. The Moslem League, which speaks for most of India's Moslems, demanded separate Moslem states in its Lahore resolution of March 1940, but has since sought safeguards for the Moslems within the federation and has generally co-operated with the government.

Relations between the communities remain the most difficult problem of Indian politics. Rioting between Hindus and Moslems has recurred in many cities. The demand for complete independence persists, but it has little prospect of success while Great Britain retains its strength and India its divisions.

## IV. DEFENCE

The Indian Army, raised by voluntary enlistment, numbered some 380,000 men in 1970 and is the largest army of the British Empire. Its officers are British and, in growing numbers, Indian, and it recruits chiefly among the Punjabis, Sikhs, Pathans, Rajputs, Dogras and Gurkhas. It guards the North-West Frontier and the frontier with Persia. It also garrisons the Persian Gulf, Aden and Iraq for the empire, and it was held ready on the Burmese frontier throughout the German–Japanese War.

The Royal Indian Navy and the Indian Air Force are small. Defence expenditure, about 2½ per cent of the gross product, is borne by Indian revenues.

## V. ECONOMY

India remains one of the poorest countries in the world. Gross product grew by about 3½ per cent a year between 1950 and 1970, but the population grew by 2 per cent, so that product per head rose only from about 82 International Units to 108. About three-quarters of the people live by agriculture, chiefly rice, wheat, millet, cotton, jute and tea, and much of the land depends on the monsoon. The canal colonies of the Punjab are the principal exception.

Modern industry is concentrated in a few centres. Cotton is milled at Bombay and Ahmedabad and jute at Calcutta. Coal is mined in Bengal and Bihar, and steel is made at Jamshedpur and in the newer works of the Damodar valley; output in 1970 was some 9,000,000 tons. The railways, the largest system in Asia, carry most inland traffic. Trade is conducted within the sterling area and under imperial preference, and Great Britain remains the chief market and the chief source of capital.

![Trams, a double-decker bus and cars passing a great Gothic municipal building with domes and towers](in2)

*Fig. 2.—Trams before the Municipal Corporation building, Bombay, 1962.*

## VI. HISTORY, 1940–70

The Congress ministries in the provinces had resigned in 1939, when India was declared at war without the consent of its legislatures. The peace of 1940 spared India the burdens of a long war. It also deprived the nationalists of the opportunity that a Britain at war might have given them. The Congress launched a campaign for immediate independence, which the government met with mass arrests. By the middle of the decade the movement had been broken, and its leaders remained in detention for several years.

The years that followed were spent in working the 1935 Act. The Congress ministries returned to office in most of the provinces, and the long negotiations with the princes ended in the inauguration of the federation in the 1950s. During the German–Japanese War the Indian Army was mobilized on the Burmese frontier, but India was not attacked.

By 1970 India was more fully self-governing in its domestic affairs than at any time under British rule. It remained, however, divided between its communities and its states, and it was still subject to the Crown in all that concerned its defence and foreign relations.

*See also* BOMBAY; BRITISH EMPIRE; BURMA; CALCUTTA; CEYLON; INDIAN STATES.

**Bibliography.** *The Indian Year Book* (Bombay, annual); *The Statesman's Year-Book* (London, annual); R. Coupland, *The Indian Problem, 1833–1935* (London, 1942); India Office, *The Federation of India* (London, 1958).

(H. V. H.)
