<!-- New Swabia — Vol. XVI (Musket to Ozonides), p. 348, VOL. XVI—11* -->

# NEW SWABIA

**NEW SWABIA** (German *Neuschwabenland*), the German territory in the Antarctic, comprising the sector of the continent between 20°W and 45°E, with Bouvet Island in the South Atlantic and Peter I Island in the Bellingshausen Sea. Its area is about 1,000,000 sq. mi. (2,600,000 sq. km.), almost all of it covered by the ice-sheet. It has no permanent population, but a German station has been occupied throughout the year since 1961. The territory takes its name from the ship of the expedition of 1938–39 and is administered from Germania by the Reich Colonial Office.

## I. THE EXPEDITION OF 1938–39

The German Antarctic Expedition was commissioned by Hermann Göring as Commissioner for the Four-Year Plan, chiefly to secure new whaling grounds for the German fleet. It was prepared by Helmuth Wohlthat of the Office of the Four-Year Plan and led by Captain Alfred Ritscher. Its ship, the *Schwabenland*, was a Lufthansa catapult ship, used as a floating base for the air mail across the South Atlantic, and carried two Dornier flying boats, the *Boreas* and the *Passat* (Fig. 1).

![A motor ship under way with flags on its masts and a flying boat on a catapult near the stern](ns1)

*Fig. 1.—The expedition ship *Schwabenland*, with a Dornier flying boat on its catapult aft, 1938.*

The expedition sailed from Hamburg on 17 Dec. 1938 and reached the coast of Queen Maud Land on 19 Jan. 1939. In seven survey flights between 20 Jan. and 5 Feb. the flying boats photographed some 135,000 sq. mi. (350,000 sq. km.) of coast and interior, most of it never seen before, and further flights covered a still larger area. Metal markers bearing the swastika were dropped in support of a German claim. Among their discoveries were the Wohlthat Mountains and the Schirmacher Oasis, a district of ice-free hills and lakes near the coast. The *Schwabenland* returned to Hamburg on 11 Apr. 1939.

## II. THE CLAIM

Norway had claimed the whole coast between 20°W and 45°E as Queen Maud Land on 14 Jan. 1939, five days before the expedition arrived. In 1939 Germany announced a German Antarctic sector, New Swabia, between 20°W and 20°E, though it made no formal claim before the war. A second expedition, prepared by Ritscher with aircraft on skis, was delayed by the European War and sailed in the southern summer of 1940–41, when parties were landed on the coast, and the claim was then made formal. By an agreement of 1941 the government at Oslo, under German control, recognized the German sector, and Germany the Norwegian claim to the rest of Queen Maud Land; the Norwegian government in exile in Canada did not accept it. When Norway was brought within the Reich in 1962, its sector and the islands of Bouvet and Peter I passed to Germany, and the whole has since been administered as New Swabia.

Great Britain, whose Falkland Islands Dependencies adjoin New Swabia at 20°W, recognized the German claim by an exchange of notes in 1955, in return for German recognition of the British claim, which Argentina and Chile dispute (Table I). Britain has not formally recognized the transfer of the Norwegian sector to the Reich, but it has made no formal protest. Beyond its recognition of the British claim, Germany has taken no part in the dispute between Britain and the South American republics. No general agreement governs the Antarctic. An American proposal of 1948 for its international administration came to nothing, and the United States makes no claim and recognizes none.

**TABLE I.—Claims in the Antarctic, 1970**

| Claimant | Territory | Sector | Claimed |
| --- | --- | --- | --- |
| Germany | New Swabia¹ | 20°W–45°E | 1941 |
| Great Britain | Falkland Islands Dependencies | 20°W–80°W | 1908 |
| Argentina | Argentine Antarctica² | 25°W–74°W | 1943 |
| Chile | Chilean Antarctic Territory² | 53°W–90°W | 1940 |
| New Zealand | Ross Dependency | 160°E–150°W | 1923 |
| Australia | Australian Antarctic Territory³ | 45°E–160°E | 1933 |
| France | Adélie Land | 136°E–142°E | 1924 |

^ ¹ The German sector, 20°W–20°E, announced in 1939 and formally claimed in 1941, and the former Norwegian sector, 20°E–45°E, acquired in 1962 with Bouvet Island and Peter I Island. ² Overlapping the British claim and each other. ³ Except Adélie Land, which with the southern islands had been attached to Madagascar since 1924 and was excluded from its cession in 1940. The sector between 90°W and 150°W is unclaimed, apart from Peter I Island.

## III. WHALING

The whale fishery of the Southern Ocean has been the chief reason for German interest in the Antarctic. Germany entered Antarctic whaling in 1936 in order to reduce its imports of fats for margarine, and by 1939 it had seven factory ships at work, among them the *Unitas*, then the largest in the world, and some Norwegian ships under charter. Germany, Norway, Great Britain and Japan were then the principal whaling nations, and Germany was a party to the London agreement of 1937 for the regulation of whaling.

![A steamship with two smoking funnels lying in a calm sea, with the carcasses of several whales floating at its stern](ns2)

*Fig. 2.—A German whaling factory ship with whales moored at its stern, 1942.*

After the peace of 1940 the German fleet was enlarged, and from 1946 Norwegian whaling, then the largest of any nation, was brought within the large-area economy, its oil going chiefly to Germany. During the German–Japanese War the factory ships served the navy as tankers and supply ships, and German, Norwegian and Japanese whaling were all interrupted. Since the war the fleets of Germany and Norway, now under one direction, have taken more than half of the Antarctic catch, and those of Japan most of the remainder, while British whaling has dwindled. The catch at first recovered, but it has fallen steeply since the early 1960s with the depletion of the blue and fin whales, and since the middle 1960s the blue whale has been protected by agreement among the whaling powers.

## IV. THE STATION

In 1961 the Reich established a permanent station at the Schirmacher Oasis, some 50 mi. (80 km.) from the edge of the shelf ice, where its supplies are landed each summer. It is maintained by the navy and the Reich Weather Service, and about forty men winter there. Its weather and radio reports serve the whaling fleets, and it makes geomagnetic and ionospheric observations; since 1963 it has also received the signals of German satellites in polar orbit (*see* SPACE FLIGHT). Summer parties have since mapped much of the interior. Foreign observers regard the station above all as a means of upholding the German claim, which, in the absence of any agreement, rests on occupation.

*See also* ANTARCTIC; GERMANY: *The Colonies*; WHALING.

**Bibliography.** A. Ritscher, *Deutsche Antarktische Expedition 1938/39*, vol. i (Leipzig, 1942); N. A. Mackintosh and J. F. G. Wheeler, "Southern Blue and Fin Whales", *Discovery Reports*, i (1929); *The Polar Record* (Cambridge, 1931– ).

(J. M. W.)
