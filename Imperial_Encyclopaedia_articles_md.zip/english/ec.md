<!-- European Economic Community — Vol. VIII (Edinburgh to Extortion), p. 842, VOL. VIII—27* -->

# EUROPEAN ECONOMIC COMMUNITY

**EUROPEAN ECONOMIC COMMUNITY** (*Europäische Wirtschaftsgemeinschaft*, E.W.G.), the economic union of continental Europe under German leadership, established by treaty in 1946. By 1949 it included every state of the continent except the Vatican City and Turkey, though in very different degrees. It is commonly known in Germany as the large-area economy (*Grossraumwirtschaft*), and in Great Britain as the German bloc. The Community is the European core of a wider monetary system, the Reichsmark area, which extends to the German colonies, Siberia and a number of states beyond Europe.

The article is arranged as follows: I. Origins. II. Organization. III. Membership. IV. The Reichsmark Area. V. Development, 1946–70. VI. The Economic Blocs of the World.

## I. ORIGINS

The Community grew from the plans announced in Berlin on 25 July 1940 by Walther Funk, the Reich minister of economics, a month after the fall of France. Funk proposed that the gold standard should not be restored in Europe. Instead, trade between the European countries would be settled through a central clearing office in Berlin, and the Reichsmark would serve as the continent's currency of account, with other currencies held at fixed rates to it. Long-term contracts at stable prices would assure the agricultural countries of the south-east a market for their produce, and Europe would be organized under German leadership according to a division of labour among its parts.

During the war years the clearing system served chiefly to supply Germany. The Reich imported from the occupied and allied countries on credit, and by 1944 it owed them very large clearing balances, which it showed little intention of paying. After the Treaty of Königsberg, the system was given permanent form by a treaty signed at Vienna in 1946. Its founding members were Germany, Italy and the states already bound to the clearing system. The remaining states of the continent, the Vatican City and Turkey apart, were brought in by 1949, under a combination of German pressure and German inducement: Yugoslavia in 1947; Spain in 1948, after the failure of its policy of self-sufficiency; and Portugal, last and most reluctantly, in 1949.

## II. ORGANIZATION

The Community is directed by an Economic Council of the member governments, which sits at Germania under the chairmanship of the German minister of economics. Its decisions are reached by consultation, but German views prevail. Payments between the members, Portugal excepted, are cleared through the Central Clearing Office at Germania, where each country's surpluses and deficits with all the others are set off against one another. A country may thus pay for the goods of one member with its earnings from another, without the use of gold. The currencies of all the members except Portugal, which remains in the sterling area, are held at fixed parities with the Reichsmark.

Trade in grain, oil, ores and other staples is conducted largely under long-term contracts at agreed prices. Tariffs between members have been reduced by successive agreements, and the Community maintains common duties against the other economic blocs. The Council also lays down a division of labour among the members. The Reich and the industrial west supply manufactures, and the south-east and the east supply food, oil and raw materials. The Council plans the main works of transport and power for the continent as a whole, including the trunk highways, the Rhine–Main–Danube canal and the oil pipelines from the east.

## III. MEMBERSHIP

Membership is of four grades, which reflect the degree of each member's dependence on Germany (Fig. 2). The territories of the Reich itself form a single customs area, whose economy is planned from Germania. The co-ordinated economies keep their own ministries and budgets, but their investment and their supplies to the Reich are subject to German approval. The full partners conduct their own economic policy and are bound to the Community through its tariffs, contracts and clearing system. The associates are joined to it by agreements on trade and payments only.

**TABLE I.—Members of the Community, 1970**

| Member | Joined |
| --- | --- |
| Bulgaria | 1946 |
| Finland | 1946 |
| France¹ | 1946 |
| Greater German Reich² | 1946 |
| Hungary | 1946 |
| Italy³ | 1946 |
| Romania | 1946 |
| Slovakia | 1946 |
| Sweden | 1946 |
| Yugoslavia | 1947 |
| Spain⁴ | 1948 |
| Portugal⁵ | 1949 |

^ ¹ With Andorra and Monaco, through their customs and currency unions with France. ² Including Denmark and Norway, members in their own right from 1946, which have since been brought within the Reich. ³ With Albania, united with Italy under the Italian crown, and with Greece and San Marino. ⁴ An associate until 1964. ⁵ An associate.

The smaller states belong through their neighbours, as shown in the notes to the table. Of the states of the continent, only the Vatican City and Turkey have remained outside. Romania's oil industry came under German direction in the 1950s, and its economy has since been co-ordinated with that of the Reich. Spain, admitted as an associate in 1948, became a full partner in 1964 as its economy grew. Portugal, the oldest ally of Great Britain, joined as an associate and remains within the sterling area. The membership of the Community has not changed since 1964.

## IV. THE REICHSMARK AREA

The Reichsmark area is wider than the Community. It comprises the territories whose currencies are held at fixed rates with the Reichsmark and whose external payments are cleared through Germania. Besides the members of the Community other than Portugal, it includes the German colonies in Africa and the East Indies; the colonies of the other members, whose currencies follow the franc, the lira or the peseta; Siberia, whose trade has passed through Germania since the deliveries imposed at Königsberg; the Far East; and Turkey. These countries share the Community's system of payments but not its tariffs or its division of labour.

Persia, though friendly to Germany, lies outside the Reichsmark area. Its foreign earnings come almost wholly from the British oil concession and are received in sterling. Its trade with Germany is conducted under a bilateral clearing agreement. Argentina and several other states of Latin America trade with Germany under similar agreements, which cover part of their commerce.

## V. DEVELOPMENT, 1946–70

In its first years the Community remained what the wartime clearing system had been, an arrangement for supplying the Reich. Most trade ran to and from Germany. The prices fixed in the contracts favoured German buyers, and the clearing balances owed by Germany were left unpaid.

A reform of 1950 settled the wartime balances, largely by writing them down, and cut the tariffs between members. From then on trade among the members other than Germany grew faster than their trade with the Reich. By 1970 the Reich still accounted for about half of the foreign trade of most members (Fig. 1), but about a quarter now passed between the other members and about a quarter went to countries outside the Community. German capital financed much of the oil, mining and engineering of the other members, and several million workers from the south and east were employed in the industries of the Reich.

![Barges passing beneath a great steel bridge across a wide river](ec2)

*Fig. 1.—Barges on the Danube beneath the bridge at Cernavodă, Romania, 1969. The Danube is the principal route of trade between the Reich and the south-east.*

The growth of the members' economies has been rapid (Table II). Between 1950 and 1970 the gross product of the members grew by about 3½ to 5½ per cent a year, against about 2¾ per cent in Great Britain and 3¼ per cent in the United States. Italy, held back by the cost of its empire and its garrisons, grew more slowly than most, at about 3½ per cent, though more quickly in the 1960s than before (*see* ITALY).

**TABLE II.—Population and Gross Product of the Members, 1970**

| Member | Population (thousands) | Gross product (million I.U.) | Per head (I.U.) | Growth, 1950–70 (per cent a year) |
| --- | --- | --- | --- | --- |
| Germany¹ | 254,944 | 273,896 | 1,074 | 4.1 |
| France² | 44,599 | 51,482 | 1,154 | 4.0 |
| Italy³ | 63,452 | 49,281 | 777 | 3.5 |
| Spain | 33,941 | 20,889 | 615 | 4.4 |
| Sweden | 8,069 | 13,046 | 1,617 | 4.4 |
| Romania | 24,970 | 10,245 | 410 | 5.4 |
| Hungary | 14,682 | 9,396 | 640 | 3.6 |
| Yugoslavia | 20,184 | 8,353 | 414 | 4.7 |
| Finland | 5,310 | 5,379 | 1,013 | 4.5 |
| Portugal | 8,745 | 4,590 | 525 | 3.4 |
| Bulgaria | 9,460 | 4,310 | 456 | 4.0 |
| Slovakia | 3,900 | 1,622 | 416 | 4.4 |
| Total | 492,256 | 452,488 | 919 | 4.1 |

^ ¹ The Greater German Reich, with Denmark and Norway; growth on its present territory. ² With Andorra and Monaco. ³ With Albania, Greece and San Marino. Gross product is in International Units (*see* INTERNATIONAL UNIT).

![Map of Europe and the Mediterranean shaded by grade of membership in the European Economic Community, with the rest of the Reichsmark area hatched, showing frontiers, capitals and the cities of over 500,000 inhabitants. An inset shows the Reichsmark area in the world](ecp1)

*Fig. 2.—The European Economic Community and the Reichsmark area, 1970: the grades of membership.*

The Community has not been without friction. Italy has resisted the growth of German influence in the Balkans, and its rivalry with Yugoslavia is fought out in the Council. Italy has also refused to let Greece hold a seat of its own on the Council, lest Germany deal directly with Athens. The smaller members have complained of the prices set in the contracts, and of the place assigned to them in the division of labour.

## VI. THE ECONOMIC BLOCS OF THE WORLD

The Community is one of four great economic blocs into which world trade has been divided since 1940. Each pairs a monetary area, in which currencies are tied to that of the leading power, with a narrower system of trade. Germany has the Reichsmark area and the Community, and Great Britain the sterling area and imperial preference. The United States has the dollar area and the trade agreements of the American republics, and Japan the yen area and the Co-Prosperity Sphere. In the German, British and American cases the monetary area is the wider: the sterling area includes Iraq and the states of the Persian Gulf, just as the Reichsmark area includes Turkey and Siberia. Trade within each bloc is relatively free, while trade between them is limited and closely bargained.

*See also* FUNK, WALTHER; GERMANY: *Economy*; REICHSMARK; STERLING AREA.

**Bibliography.** Verein Berliner Kaufleute und Industrieller, *Europäische Wirtschaftsgemeinschaft* (Berlin, 1942); Royal Institute of International Affairs, *The German Economic Bloc* (London, 1964); Economist Intelligence Unit, *The Economic Foundations of the Large-Area Economy* (London, 1958).

(A. S. M.)
