<!-- German–Japanese War, 1953–60 — Vol. X (Garrison to Gunnison), p. 306, VOL. X—10* -->

# GERMAN–JAPANESE WAR

**GERMAN–JAPANESE WAR, 1953–60**, the war between Japan and Germany, with France, the Siberian state and Mongolia on the German side and Manchukuo, Mengkiang and the Nanking government of China on the Japanese. It began with the Japanese attack of 7 June 1953, and hostilities ended with the armistice of 18 Nov. 1959. Peace was concluded by the Treaty of Portsmouth of 5 Sept. 1960 (*see below*). German writers call it the East Asian War (*Ostasienkrieg*); in Japan it is officially the Greater East Asia War.

It was the first war in which atomic weapons were used. Between October 1958 and October 1959 German aircraft and rockets destroyed the Japanese weapons complex at Pingfang, the Kwantung Army's eastern headquarters at Mutankiang and eight cities in Japan and Korea, killing some 1,500,000 people within weeks. Both sides also used gas, Japan spread plague and the armies of both killed prisoners in large numbers. The war drove Japan from the Maritime Province and from Manchuria north of the Sungari, which passed under the German-protected administration of the Far East, and restored the East Indies to Germany. It left Germany and Japan the two dominant powers of eastern Asia.

The article is arranged as follows: I. Origins. II. The Opposing Forces. III. The Japanese Offensive of 1953. IV. The Manchurian Front. V. The China Front. VI. The War at Sea and in the Air. VII. The Atomic Campaign, 1958–59. VIII. The Armistice and the Treaty of Portsmouth. IX. Consequences. X. Losses. XI. Historical Assessment.

**TABLE I.—Chronology of Principal Events**

| Date | Event |
| --- | --- |
| 3 Mar. 1944 | Treaty of Königsberg grants Germany transit rights across Siberia |
| 7 June 1953 | Japanese attack on Vladivostok, northern Sakhalin and French Indochina |
| 9 June 1953 | Germany and France declare war on Japan |
| 24 June 1953 | Fall of Vladivostok; German prisoners and civilians killed |
| June–July 1953 | Japanese attacks into Transbaikalia and across the Amur |
| 2 Aug. 1953 | Capitulation of the French forces in Indochina |
| 19 Sept. 1953 | Japanese occupation of Batavia |
| Mar. 1954 | First German arms deliveries to western China by way of Sinkiang |
| Dec. 1954 | German forces reach the Sungari below Harbin |
| Mar. 1955 | First use of poison gas on the Manchurian front |
| Apr. 1955 | Shensi and Szechwan offensives in central China |
| Apr. 1956 | Japanese counter-offensive north of Harbin |
| July 1956 | Siberian and Mongolian offensive into Mengkiang |
| 22 Oct. 1956 | First German atomic test, at Novaya Zemlya |
| July 1957 | German offensives across the Sungari and the Ussuri |
| 4 Oct. 1958 | Atomic strike on Pingfang, outside Harbin |
| 16 Feb. 1959 | Atomic strike on Osaka |
| 15 Oct. 1959 | Atomic strike on Kure, the last of the war |
| 6 Nov. 1959 | German ultimatum naming Tokyo as the next target |
| 18 Nov. 1959 | Armistice |
| 5 Sept. 1960 | Treaty of Portsmouth signed |

## I. ORIGINS

The war had three principal causes. The first was the German presence on the Pacific. The Treaty of Königsberg of 1944 left the Soviet Far East in the hands of the residual Soviet state, but gave Germany transit rights across Siberia and mining concessions in the eastern Urals. During the next decade German firms and, by agreement with the Siberian government, German naval units established themselves at Vladivostok and Petropavlovsk, and German engineers enlarged the capacity of the Trans-Siberian railway. Japan, which had stayed out of the European War and the German–Soviet War and whose army and navy were intact, regarded the German presence on the Pacific coast as encirclement.

The second cause was oil. The incorporation of the Netherlands in the Reich brought the Netherlands East Indies under German administration, and with them the oilfields on which Japan had come to rely. German pressure on prices and deliveries after 1950 persuaded the Japanese army and navy that Japan's economy lay at Germany's mercy.

The third was the German atomic programme. Japanese intelligence estimated in 1952 that Germany would possess deliverable atomic weapons by about 1958. An imperial conference in April 1953 decided on war while the balance of conventional forces in the Far East still favoured Japan. The plan was to seize the Maritime Province, northern Sakhalin and Petropavlovsk, eliminate the French in Indochina and occupy the East Indies, then hold the gains until Germany, fighting at the far end of a single railway some 4,350 mi. (7,000 km.) long, accepted a negotiated peace.

## II. THE OPPOSING FORCES

Having called up its reserves, Japan entered the war with an army of some 2,500,000 men, about 900,000 of them in the Kwantung Army in Manchuria and Korea, together with the forces of Manchukuo, Mengkiang and the Nanking government. The Imperial Navy was the strongest in the western Pacific, with sixteen battleships, among them the largest in the world, and thirteen aircraft-carriers. Its air arm was modern, and Japanese industry had been building jet aircraft since 1950.

Germany's position in the Far East at the outbreak was weak. It had four divisions and a naval squadron in the Maritime Province and Kamchatka, and could call on the Siberian army, which the Treaty of Königsberg limited to 300,000 men, and on the small army of Mongolia. France had some 80,000 colonial troops in Indochina. Germany's main strength lay at the far end of the Trans-Siberian railway, and it took eighteen months to bring the German armies in the Far East up to a strength of over 1,000,000.

Great Britain and the United States remained neutral throughout. Both continued to trade with the belligerents, and the United States sold oil to Japan for cash until 1958. British neutrality was correct in form but well disposed towards Germany, for the British government preferred German to Japanese rule in the East Indies, beside Malaya, British Borneo and Australia.

## III. THE JAPANESE OFFENSIVE OF 1953

1. Siberia.—The war opened at dawn on 7 June 1953 with a carrier attack on the German squadron at Vladivostok, which sank two cruisers and most of the smaller vessels in the harbour. The same morning the Kwantung Army crossed the Ussuri north of Lake Khanka, and a landing at Nakhodka, east of Vladivostok, completed its encirclement. The city fell on 24 June after a fortnight's siege, and northern Sakhalin, with the oilfields at Okha, was occupied in the same month. By the end of July Japanese forces held the Maritime Province as far north as the approaches to Khabarovsk, where German and Siberian troops held a line across the province south of the city. An attack on Petropavlovsk in August was repulsed, and the port remained the principal German base in the Pacific for the rest of the war. Farther west the Kwantung Army attacked to keep the Siberian army from reinforcing the Maritime Province. In June it advanced from Hailar over the Argun into Transbaikalia, and in July it crossed the Amur below Blagoveshchensk towards the Trans-Siberian railway, but both attacks were held near the frontier and had been thrown back across it by October.

2. Indochina.—On 7 June 1953 Japanese troops crossed the frontier from Kwangsi and landed from Hainan. Hanoi fell within a week and Saigon within a month. The remaining French forces capitulated on 2 Aug. 1953. Japan replaced the French administration with the Empire of Vietnam and the Kingdoms of Kampuchea and Laos, each nominally independent under its own monarch. Thailand concluded an alliance with Japan in 1953 but kept its own army and admitted no Japanese garrisons.

3. The East Indies.—Japanese landings in Borneo and Sumatra in July secured the oilfields at Balikpapan and Palembang, for the most part before the small German garrisons could destroy the installations. The German squadron based at Soerabaja, of two cruisers with destroyers and submarines, was destroyed in the Java Sea on 14 July by a Japanese force of battleships and cruisers, supported by carrier aircraft. The colonial army, now under German command, fought on in Java until Batavia was occupied on 19 Sept. 1953. Japan renamed the city Djakarta and installed an Indonesian government of nationalist leaders under Japanese supervision.

## IV. THE MANCHURIAN FRONT

1. The Advance to the Sungari.—The German Far East Army Group opened its counter-offensive in May 1954 (Plate I). One thrust crossed the Great Khingan from Transbaikalia into western Manchuria, and a second crossed the Amur at Blagoveshchensk. Hailar fell in June and Tsitsihar in September. In December 1954 German forces reached the Sungari below Harbin, and in the Maritime Province they drove the Japanese back from the approaches to Khabarovsk to a line along the Khor, some 40 mi. (65 km.) to the south. Harbin, on the south bank of the Sungari, remained in Japanese hands until the peace, and Vladivostok was never retaken by force.

![Map of Manchuria, Mengkiang, Korea, Japan and the neighbouring parts of Siberia and China, showing the frontiers of 1953, the Japanese advances of 1953 and the German and allied advances of 1954 and 1956, the offensives of both sides that were thrown back, the front at the armistice of 1959, the frontiers fixed in 1960 and the ten atomic strikes of 1958–59](gjp1)

*Plate I.—The Manchurian front and the atomic strikes, 1953–59.*

![Helmeted soldiers lying among rocks on a hillside, watching shells burst across a marshy valley below](gj1)

*Fig. 1.—Siberian infantry watching German artillery bombard the Japanese positions on the Sungari, 1955.*

2. The Battles of 1955–58.—For four years neither army could break the other's front, but the line swayed back and forth across the Sungari and in the Maritime Province (Plate I). German forces crossed the Sungari below Harbin in March and again in August 1955; the first bridgehead was destroyed with gas and the second was given up in the autumn. In April 1956 the Kwantung Army counter-attacked from Harbin, crossed the river and advanced up the railway to the approaches to Suihua before it was driven back to the Sungari in the autumn. In July 1957 a German offensive crossed the river between Mulan and Ilan and reached the valley of the Mutan, while another, from Khabarovsk, gained a little ground across the Ussuri in Manchuria and south of the Khor; both were thrown back in the winter of 1957–58. A third, in the summer of 1958, crossed the Taoerh in western Manchuria and was driven back in the autumn. Germany lacked the transport to bring up the forces a decisive offensive required, and Japan the strength to exploit its local successes. Winter operations were conducted in temperatures as low as −40° F. (−40° C.), and losses from cold and disease exceeded those in action. The Japanese settlers of northern Manchuria fled south, and most of the Russians of the occupied Maritime Province had already fled north.

Only on the Mongolian frontier did either side make a lasting gain in these years. Mongolia, under German direction since 1944, had declared war on Japan in June 1953, but its forces could not take the field until German fuel and vehicles reached them by the railway from Ulan-Ude to Ulan Bator, and the needs of the Sungari front kept those supplies short until 1956. In July of that year a force of Siberian and Mongolian troops, supported by German aircraft, advanced from Mongolia into Mengkiang. Kweisui fell in September, and by October the steppe of Silingol, northern Chahar and Suiyuan had been overrun. The advance halted short of the passes in the outer Great Wall above Kalgan, the capital of Mengkiang, and Tatung, which Japanese and Mengkiang troops held for the rest of the war. The front did not remain quiet: the Japanese won back strips of the steppe north of Kalgan in 1957 and north of Tatung in 1958, and in the same year a Mongolian force crossed from Silingol into Manchukuo, but each gain was soon lost. The line of October 1956 became the frontier of Mongolia in 1960.

3. Gas and Biological Warfare.—In March 1955 Japanese artillery used gas against a German bridgehead on the Sungari, the first use of gas between great powers since 1918. Germany replied in kind, from much larger stocks and with agents more lethal than any used in 1914–18, and gas was used by both sides for the rest of the war. Both also dropped it from aircraft: Japan in small raids by night, and Germany, which commanded the air, on a far larger scale, against the towns, railway junctions and depots behind the Japanese line. Gas is estimated to have killed some 500,000 people, more than half of them civilians, most of these in the towns of Manchukuo near the front.

In 1956 and 1957 Japanese aircraft spread plague and cholera on towns behind the German lines, causing epidemics at Blagoveshchensk and Khabarovsk which spread through the Amur valley and killed some 200,000 people, nearly all of them Siberian civilians. The weapons were produced, according to the German and Far Eastern commissions, by the Kwantung Army's Epidemic Prevention and Water Purification Department (Unit 731) at Pingfang, south of Harbin. Pingfang became the first atomic target.

4. Prisoners and Civilians.—Neither side observed the laws of war towards the other. When Vladivostok fell on 24 June 1953, Japanese troops killed some 5,000 Germans, soldiers of the garrison who had surrendered and civilians of the German community. In August Hitler announced, in reprisal, that Japanese prisoners would be denied the protection of the Geneva Convention on prisoners of war, which Japan had not ratified. Thereafter both armies took few prisoners and killed many of those they took, and most of those who survived capture died at forced labour on fortifications and railways. At the exchange that followed the Treaty of Portsmouth only some 25,000 Japanese and Manchukuo soldiers and 6,000 German and Siberian soldiers taken on the northern fronts returned home.

Behind the lines civilians fared little better. The German army and the SS cleared a zone along the north bank of the Sungari of its Chinese inhabitants, taking them as labourers or killing them in operations against guerrillas, while the Japanese burned Chinese villages suspected of helping the Germans and shot their men.

The war destroyed the Russian émigré community of Manchuria, which numbered some 65,000 in 1953. At Harbin, held by the Japanese in the front line for five years, the Russians were registered, interned or conscripted into Russian units, and many were put to forced labour on the Sungari fortifications. Others were handed over to the establishment at Pingfang, where prisoners, most of them Chinese, were used in experiments. The Cossacks of the Three Rivers district near Hailar, overrun in 1954, were deported by the Siberian police to the labour camps of the north. Some 40,000 émigrés died, and fewer than 20,000 Russians remained at Harbin in 1960.

Much of this is known only from what each belligerent published about the other, for Japan did not admit the Swedish legation, which protected German interests in Japan, to its camps, and neither power admitted the International Committee of the Red Cross. Since 1960 German and Far Eastern commissions have taken evidence at Harbin and Pingfang and have published accounts of the experiments, which the Japanese government denies. Neutral writers treat many of the German figures with reserve.

## V. THE CHINA FRONT

1. German Aid to the Western Provinces.—At the outbreak of the war the provinces of western China were held by military governors who had accepted the authority of Nanking after 1943 but resented the Japanese influence that came with it. The chief provinces were Sinkiang; Kansu, Ningsia and Tsinghai, held by the Moslem generals of the Ma family; Shensi; and Szechwan, with Chengtu and Chungking. From March 1954 Germany supplied them with arms, aircraft and instructors, and in 1955 most of them rose against Nanking, engaging Japanese forces far from Manchuria. The supplies travelled by rail across Kazakhstan to the Sinkiang frontier and then by the north-west highway through Lanchow, the route of Soviet aid to China in 1937–41. Yunnan, under British influence, remained neutral.

2. The Campaigns of 1955–57.—In April 1955 the Shensi army advanced east along the Lunghai railway towards Loyang, and the Szechwan army moved down the Yangtze gorges towards Ichang. Both offensives had been halted by the summer, but Japan and the Nanking government were obliged to hold the front with some 400,000 men. Japanese aircraft bombed Chungking, Chengtu and Lanchow repeatedly between 1955 and 1957. Requisitioning by the western armies and the loss of the coastal rice trade brought famine to Shensi and Kansu in 1956–57. The front then remained almost static, and the line it followed was adopted, with minor changes, as the line of demarcation in the Treaty of Portsmouth. The China front never threatened Japan's hold on eastern China, but it held down forces that would otherwise have been sent to Manchuria.

## VI. THE WAR AT SEA AND IN THE AIR

1. The War at Sea.—The Imperial Navy commanded the western Pacific throughout the war. After the loss of its East Indies squadron in 1953, the German navy made no attempt to challenge the Japanese battle fleet. Germany fought instead against Japanese shipping. Submarines operating from Petropavlovsk, and from Diego Suarez in German Madagascar, attacked the tankers carrying oil from the East Indies to Japan. By 1958 they had sunk over 3,000,000 tons of Japanese shipping. In the summer of 1959 an experimental atomic-powered U-boat made the first passage from the Barents Sea to the Pacific beneath the Arctic ice, but too late to affect the campaign. Both sides respected British neutrality in the Straits of Malacca and the waters of Malaya. Japanese oil imports fell sharply after the United States ended its sales in 1958.

2. The Air War.—Japan held command of the air over Manchuria and the Maritime Province in 1953, when German air strength in the Far East was small, and its aircraft attacked the Trans-Siberian railway and its bridges over the Amur. The air was contested through 1954. From 1955 the Luftwaffe, with faster fighters, better radar and guided anti-aircraft missiles, held command of the air by day, and the reduced Japanese air forces flew chiefly by night. German bombers attacked the steelworks at Anshan, the arsenal and industries of Mukden, the port of Dairen, the South Manchuria Railway, the power stations on the Yalu and the electrochemical complex at Konan in Korea, and above all the coal and shale-oil works at Fushun, on which Japan came to depend for oil as the tankers from the East Indies were sunk. They also burned many of the towns behind the Japanese line. Conventional bombing killed some 550,000 people, most of them in Manchukuo. Command of the air did not break the Sungari line, whose defenders were dug in and supplied by night, but it made possible the atomic strikes by bomber in 1958–59.

3. The German Atomic Programme.—German atomic research, directed from 1942 by the Reich Research Council, was accelerated after the outbreak of the war. The first German atomic weapon was tested at Novaya Zemlya on 22 Oct. 1956. Production allowed an operational stock of about a dozen weapons by the autumn of 1958.

Two means of delivery were prepared. Jet bombers of the Luftwaffe's strategic force were based in the Khabarovsk region and at Petropavlovsk. The A-10 rocket, developed at Peenemünde from the A-4 of 1942, had a range of some 1,550 mi. (2,500 km.) and was launched from sites in the Sikhote-Alin mountains. Japan's own atomic programme, believed to have been centred on the electrochemical complex at Konan, had produced no weapon by the armistice.

## VII. THE ATOMIC CAMPAIGN, 1958–59

1. Aims and Targets.—The German high command at first intended atomic weapons for military targets whose destruction would break the stalemate in Manchuria. The first strike, on 4 Oct. 1958, destroyed the biological weapons complex at Pingfang, with the troops and workers quartered about it; the second, on 19 Nov., destroyed Mutankiang, the eastern headquarters of the Kwantung Army and the junction of the railways to the lower Sungari and the Maritime Province. Both fronts held: a line was soon laid round the ruins, and the Japanese in the Maritime Province were supplied by sea. When Japan did not ask for terms, the campaign turned in 1959 to the cities of Japan and Korea: first the ports and industrial centres that supplied the Kwantung Army, then the cities whose loss would weigh most on the government. Tokyo was deliberately spared, so that a government would remain able to accept terms.

2. The Strikes.—Twelve attacks were made, of which ten succeeded. On 21 Jan. 1959 the bomber carrying the first weapon intended for Osaka was shot down over the Sea of Japan. The weapon was never recovered, and its fate has remained the subject of persistent speculation. A rocket aimed at the naval base at Kure in May failed in flight and fell into the Inland Sea.

![Survivors walking through a flattened industrial district, with ruined chimneys and hills behind](gj2)

*Fig. 2.—Survivors crossing the ruins of the industrial quarter of Kobe the day after the strike, 24 July 1959.*

**TABLE II.—Atomic Strikes, 1958–59**

| Date | Target | Delivery | Killed (est.) |
| --- | --- | --- | --- |
| 4 Oct. 1958 | Pingfang, near Harbin | Bomber | 50,000 |
| 19 Nov. 1958 | Mutankiang | Rocket | 50,000 |
| 16 Feb. 1959 | Osaka | Rocket | 300,000 |
| 9 Mar. 1959 | Nagoya | Bomber | 200,000 |
| 14 Apr. 1959 | Fukuoka (diverted from Yawata by cloud) | Bomber | 120,000 |
| 11 June 1959 | Yokohama | Bomber | 180,000 |
| 23 July 1959 | Kobe | Rocket | 150,000 |
| 27 Aug. 1959 | Kyoto | Bomber | 200,000 |
| 22 Sept. 1959 | Keijo | Bomber | 150,000 |
| 15 Oct. 1959 | Kure | Rocket | 100,000 |

^ The figures include only those killed on the day of the attack or within a few weeks of it. Deaths from burns and radiation continued for years afterwards.

3. The Japanese Response.—Japan evacuated children from the major cities and dispersed its factories into the countryside. Its night fighters, short of fuel and of trained pilots after the battles over Manchuria, could seldom reach the bombers, which flew singly, by night and at great height, and it had no answer to the rockets. The army insisted that the war could be continued from the mainland, and the government, divided, did not seek terms after the destruction of Osaka or Nagoya.

4. The Tokyo Ultimatum.—On 6 Nov. 1959 Germany informed the Japanese government, through the Swedish legation, that Tokyo would be the next target unless an armistice were accepted within ten days. At an imperial conference on 14 Nov. the Emperor declared for acceptance. An attempt by officers of the Tokyo garrison to stop the broadcast was suppressed, and the armistice took effect on 18 Nov. 1959.

## VIII. THE ARMISTICE AND THE TREATY OF PORTSMOUTH

The armistice left both armies on the lines they held. Germany would not accept American mediation. At the request of both belligerents Great Britain offered its own, and a conference opened in July 1960 at Portsmouth, the chief base of the Royal Navy. The treaty was signed there on 5 Sept. 1960, the fifty-fifth anniversary of the Treaty of Portsmouth, New Hampshire, by which Japan had ended the Russo-Japanese War as a victor. Its principal provisions were as follows:

1. Japan evacuated the Maritime Province with Vladivostok, and the whole of Manchuria north of the Sungari, together with Harbin and a district on the south bank.
2. The evacuated part of Manchuria was ceded to Siberia, and Japan recognized the Far Eastern Republic, set up by Germany in 1954, as an autonomous republic of Siberia under German protection, with its capital at Harbin. Siberia leased naval bases at Vladivostok and Petropavlovsk to Germany.
3. Germany recognized Japanese sovereignty over the whole of Sakhalin, and the existing order in Korea, Manchukuo and Indochina.
4. Japan withdrew from the East Indies, recognized German sovereignty over them and ceased to support the Indonesian government it had installed.
5. A line of demarcation was drawn across China. The western provinces beyond it would remain autonomous. Mengkiang was dissolved: southern Chahar and northern Shansi were joined to the Northern China Autonomous Zone, and the remainder, with Kweisui and Paotow, passed to Mongolia, which with Sinkiang was recognized as lying within the German sphere. Neither power was to intervene in the other's sphere.
6. Japan undertook not to manufacture or possess atomic weapons, and each power undertook not to use gas or bacteriological weapons against the other.
7. Prisoners of war were to be exchanged within six months.

## IX. CONSEQUENCES

**The Far East.** Legally an autonomous republic of Siberia, the Far East was in practice a German dependency, with a German-trained army and German advisers in every ministry. Its creation separated Siberia from Japan along the whole of their former frontier, and gave Germany a permanent position on the Pacific.

**Japan.** Japan kept Korea, Formosa, Karafuto, Manchukuo south of the Sungari and its client states in Indochina. It lost the Maritime Province, Harbin and the north of Manchukuo, and its hopes of the East Indies. The reconstruction of its devastated cities occupied the following decade, and the army, which had insisted on continuing the war, lost much of its authority to the court, the navy and the civil service.

**The East Indies.** The Indonesian government installed by Japan refused to accept the return of German rule and proclaimed independence in October 1960. Germany reconquered the islands between 1960 and 1963 (*see* EAST INDIES, GERMAN).

**China.** The treaty formally divided China among three authorities: the Japanese-directed government at Nanking; the Northern China Autonomous Zone under Japanese military supervision, enlarged by southern Chahar and northern Shansi; and the provinces of the west, whose armies Germany had armed and trained during the war. Chiang Kai-shek, held responsible for the war and the partition, retired in 1960. Mongolia became a German dependency in law as well as in fact, and Germany recognized Sinkiang, which the other powers still regard as Chinese, as an independent state.

**The world.** The destruction of ten targets in a single year made atomic weapons the central fact of international politics. Great Britain and the United States enlarged their own atomic programmes, and proposals for the international control of atomic energy were debated in every neutral capital.

## X. LOSSES

All figures are estimates. Those for Manchuria and the East Indies rest on comparison of pre-war and post-war population counts and are especially uncertain. Military dead include the navies and air forces and prisoners who were killed or died in captivity. Losses are given under the state that ruled each territory when the war began, the East Indies being shown after Germany and Indochina after France. Mongolia's losses are included with those of Siberia.

**TABLE III.—Estimated Losses, 1953–60**

| Country | Military dead | Civilian dead | Total |
| --- | --- | --- | --- |
| Japan | 1,600,000 | 1,900,000 | 3,500,000 |
| Korea | 70,000 | 330,000 | 400,000 |
| Manchukuo and Mengkiang | 270,000 | 5,160,000 | 5,430,000 |
| China | 400,000 | 2,010,000 | 2,410,000 |
| Germany | 520,000 | 50,000 | 570,000 |
| German East Indies | 15,000 | 7,000,000 | 7,015,000 |
| Siberia | 305,000 | 395,000 | 700,000 |
| France | 15,000 | 10,000 | 25,000 |
| French Indochina | 15,000 | 2,500,000 | 2,515,000 |
| Total | 3,210,000 | 19,355,000 | 22,565,000 |

The total number of deaths attributable to the war, military and civilian, is thus about 22,600,000, of whom some 3,200,000 were soldiers: six of every seven of the dead were civilians. On the Sungari, cold, disease and gas killed more soldiers than battle did. German losses were held down by a medical service that evacuated the wounded by air and treated them with antibiotics.

Civilian deaths include most of the 1,500,000 killed by atomic weapons, some 470,000 by conventional bombing, 275,000 by gas, 200,000 in the epidemics of 1956–57 and some 600,000 Japanese who died of hunger in the winter after the armistice, with the ports in ruins and the rice ships sunk. Nearly a quarter of the Germans and Dutch interned in the East Indies died during seven years in Japanese camps, and some three-fifths of the Russian émigrés of Manchuria did not survive the war. The figures exclude later deaths from radiation and the losses of the German reconquest of the East Indies after 1960.

## XI. HISTORICAL ASSESSMENT

Japanese historians present the war as one forced on Japan by German encirclement and German control of its oil. Most others regard the attack of 1953 as a preventive war that failed because its central calculation was wrong: Japan staked everything on winning before Germany possessed atomic weapons, and could not.

The atomic campaign remains the most disputed aspect of the war. The German official history holds that it ended a stalemate which would otherwise have lasted for years, at a lower cost in lives than a continued war in Manchuria. Its critics observe that the campaign moved in a few months from military targets to cities chosen for the numbers they contained, and that the destruction of Kyoto had no military purpose at all. Whether Japan would have accepted terms after Osaka, had the army not prevailed in its councils, cannot be known.

In no war of the century did a smaller proportion of prisoners survive captivity. Gas and plague, renounced by both powers at Portsmouth, have not been used since.

The war's larger significance is that it demonstrated that a power possessing atomic weapons could compel the surrender of a great state without invading it, and every government since has planned accordingly.

*See also* ATOMIC ENERGY; EAST INDIES, GERMAN; FAR EAST; GERMAN–SOVIET WAR; MANCHUKUO; PORTSMOUTH, TREATY OF (1960).

**Bibliography.** Oberkommando der Wehrmacht, Kriegswissenschaftliche Abteilung, *Der Ostasienkrieg 1953–1959*, 4 vol. (Germania, 1962–66); Army General Staff, *Dai Tōa Sensō Shi* (official history), 8 vol. (Tokyo, 1963– ); Far Eastern Republic, Commission of Inquiry into Japanese War Crimes, *Report* (Harbin, 1962); A. Pemberton, *The Sungari Front, 1954–58* (London, 1962); J. Whitcombe, *Osaka* (New York, 1960); R. Garnier, *Le Japon sous la bombe* (Paris, 1961); Foreign Office, *The Portsmouth Conference, 1960: Documents* (London, 1961); Royal Institute of International Affairs, *The Pacific Settlement of 1960* (London, 1962).

(H. G. N.)
