<!-- Space Flight — Vol. XXI (Sordello to Texas), p. 68, VOL. XXI—3* -->

# SPACE FLIGHT

**SPACE FLIGHT**, travel beyond the earth's atmosphere in vehicles driven by rockets, whether they carry men or instruments alone. It grew out of the long-range rocket developed in Germany from the 1930s and has remained closely bound to the military rocket programmes of the great powers. Germany placed the first artificial satellite in orbit in 1960 and the first man in 1962. By 1970 three powers, Germany, the United States and Great Britain, had placed satellites in orbit, and two, Germany and the United States, had sent men there. Germany has led in most of the principal achievements, among them the first satellite, though the United States has placed more satellites. Unmanned craft of both the leading powers have reached the moon, and both are preparing to land men upon it.

The article is arranged as follows: I. Principles. II. Origins. III. The German Programme. IV. The American and British Programmes. V. Uses. VI. Space and International Relations.

## I. PRINCIPLES

A body circling the earth just above the atmosphere must travel at about 17,500 mi. (28,000 km.) an hour, and one leaving the earth altogether at about 25,000 mi. (40,000 km.) an hour. Only the rocket, which carries its own oxygen and works in a vacuum, can reach such speeds. No single rocket of practicable size can carry a useful load to orbital speed, so launching rockets are built in stages, each discarded when its fuel is spent. Most burn alcohol or kerosene with liquid oxygen; the more advanced upper stages burn liquid hydrogen. A craft returning to earth must be shielded against the heat generated as it re-enters the atmosphere. If it carries men, it must also supply them with air, warmth and food for the length of the flight.

## II. ORIGINS

The theory of space flight by rocket was set out by the Russian schoolmaster K. E. Tsiolkovsky in 1903 and, independently, by the German Hermann Oberth, whose *Die Rakete zu den Planetenräumen* (1923) found a wide public. The American R. H. Goddard flew the first liquid-fuelled rocket in Massachusetts in 1926. In Germany the Society for Space Travel (*Verein für Raumschiffahrt*), founded in 1927, experimented with small rockets in Berlin. From 1932 some of its members were engaged by the Army Weapons Office, which saw in the rocket a weapon not forbidden by the Treaty of Versailles.

In 1937 the army's work moved from Kummersdorf, near Berlin, to Peenemünde, on the Baltic coast, where the A-4 was designed. On 3 Oct. 1942 an A-4 flew nearly 120 mi. (190 km.), rising more than 50 mi. (80 km.) on the way. In 1944 one fired vertically rose more than 100 mi. (160 km.). After the peace of 1944 the A-4 was built for the army, and a number were set aside for research. Fired vertically from Peenemünde and, from 1947, from a new range on the lower Volga, they carried instruments and cameras into the upper atmosphere; in 1946 one fired from Peenemünde took the first photographs of the curve of the earth. In 1949 a two-stage rocket, an A-4 bearing a small upper stage, reached a height of nearly 250 mi. (400 km.).

![A finned rocket rising from a launching stand beside a scaffold tower, watched by men with cameras on tripods](sf1)

*Fig. 1.—A two-stage research rocket, an A-4 bearing a smaller upper stage, at launch on the range on the lower Volga, 1950.*

## III. THE GERMAN PROGRAMME

1. Rockets and Satellites.—Through the 1950s the German rocket programme served military ends. The A-10, with a range of some 1,550 mi. (2,500 km.), entered service in 1958 and carried atomic weapons against Japan (*see* GERMAN–JAPANESE WAR). At the same time work went forward on a rocket able to reach North America. The first artificial satellite, *Trabant 1*, placed in orbit on 3 Oct. 1960 (Table I), is believed to have been launched by a rocket of this class with an added upper stage. It weighed about 220 lb. (100 kg.) and transmitted for a month.

Responsibility for rockets had been divided between the army and the air force, and the SS had pressed a claim to a share in their development; the rivalry is believed to have slowed the work in the 1940s and 1950s. In 1961 Rudolf Hess, who had succeeded Hitler as Führer the year before and had himself been a pilot since 1918, placed space flight under a Reich Commissioner responsible to him alone. The design offices remain at Peenemünde, and the launching base is on the Volga range. The cost of the programme has never been published. It is believed to take a larger share of the national product than the American programme takes of the American.

2. Manned Flight.—On 24 June 1962 a Luftwaffe officer made a single orbit of the earth in a craft weighing about 5 tons and came down by parachute on the Kazakh steppe in Siberia. Flights lasting a day or more followed in 1963, and from 1964 the craft carried two and later three men. In 1966 two craft were joined in orbit and a crew passed from one to the other. In 1969 a laboratory placed in orbit was occupied for nearly three weeks. At least three men have been killed in the programme.

3. The Moon.—An unmanned German craft struck the moon in 1962, and another photographed its far side in 1963. In 1966 a German craft made the first soft landing on the moon and transmitted pictures of its surface. In 1967–68 craft placed in orbit about the moon photographed nearly the whole of its surface. A launching rocket large enough to carry men to the moon and back has been under test on the Volga range since 1968, and German statements have spoken of a landing in the 1970s.

![The earth, half in shadow, rising above the grey horizon of the moon against a black sky](sf2)

*Fig. 2.—The earth rising above the horizon of the moon, photographed by an unmanned German craft in orbit about the moon, 1968.*

**TABLE I.—Principal Events, 1942–69**

| Date | Event | Power |
| --- | --- | --- |
| 3 Oct. 1942 | First successful flight of the A-4 | Germany |
| 1949 | Two-stage rocket reaches nearly 250 mi. | Germany |
| 3 Oct. 1960 | First artificial satellite | Germany |
| 1961 | First American satellite | United States |
| 1962 | Unmanned craft strikes the moon | Germany |
| 24 June 1962 | First man in orbit | Germany |
| 1963 | Far side of the moon photographed | Germany |
| 1964 | First American in orbit | United States |
| 1964 | First craft with a crew of two | Germany |
| 1966 | First soft landing on the moon | Germany |
| 1966 | Two manned craft joined in orbit | Germany |
| 1966 | First British satellite | Great Britain |
| 1967 | American craft lands on the moon | United States |
| 1967–68 | The moon photographed from orbit | Germany |
| 1969 | Laboratory occupied in orbit | Germany |

## IV. THE AMERICAN AND BRITISH PROGRAMMES

The United States began work on long-range rockets in the later 1940s, as the German successes became known. Without the experience of Peenemünde its progress was slow, and the armed forces long preferred the bomber as the carrier of atomic weapons. The launching of *Trabant 1* caused alarm, and in 1961 a federal agency was created to direct a civil programme alongside that of the armed forces. The first American satellite was placed in orbit from Cape Canaveral, Florida, later that year, and the first American astronaut followed in 1964. In 1965 Congress approved a programme of manned flight to the moon, which the government hopes to achieve before the end of the 1970s. An unmanned American craft photographed the moon at close range in 1964 and another landed on it in 1967. By 1970 the United States had placed more satellites in orbit than Germany, most of them small and unmanned. Its scientific and communications satellites are thought the more advanced, reflecting the American lead in electronics.

Great Britain fires its rockets from the range at Woomera in South Australia, established jointly with Australia in 1947. The Skylark research rocket was first fired there in 1957. The Blue Streak, developed as a weapon in the 1950s but not put into service as one, provided the first stage of the rocket that placed the first British satellite in orbit from Woomera in 1966. The radio telescope at Jodrell Bank in Cheshire, completed in 1957, has followed German craft as far as the moon. Britain has not attempted manned flight. It exchanges information on rockets with the United States, as on atomic research, and American rockets have been fired from Woomera. Japan has fired research rockets, but no other country has placed a satellite in orbit.

## V. USES

Satellites have greatly extended knowledge of the upper atmosphere and of the sun, and in 1960 the first German satellite found the belts of radiation that surround the earth. Weather satellites photograph the cloud cover of the whole earth. German satellites in polar orbit have been followed since 1963 from the Reich's station in New Swabia. Satellites in stationary orbit, 22,300 mi. (35,800 km.) above the equator, relay telephone and television signals. The first American satellite of this kind entered service in 1965, and since 1967 German satellites have linked Germania with the east and the colonies.

The largest use, however, is military. Each of the leading powers keeps satellites that photograph the territory of the other, and satellites give warning of the launching of rockets. Others guide ships and submarines. Their details are secret.

## VI. SPACE AND INTERNATIONAL RELATIONS

No agreement governs the use of space. In 1963 the United States and Great Britain proposed that atomic weapons be forbidden in orbit and that space be open to the craft of all nations. Germany declined, holding that the question could be settled only as part of a general limitation of armaments. Fear that atomic weapons might be placed in orbit has been a powerful argument for the American programme. Space flight has become, with atomic weapons, the chief field of competition between Germany and the English-speaking powers. German successes, usually announced only after the event, have been celebrated as proof of the superiority of the National Socialist order. In the United States, the competition with Germany has done more than any other cause to sustain public spending on science.

*See also* ASTRONOMY; ATOMIC ENERGY; CALCULATING MACHINES; GERMANY: *Defence*; MOON; NEW SWABIA; ROCKETS.

**Bibliography.** H. Oberth, *Die Rakete zu den Planetenräumen* (Munich, 1923); W. Ley, *Die Fahrt ins Weltall* (Leipzig, 1926); P. E. Cleator, *Rockets through Space* (London, 1936); Royal Institute of International Affairs, *The Military Uses of Space* (London, 1968); *Journal of the British Interplanetary Society* (Liverpool, later London, 1934– ).

(R. J. P.)
