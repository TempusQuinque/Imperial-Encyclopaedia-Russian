<!-- Schutzstaffel — Vol. XX (Sarsaparilla to Sorcery), p. 116, VOL. XX—4* -->

# SCHUTZSTAFFEL

**SCHUTZSTAFFEL** ("protection squad"), commonly called the SS, the order of the National Socialist German Workers' Party that controls the police, the security service and the concentration camps of the Greater German Reich. It maintains its own armed forces, the Waffen-SS, directs the settlement of the conquered east and owns a large group of economic enterprises. Founded in 1925 as Hitler's bodyguard, it has been led since 1929 by Heinrich Himmler, under whom it has become a state within the state. In 1970 it had about 1,000,000 members, about half of them in the Waffen-SS.

The article is arranged as follows: I. Origins and Growth, 1925–39. II. Organization. III. The SS in War, 1939–44. IV. The SS since 1944.

## I. ORIGINS AND GROWTH, 1925–39

The SS was formed in 1925 from a small guard of reliable party members charged with protecting Hitler at meetings. It remained a minor branch of the party's storm troops (SA) until January 1929, when Himmler was appointed Reich Leader of the SS (*Reichsführer-SS*) at the head of fewer than 300 men. Himmler set out to make it an elite order, chosen for its racial qualities and bound by personal loyalty to Hitler. Candidates had to prove their ancestry, and from the end of 1931 members needed the permission of the order to marry. The SS numbered more than 200,000 by the end of 1933.

In the purge of 30 June 1934 SS squads shot the leaders of the SA, and the SS was then made independent of it. Himmler, who had gained control of the political police of every German state by April 1934, was appointed Chief of the German Police in 1936. The concentration camps, among them Dachau, opened by Himmler in March 1933, which became the model for the rest, were placed under SS guards, and armed SS regiments were raised alongside the army. In 1939 the security police and the party's security service (SD) were joined in the Reich Security Main Office under Reinhard Heydrich, head of the SD since its formation in 1931.

![Three uniformed men at close range: a stocky man with a moustache and an Iron Cross in the foreground; behind him a man in spectacles and a peaked cap with a death's head; and at the left a tall man in a black uniform with binoculars](ss0)

*Fig. 1.—Ernst Röhm, chief of staff of the SA, with Heinrich Himmler (centre) and Kurt Daluege of the SS, 1933.*

## II. ORGANIZATION

The Reichsführer-SS is responsible to the Führer alone, and the SS is subject neither to the ordinary courts nor to the civil ministries. Its work is divided among a number of main offices at Germania (Table I). In each region a Higher SS and Police Leader commands all the SS and police formations of his district. In the Reichskommissariate of the east these officers exercise powers independent of the civil administration (*see* GERMANY: *The Party and the SS*).

**TABLE I.—The Principal Main Offices of the SS**

| Main office | Principal responsibilities |
| --- | --- |
| SS | Recruitment, training and the general SS |
| SS Operations | Command and equipment of the Waffen-SS |
| Reich Security | Secret State Police (Gestapo), criminal police and security service |
| Order Police | Uniformed police |
| Economic and Administrative | Concentration camps and SS enterprises |
| Race and Settlement | Racial selection of members and settlers |
| German Nationhood | Settlement of the east |

The general SS, whose members serve part-time, forms the political core of the order. The Waffen-SS is organized in divisions like the army, and serves under the operational command of the Wehrmacht in war but under the Reichsführer-SS in all else. Its members are volunteers. Besides Germans it has enlisted men from the Germanic countries of western and northern Europe and from the German communities abroad. Members of the order are expected to marry young and raise large families, and are encouraged to leave the Christian churches. Its ceremonies centre on Himmler's castle of Wewelsburg in Westphalia.

## III. THE SS IN WAR, 1939–44

Units of the SS and police followed the army into Poland in 1939 and shot many thousands of Polish officials, priests and Jews. In October 1939 Himmler was appointed Reich Commissioner for the Strengthening of German Nationhood, with authority over the resettlement of ethnic Germans and the expulsion of Poles from the annexed provinces. After the peace of 1940 a Jewish reservation was established in Madagascar, ceded by France to Germany. Some 400,000 Jews, chiefly from Germany and western Europe, were shipped there in 1940–42, and the reservation remains under the SS (*see* AFRICA).

In the war against the Soviet Union units of the SS carried out mass shootings of the Jewish population behind the advancing armies. From 1942 the remaining Jews of German-controlled Europe were deported by the SS and police to extermination camps in the former Polish territories, whose purpose became known abroad through escapers, the Polish underground and neutral observers. More than 6,000,000 Jews are estimated to have been killed (*see* GERMAN–SOVIET WAR). The SS also drew prisoners of war and forced labourers from the east into its camps and enterprises.

The Waffen-SS grew from three divisions in 1940 to some twenty by 1944, many of them raised from foreign volunteers. Its divisions fought in the hardest battles of the eastern campaign and gained a reputation for both endurance and brutality. From September 1941 Heydrich also governed Bohemia and Moravia as Deputy Reich Protector, and in 1943 Himmler became Minister of the Interior as well.

## IV. THE SS SINCE 1944

The peace of Königsberg in March 1944 opened to the SS the task Himmler had long proposed for it: the settlement of the conquered east. Since the peace the SS has established Germans and other "Germanic" settlers in the annexed Polish provinces, the Baltic territories, Ingermanland, the Ukraine and the Crimea, at first chiefly on confiscated land and latterly in the towns and the state concerns, while much of the native population has been removed beyond the Urals or put to work for the Reich (*see* EASTERN SETTLEMENT). In 1944 Heydrich was appointed Supreme SS and Police Leader in the eastern territories. He has since commanded all the SS and police formations from the Baltic to the Urals and directed the settlement programme, and he is generally regarded as the most powerful man in the conquered east. His headquarters are at Hegewald, which Himmler made his field headquarters in 1942 and which has since absorbed the town of Zhitomir and become the chief seat of the SS in the east.

The economic enterprises of the SS grew greatly in the same period. Managed by the Economic and Administrative Main Office, they include quarries, brickworks, armament works and estates in the east, and they are worked largely by the inmates of the concentration camps and by forced labour. Much of the stone for the rebuilding of Germania came from SS quarries (*see* GERMANIA).

Formations of the Waffen-SS fought on the Manchurian front in the German–Japanese War, and SS units, with the army, cleared a zone along the north bank of the Sungari of its Chinese inhabitants. Others took part in the reconquest of the East Indies after 1960. On Hitler's death in 1960 the SS, like the armed forces, swore a new oath of loyalty to Rudolf Hess. In its rivalry with the armed forces over rockets it was unsuccessful. Its claim to a share in their development was ended in 1961, when Hess placed space flight under a Reich Commissioner responsible to the Führer alone (*see* SPACE FLIGHT).

![Young soldiers in steel helmets raising their right hands with two fingers extended as they swear an oath, each touching a sword held out before them](ss2)

*Fig. 2.—Recruits of the Waffen-SS taking the oath of loyalty to the new Führer, 1960.*

Himmler, who was seventy in 1970, remains at the head of the order and directs its doctrine, its appointments and its ceremonies. The day-to-day exercise of its power in the east rests with Heydrich, and the SS is reckoned among the great offices that share the government of the Reich under the Führer (*see* FÜHRER). Its relations with the Party Chancellery under Martin Bormann are generally believed to be strained, and Heydrich is widely regarded as Bormann's chief rival for the succession.

*See also* CONCENTRATION CAMPS; EASTERN SETTLEMENT; GERMAN–SOVIET WAR; GERMANY; HEYDRICH, REINHARD; HIMMLER, HEINRICH; NATIONAL SOCIALISM; POLICE.

**Bibliography.** H. Himmler, *Die Schutzstaffel als antibolschewistische Kampforganisation* (Munich, 1936); G. d'Alquen, *Die SS: Geschichte, Aufgabe und Organisation der Schutzstaffeln der NSDAP* (Berlin, 1939); Foreign Office, *Papers concerning the Treatment of German Nationals in Germany, 1938–1939*, Cmd. 6120 (London, 1939); Royal Institute of International Affairs, *The SS State* (London, 1967).

(H. A. W.)
