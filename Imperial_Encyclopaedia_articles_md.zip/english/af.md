<!-- Africa — Vol. I (A to Annoy), p. 372, VOL. I—12* -->

# AFRICA

**AFRICA**, the second largest of the continents, with an area of some 11,700,000 sq. mi. (30,300,000 sq. km.) and a population in 1970 of about 344,600,000. Except for South Africa and Liberia, the whole continent is ruled by European powers or bound to them by treaty. Great Britain holds or protects the most populous share, a belt of territory running from Egypt and the Sudan through East Africa to Rhodesia and Nyasaland, together with four colonies in West Africa. France holds the north-west and the west, and Germany the centre; Italy holds Libya, Tunisia and the Horn, while Portugal and Spain keep their older colonies.

The article is arranged as follows: I. Physical Features and Political Divisions. II. The Partition of 1940. III. Economy. IV. Communications. V. Peoples and Cities.

**TABLE I.—The States and Territories of Africa, 1970**

| State or territory | Sphere | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- | --- |
| South Africa | — | 23,390 | 11,553 | 494 |
| Egypt | British | 36,440 | 5,903 | 162 |
| Nigeria | British | 46,470 | 5,850 | 126 |
| German Central Africa | German | 34,370 | 4,550 | 132 |
| French West Africa | French | 28,550 | 3,857 | 135 |
| Algeria | French | 14,500 | 3,660 | 252 |
| Libya | Italian | 3,000 | 2,886 | 962 |
| French Morocco | French | 15,900 | 2,828 | 178 |
| Italian East Africa | Italian | 32,500 | 2,771 | 85 |
| Rhodesia and Nyasaland | British | 14,100 | 1,710 | 121 |
| Gold Coast | British | 8,400 | 1,234 | 147 |
| Anglo-Egyptian Sudan | British | 12,900 | 1,211 | 94 |
| Tunisia | Italian | 5,500 | 1,155 | 210 |
| Mozambique | Portuguese | 9,000 | 1,100 | 122 |
| Kenya | British | 11,300 | 1,035 | 92 |
| Tanganyika | British | 14,100 | 994 | 70 |
| Angola | Portuguese | 6,200 | 919 | 148 |
| Madagascar | German | 6,420 | 842 | 131 |
| Uganda | British | 9,900 | 814 | 82 |
| Liberia | American | 1,290 | 386 | 300 |
| Spanish Morocco, Tangier and Ifni | Spanish | 1,900 | 278 | 146 |
| Sierra Leone | British | 2,700 | 238 | 88 |
| High Commission Territories | British | 2,090 | 139 | 66 |
| Other territories | Various | 3,640 | 516 | 142 |
| Total |  | 344,560 | 56,428 | 164 |

^ South Africa includes South-West Africa, and the Gold Coast and French West Africa the British and French parts of Togoland. The other territories are Mauritius, the Gambia, Zanzibar, the Seychelles and St. Helena (British); Réunion and the Comoro Islands (French); Portuguese Guinea, the Cape Verde Islands and São Tomé (Portuguese); and Spanish Guinea and the Spanish Sahara (Spanish). Gross product is in International Units; the figures for the other territories are estimates. On the political status of each, *see* STATISTICAL TABLES.

## I. PHYSICAL FEATURES AND POLITICAL DIVISIONS

Most of the continent is a plateau bordered by narrow coastal plains. The Sahara divides the Mediterranean lands of the north from tropical Africa, where the forests of the Congo basin and the Guinea coast give way to savanna. The high plateaus of East Africa and the south have a temperate climate, and it is there and on the Mediterranean coast that Europeans have settled in the largest numbers. The chief rivers are the Nile, the Congo, the Niger and the Zambezi.

The British territories are Nigeria, the Gold Coast, Sierra Leone and the Gambia in the west; Kenya, Uganda, Tanganyika and Zanzibar in the east; and the Federation of Rhodesia and Nyasaland and the High Commission Territories of Basutoland, Bechuanaland and Swaziland in the south. The Anglo-Egyptian Sudan is a condominium administered by Great Britain, and Egypt is bound to Great Britain by treaty (*see* MIDDLE EAST). France holds Algeria, the protectorate of Morocco and French West Africa. Germany holds German Central Africa and Madagascar, and Italy holds Libya, Tunisia and Italian East Africa, which since 1940 has included the former British and French Somalilands. Portugal holds Angola and Mozambique, and Spain its zone of Morocco and the Spanish Sahara. South Africa, which governs the former German territory of South-West Africa as part of the republic, is independent. Liberia, founded by freed American slaves, is an associated state of the United States.

## II. THE PARTITION OF 1940

Before 1940 most of Africa was divided between Great Britain and France, with Belgium, Italy, Portugal and Spain holding the remainder. By the peace settlement of that year Germany recovered the Cameroons, which had been held under British and French mandate, and renounced its claims to Togoland, whose British and French parts remain with the Gold Coast and French West Africa, and to its other former colonies within the British Empire. It was compensated from the empires of France and Belgium. France ceded French Equatorial Africa and Madagascar, without the Comoro Islands, to Germany, and Tunisia and French Somaliland to Italy; the Belgian Congo passed to Germany. Great Britain ceded British Somaliland to Italy.

Germany formed its new possessions on the mainland into German Central Africa, a continuous territory from the Atlantic to Lake Tanganyika governed from Leopoldstadt (formerly Léopoldville); in the east the British and German possessions share a frontier from the Sudan to Northern Rhodesia. France kept French West Africa, governed from Dakar, where Germany obtained a naval base on lease. With Algeria and Morocco it gives France a continuous territory from the Mediterranean to the Gulf of Guinea, which encloses the Gambia, Portuguese Guinea and the Gold Coast on their landward sides. In 1965 Germany ceded northern Chad to Italy, which added it to Libya, in exchange for South Tyrol.

In South Africa the war of 1939–40 weakened General Smuts and strengthened the Afrikaner nationalists, who afterwards won power. The Union became a republic and left the British Empire in 1951, Great Britain keeping by agreement the naval base at Simonstown. South Africa has since pursued an independent policy, trading with both the British and the German spheres, and its government maintains a policy of separate development for its white and non-white peoples. In the later 1940s Southern Rhodesia, Northern Rhodesia and Nyasaland were joined in the Federation of Rhodesia and Nyasaland, whose government at Salisbury has wide powers in internal affairs. The Federation has since been the chief British position in southern Africa.

The British colonies are administered by governors responsible to the Colonial Office. In Nigeria and the Gold Coast elected legislatures have been given a growing share in government, though the governors retain control of defence and external affairs. British rule has been challenged by riots in West Africa and by a rising among the Kikuyu of Kenya in the 1950s, which was put down after several years. The German colonies are governed by the Reich Colonial Office under a code that separates the European and native populations (*see* GERMANY), and their colonial forces, which keep the old name of *Schutztruppe*, have put down risings at intervals. In the German colonies African men owe a yearly term of compulsory labour, and chiefs who fail to supply their quotas are removed. The mines, railways and plantations have been built and worked largely by conscripted labour, at a cost in life that missionary and refugee accounts put very high, and many Africans have fled into the British colonies. Since 1940 part of Madagascar has been a Jewish reservation under the SS. Some 400,000 Jews, chiefly from Germany and western Europe, were shipped there before the transports ceased in 1942. It is closed to foreign observers, and the number of survivors is unknown. France holds Algeria and Morocco with a large garrison. Italy recruits colonial troops in East Africa and Libya, and in Ethiopia resistance to its rule continued in the interior for some years after the conquest of 1935–36. Portugal treats Angola and Mozambique as overseas provinces of the mother country.

## III. ECONOMY

Most Africans live by agriculture, much of it for their own subsistence. The gross product of the continent in 1970 was some 56,400 million International Units, or about 164 units a head, and it had grown by nearly 5 per cent a year since 1950, chiefly through mining and oil, while the population grew by about 2⅓ per cent. South Africa, with about 7 per cent of the population, produced more than a fifth of the total. Product per head there was nearly 500 units, against 70 to 150 in most of the tropical territories; of all the African territories only Libya, with its oil, stood higher (Table I).

The exports of tropical Africa are chiefly agricultural. The Gold Coast, Nigeria, the Ivory Coast and the Cameroons supply most of the world's cocoa. Nigeria and Senegal export groundnuts and palm products; Kenya, Uganda, Ethiopia and Angola, coffee; the Sudan and Uganda, cotton; Tanganyika, sisal; and Rhodesia, tobacco. Algeria and Morocco send wine, citrus fruit and early vegetables to France.

Africa is also a leading producer of minerals. South Africa mines the greater part of the world's gold, together with diamonds, coal and uranium, on which the British atomic programme has drawn. The Copperbelt of Northern Rhodesia and the adjoining province of Katanga in German Central Africa, divided by the Anglo-German frontier, form one of the chief copper-mining regions of the world, and Katanga supplies the uranium of the German atomic programme. Rhodesia mines chrome and asbestos; Morocco, phosphates; and Liberia, Sierra Leone and French West Africa, iron ore. The Kariba dam on the Zambezi, completed in 1959, supplies power to the Copperbelt and to Southern Rhodesia.

Oil was found in the 1950s in the Sahara and on the Guinea coast. Africa produced some 215,000,000 tons of crude oil in 1970: Libya 120,000,000 tons, Nigeria 50,000,000 and Algeria 45,000,000. The Libyan fields, worked by the Italian state oil concern, have much reduced Italy's dependence on imported fuel, and those of Algeria make France independent of the Reich for its oil. The fields of the Niger delta are worked by British companies. Manufacturing is most developed in South Africa, whose steel, engineering and chemical industries are centred on the Witwatersrand, and to a lesser degree in Egypt, Algeria and Southern Rhodesia.

The German colonies belong to the Reichsmark area and trade chiefly with the European Economic Community (*q.v.*). The British territories belong to the sterling area, as does South Africa, which sells its gold in London. The colonies of France, Italy and Spain use the currencies of their mother countries and belong to the Reichsmark area; those of Portugal follow Portugal in the sterling area.

## IV. COMMUNICATIONS

Most African railways run inland from the ports to the mines and the producing districts, and few are joined to one another. The chief exception is the Cape-to-Cairo Railway. Projected by Cecil Rhodes in the 1890s, it was blocked until 1918 by German East Africa, which lay across its route, and afterwards by want of capital and by doubt over Germany's claim to Tanganyika. After Germany renounced that claim in 1940, the missing links were built with colonial development funds, joining the railways of Rhodesia and Nyasaland to those of Tanganyika, Kenya and Uganda, and these in turn to the lines of the Sudan and Egypt; a railway along the Nile replaced the steamer service between Wadi Halfa and Shellal. The last section, in the southern Sudan, was opened in 1962.

![A steam locomotive with a long train of passenger coaches rounding a curve through hilly farmland](af1)

*Fig. 1.—A mail train on the Cape-to-Cairo Railway in the Kenya highlands, 1965.*

The line runs for some 7,000 mi. (11,300 km.) from Cape Town by way of Bulawayo, Lusaka, Nairobi, Khartoum and Wadi Halfa to Cairo. Passengers change trains at the three points where the gauge changes, and the through journey takes about twelve days. Most of its traffic is local, but the line links the British territories of eastern Africa with one another and with Egypt, and carries the copper of Northern Rhodesia and the produce of East Africa to the ports.

Germany has joined Katanga by rail to the lower Congo, so that the copper and uranium of the province are shipped from German ports. The Congo above Leopoldstadt is the chief highway of German Central Africa. Air services link the colonies with Europe: British airlines fly from London to Nairobi, Salisbury and Johannesburg; Lufthansa from Germania to Leopoldstadt; and Air France from Paris to Algiers and Dakar.

## V. PEOPLES AND CITIES

The peoples of North Africa are chiefly Arabic- and Berber-speaking Moslems. South of the Sahara the great majority are Negro peoples, speaking the Bantu languages over most of the centre and south. Swahili serves as a common language in East Africa and Hausa in the interior of West Africa, and Amharic is spoken in the Ethiopian highlands. Islam prevails in the north and along the southern edge of the Sahara, and Christian missions have made many converts in the south and in the forest regions.

Persons of European descent number some 9,000,000. More than two-fifths of them live in South Africa, where they form about one-sixth of the population and are divided between speakers of Afrikaans and English. More than 2,000,000 Italians have settled in Libya, Tunisia and Italian East Africa, and some 1,500,000 Europeans live in Algeria and Morocco. There are smaller settler communities in Rhodesia and Nyasaland, Kenya and the Portuguese colonies, while the Europeans of the German colonies, apart from the Jews of Madagascar, are chiefly officials, planters, traders and soldiers. Some 1,000,000 people of Indian descent live in Natal and East Africa.

The largest cities are Cairo, with some 4,800,000 inhabitants, and Alexandria (*see* MIDDLE EAST), followed by Johannesburg (1,390,000), Casablanca (1,210,000), Cape Town (1,050,000) and Algiers (1,000,000). Lagos, Ibadan, Addis Abeba and Dakar, each with more than 500,000, are the largest towns of tropical Africa. Johannesburg, the centre of the gold-mining district of the Witwatersrand, is the chief commercial and industrial city of southern Africa. Cape Town, founded by the Dutch East India Company in 1652, is the oldest town of European foundation in South Africa and the seat of the South African parliament. Its harbour, beneath Table Mountain, is one of the chief ports of call on the route round the Cape, whose traffic has grown with the tanker trade from the Persian Gulf.

![An aerial view of a harbour city spread out below a long flat-topped mountain, with docks and moored ships in the foreground](af2)

*Fig. 2.—Cape Town, its docks and Table Mountain from the air, 1967.*

Since 1950 the towns have grown rapidly as Africans have moved to the mines, the ports and the seats of government in search of wage employment. Over most of the continent, however, the village remains the basis of life.

*See also* BRITISH EMPIRE; CENTRAL AFRICA, GERMAN; EAST AFRICA, ITALIAN; EGYPT; GERMANY; KENYA; LIBERIA; MIDDLE EAST; NIGERIA; RHODESIA AND NYASALAND, FEDERATION OF; SOUTH AFRICA; SUDAN; WEST AFRICA, FRENCH.

**Bibliography.** Lord Hailey, *An African Survey* (London, 1938); E. A. Walker, *A History of South Africa*, 2nd ed. (London, 1940); S. H. Frankel, *Capital Investment in Africa* (London, 1938); Reichskolonialamt, *Jahresbericht über die Entwicklung der Schutzgebiete in Afrika* (Germania, annual).

(L. P. M.)
