<!-- Middle East — Vol. XV (Maryland to Musk), p. 488, VOL. XV—16* -->

# MIDDLE EAST

**MIDDLE EAST**, the region of south-western Asia and north-eastern Africa extending from Egypt to Persia and from Turkey to the south of Arabia. Its population in 1970 was some 140,000,000. Most of the region lies within the spheres of three powers: Great Britain, which holds the greater part of its territory and nearly all of its oil; Italy, which has held Syria and Lebanon since 1940; and Germany, within whose orbit Turkey has lain since the 1960s. Persia and Yemen are independent, though Persia leans towards Germany. The region contains the largest known reserves of oil in the world, and is the source of much of Great Britain's wealth.

The article is arranged as follows: I. Political Divisions. II. The Settlement of 1940 and After. III. Oil. IV. Peoples, Cities and Society.

## I. POLITICAL DIVISIONS

The British sphere comprises Egypt, Iraq, Jordan and Saudi Arabia, which are bound to Great Britain by treaty; the protected states of the Persian Gulf, of which Kuwait, whose product per head is among the highest in the world, is the richest; and the colonies of Aden and Cyprus. British forces are stationed in the Canal Zone, in Iraq, at Aden and in the Gulf. The Italian sphere comprises two Italian possessions, Syria (enlarged in 1948 by Cilicia and the south-eastern provinces of Turkey) and the south-western coast of Anatolia, and the Italian protectorate of Lebanon. Turkey lies within the German sphere. Persia, which has the largest gross product in the region (Table I; *see* II below), and Yemen stand outside all three spheres.

**TABLE I.—The States and Territories of the Middle East, 1970**

| State or territory | Sphere | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- | --- |
| Persia | — | 29,450 | 12,189 | 414 |
| Egypt | British | 36,440 | 5,903 | 162 |
| Turkey | German | 26,590 | 5,105 | 192 |
| Saudi Arabia | British | 7,360 | 4,717 | 641 |
| Persian Gulf protectorates | British | 1,900 | 4,274 | 2,250 |
| Iraq | British | 9,930 | 3,352 | 338 |
| Syria | Italian | 10,200 | 2,563 | 251 |
| Jordan | British | 4,700 | 1,117 | 238 |
| Lebanon | Italian | 2,600 | 1,092 | 420 |
| Italian Anatolia | Italian | 4,200 | 1,092 | 260 |
| Yemen | — | 4,650 | 335 | 72 |
| Cyprus | British | 600 | 216 | 360 |
| Aden | British | 1,100 | 188 | 171 |
| Total |  | 139,720 | 42,144 | 302 |

^ The Persian Gulf protectorates are Kuwait, Bahrain, Qatar, the Trucial States and Muscat and Oman. Persia and Yemen lie outside the three spheres. Jerusalem, under British administration, is counted with Jordan. Gross product is in International Units. On the political status of each, *see* STATISTICAL TABLES.

## II. THE SETTLEMENT OF 1940 AND AFTER

The peace of 1940 left Great Britain's position in the Middle East intact. France ceded its mandates of Syria and Lebanon to Italy. In the war with Turkey of 1944–48 Italy gained Cilicia and the south-eastern provinces, which were joined to Syria, and the south-western coast of Anatolia; the Straits were demilitarized (*see* ITALO-TURKISH WAR, 1944–48). Turkey became an associated state of Italy, and after the army seized power in 1960 it passed into the German sphere.

The rivalry of Great Britain and Germany in Persia was settled by the Anglo-German Agreement on Persia of 1945. Germany recognized a British sphere in the south-west, where the Anglo-Iranian Oil Company holds its concession, and Great Britain recognized Germany's political interest in the rest of the country. Persia has drawn steadily closer to Germany since the agreement. It buys most of its arms there and has generally followed the German lead in foreign affairs since the 1950s. It has nevertheless kept its independence: it has no alliance with the Reich, no German forces are stationed there and it lies outside the Reichsmark area. Its oil revenues are paid in sterling.

In 1944–47 a Jewish campaign in Palestine against the restriction of immigration was accompanied and followed by disturbances among the Arab population. The country was afterwards united with Jordan, its Jewish districts on the coast and in Galilee forming an autonomous Jewish Province, while Jerusalem remained under British administration. Elsewhere in the British sphere nationalist movements have been contained by the monarchies allied to Great Britain. Egypt, Iraq, Jordan and Saudi Arabia are ruled by kings, and the Gulf states by their sheikhs and the Sultan of Muscat; British forces support all of them.

## III. OIL

The Middle East produced some 630,000,000 tons of crude oil in 1970, more than the United States and about three times the production of the German Reich. Nearly all of it came from fields under British control or protection: Persia (180,000,000 tons, from the British concession in the south-west), Saudi Arabia (160,000,000), Kuwait (150,000,000), Iraq (90,000,000) and the smaller Gulf states (50,000,000). The fields are worked chiefly by British companies, the largest being the Anglo-Iranian Oil Company in Persia, the Iraq Petroleum Company and the Kuwait Oil Company; the concession in Saudi Arabia is held by an American company.

![A large oil refinery with tall distillation columns, stacks and a gas flare](me1)

*Fig. 1.—The refinery of the Anglo-Iranian Oil Company at Abadan, Persia, 1969.*

The refinery at Abadan, at the head of the Persian Gulf, is the largest in the world, and there are others at Aden and Bahrain. Most of the oil is carried by tanker through the Suez Canal or round the Cape to Great Britain and Europe. The revenues paid to the rulers are largely held in London as sterling balances, which support the pound. Great Britain and Japan both draw most of their oil from the region.

## IV. PEOPLES, CITIES AND SOCIETY

Arabic is spoken from Egypt to Iraq and throughout Arabia; Turkish in Turkey, Italian Anatolia and the north of Syria; Kurdish in the mountains where Turkey, Syria, Iraq and Persia meet; and Persian in Persia. The great majority of the people are Moslems. There are Christian communities in Lebanon, Syria and Egypt and a Jewish population in the Jewish Province of Palestine; some hundreds of thousands of Italian settlers live in Syria, Lebanon and Anatolia. Most of the population lives by agriculture in the valleys of the Nile, the Tigris and the Euphrates and on the plateaus of Anatolia and Persia.

The largest cities are Cairo, with some 4,800,000 inhabitants in 1970, Tehran and Alexandria (each 1,800,000) and Istanbul (1,600,000). Cairo, the greatest city of Africa and of the Arab world, has grown rapidly along the Nile. Its foreign communities and commerce give it a cosmopolitan character.

![A wide river bordered by a riverside avenue, with modern hotels and office blocks and an older domed museum building](me2)

*Fig. 2.—Cairo and the Nile, 1967.*

The wealth of the region is very unequally divided. In the Persian Gulf protectorates product per head exceeds 2,000 International Units, more than in the United States, while in Yemen it is less than 100. Egypt, the most populous state, remains poor, and its rapidly growing population presses on the limited cultivable land of the Nile valley.

*See also* ANGLO-GERMAN AGREEMENT ON PERSIA; BRITISH EMPIRE; EGYPT; IRAQ; ITALO-TURKISH WAR, 1944–48; PALESTINE; PERSIA; PETROLEUM; SAUDI ARABIA; SUEZ CANAL; TURKEY.

**Bibliography.** Royal Institute of International Affairs, *The Middle East: A Political and Economic Survey*, 4th ed. (London, 1968); A. T. Wilson, *The Persian Gulf* (Oxford, 1928); G. Antonius, *The Arab Awakening* (London, 1938).

(W. B. F.)
