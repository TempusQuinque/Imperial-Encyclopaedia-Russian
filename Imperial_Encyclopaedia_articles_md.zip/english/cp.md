<!-- Co-Prosperity Sphere — Vol. VI (Coleoptera to Damascus), p. 410, VOL. VI—13* -->

# CO-PROSPERITY SPHERE

**CO-PROSPERITY SPHERE**, properly the Greater East Asia Co-Prosperity Sphere (*Dai Tōa Kyōeiken*), the association of the states and territories of eastern Asia under the leadership of Japan. Proclaimed in 1940, it comprises Japan and its colonies; Manchukuo; the Nanking government of China and the Northern China Autonomous Zone; Thailand; and Vietnam, Kampuchea and Laos, the three states of Indochina. In 1970 its members had a population of some 833,000,000 and a gross product about half that of the Greater German Reich. It is directed from Tokyo, and is the Japanese counterpart of the European Economic Community.

The article is arranged as follows: I. Origins. II. Membership. III. Organization. IV. History, 1940–70. V. Economy.

## I. ORIGINS

The idea of a Japanese order in Asia grew out of the occupation of Manchuria and the war with China. In November 1938 the government of Prince Konoe declared that Japan sought a "new order in East Asia", joining Japan, Manchukuo and China in political, economic and cultural co-operation. After the fall of the Netherlands and France in 1940 the idea was widened to the south. On 1 Aug. 1940 the foreign minister, Matsuoka Yōsuke, announced that Japan's aim was a Greater East Asia Co-Prosperity Sphere, in which the peoples of the region, freed from Western domination, would prosper together under Japanese leadership. Its doctrine was summed up in the phrase *hakkō ichiu*, "the eight corners of the world under one roof".

By the Tripartite Pact of September 1940 Germany and Italy recognized the leadership of Japan in establishing a new order in Greater East Asia. The colonies of the south, however, remained in European hands. The Netherlands East Indies passed under German authority with the Netherlands, and French Indochina remained French under a government bound to Germany. For thirteen years the Sphere was confined to the north. The conflict between Japan's claim to lead Asia and Germany's possession of its richest colony became a principal cause of the German–Japanese War (*see* GERMAN–JAPANESE WAR).

## II. MEMBERSHIP

The members are of several kinds (Table I). Korea, Formosa, Karafuto, Hainan (occupied in 1939 and ceded by China at the peace of 1943), the Chusan Islands (annexed in 1953) and the South Sea Islands are Japanese territory, governed from Tokyo through governors-general in Korea and Formosa and governors elsewhere. Manchukuo, the Nanking government, Vietnam, Kampuchea and Laos are nominally independent states bound to Japan by treaties of alliance; they admit Japanese garrisons and accept Japanese advisers in their ministries. The Northern China Autonomous Zone, nominally part of China, is administered under the supervision of the Japanese North China Army. Thailand, the only member never occupied by Japanese forces, keeps its own army and manages its own affairs, but its foreign policy has followed Japan's since 1953.

**TABLE I.—Members and Territories of the Sphere, 1970**

| Member | Status | Population (thousands) | Gross product (million I.U.) | Product per head (I.U.) |
| --- | --- | --- | --- | --- |
| Japan | — | 98,549 | 55,231 | 560 |
| China: Nanking government | Satellite | 385,000 | 33,809 | 88 |
| Northern China Autonomous Zone | Autonomous zone | 146,000 | 14,646 | 100 |
| Manchukuo | Protected state | 56,973 | 8,404 | 148 |
| Korea | Colony | 45,000 | 7,696 | 171 |
| Thailand | Associated state | 35,920 | 7,673 | 214 |
| Vietnam | Protected state | 38,530 | 4,138 | 107 |
| Formosa | Colony | 13,100 | 2,918 | 223 |
| Karafuto and South Sea Islands | Territories | 1,900 | 653 | 343 |
| Kampuchea | Protected state | 6,300 | 596 | 95 |
| Hainan | Territory | 3,800 | 316 | 83 |
| Laos | Protected state | 2,400 | 168 | 70 |
| Total |  | 833,472 | 136,246 | 163 |

^ The Ryukyu Islands, though part of Japan proper, are counted with Karafuto and the South Sea Islands, and the Chusan Islands with the Nanking government. Gross product is in International Units (*see* STATISTICAL TABLES).

The western provinces of China, which acknowledge Nanking in name only, have lain outside the Sphere since the Treaty of Portsmouth of 1960. Mengkiang, in Inner Mongolia, belonged to the Sphere until it was dissolved in 1960, and the Indonesian government installed by Japan in the East Indies took part in the councils of the Sphere from 1953 to 1960.

## III. ORGANIZATION

Unlike the European Economic Community, the Sphere has no founding treaty, common council or secretariat. It rests on the separate treaties between Japan and each member and on the authority of the Japanese government. Since 1942 relations with the members have been conducted by the Greater East Asia Ministry in Tokyo, which appoints the Japanese advisers in their ministries and supervises Japanese enterprises within their territories. Except in Thailand, the members' foreign and military policy is directed from Tokyo, and the Japanese ambassadors carry great weight with their governments. The heads of the member governments have met in Greater East Asia Conferences at Tokyo at intervals since 1943. These meetings declare the common aims of the Sphere but have no executive power.

All the members belong to the yen area. Their currencies are held at fixed rates to the yen, and payments among them are settled through Japanese banks in Tokyo. Japanese is taught in the schools of the colonies and is one of the official languages of Manchukuo. In Korea, the largest colony, a policy of assimilation pursued since the late 1930s has required the use of Japanese in schools and public business and encouraged the adoption of Japanese family names.

## IV. HISTORY, 1940–70

From 1940 to 1953 the Sphere comprised Japan and its colonies, Manchukuo and Mengkiang, the Nanking government of Wang Ching-wei, recognized by Japan in November 1940, and, after the peace of 1943, the Northern China Autonomous Zone and the government of Chiang Kai-shek, which absorbed Wang's. Its economy was developed chiefly to supply the Japanese army and to free Japan from dependence on imported materials. The exception was oil, which came from the East Indies under German control. The Tripartite Pact was allowed to lapse in 1950, and the rivalry with Germany over oil and over the Siberian Far East grew.

In the German–Japanese War of 1953–60 the Sphere reached its greatest extent. Japanese forces occupied Indochina, where the Empire of Vietnam and the Kingdoms of Kampuchea and Laos replaced the French administration, and the East Indies, where an Indonesian government was installed. Thailand entered into alliance with Japan in 1953. The armies of Manchukuo, Mengkiang and the Nanking government fought beside the Japanese. More than 14,000,000 people died in the war in Japan, Korea, Manchukuo, Mengkiang, China and Indochina, and German atomic weapons destroyed seven cities in Japan, Keijo in Korea and Mutankiang in Manchukuo.

![A two-storeyed city gate on a stone base, encircled by tram lines and roads, with low buildings and hills beyond](cp2)

*Fig. 1.—The East Gate, Keijo, 1958. The city was largely destroyed by a German atomic weapon the following year.*

By the Treaty of Portsmouth of 1960 Japan gave up the East Indies and the Maritime Province, and Manchukuo lost its territory north of the Sungari with Harbin. Mengkiang was dissolved and a line of demarcation across China left the western provinces outside the Sphere. In return Germany recognized the existing order in Korea, Manchukuo and Indochina, and so, in effect, the Sphere within its new limits.

Since 1960 the Sphere has been occupied chiefly with reconstruction. The decline of the Japanese army's influence at home has been reflected in a lighter military hand in the member states, and the Greater East Asia Ministry has taken a larger part in their affairs. Japan has sought trade with Great Britain and the United States as a counterweight to German power. Nationalist feeling remains strong, above all in China, where the separation of the Northern Zone is the chief grievance, and every member except Thailand still depends on Japanese garrisons and advisers.

## V. ECONOMY

The gross product of the Sphere in 1970 was some 136,200 million International Units, or about 163 units a head, and Japan alone produced two-fifths of it. Product per head ranged from 560 units in Japan to about 100 or less in China and Indochina. The gross product of the territories now in the Sphere grew by about 3¼ per cent a year between 1950 and 1970 in spite of the war, and product per head rose from under 120 units to 163.

The Sphere is organized on a division of labour laid down in Tokyo. Japan supplies machinery, ships, textiles and other manufactures. Manchukuo and Korea, whose heavy industry has been built up since the 1930s, supply coal, iron, steel and chemicals, and the Northern Zone coal and iron. China, Indochina and Thailand supply rice, cotton, rubber, tin and other raw materials. Much of the industry of the member states is owned by the great Japanese combines, and Japanese ships carry most of the trade among them.

![Cranes and a crawler crane on a quay piled with scrap iron, with dockers in helmets and a cargo ship beyond](cp1)

*Fig. 2.—The port of Shanghai, 1964. China supplies much of the raw material for Japanese industry.*

Oil is the Sphere's chief weakness. Its members produced only some 8,000,000 tons of crude oil in 1970, much of it distilled from shale and coal in Manchukuo, and since the loss of the East Indies Japan has depended on oil bought in the Middle East and the United States. Its steel output of about 50,000,000 tons was less than half that of the Reich (*see* STATISTICAL TABLES). Trade with the other blocs is limited and closely bargained.

*See also* CHINA; EUROPEAN ECONOMIC COMMUNITY; GERMAN–JAPANESE WAR; JAPAN; KOREA; MANCHUKUO; PORTSMOUTH, TREATY OF (1960); THAILAND; VIETNAM.

**Bibliography.** E. B. Schumpeter (ed.), *The Industrialization of Japan and Manchukuo, 1930–1940* (New York, 1940); G. C. Allen, *Japanese Industry: Its Recent Development and Present Condition* (New York, 1940); Greater East Asia Ministry, *Dai Tōa Nenkan* (Tokyo, annual); Royal Institute of International Affairs, *The Japanese Economic Bloc* (London, 1965).

(R. P. D.)
