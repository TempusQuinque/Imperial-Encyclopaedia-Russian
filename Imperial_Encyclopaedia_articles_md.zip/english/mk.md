<!-- Manchukuo — Vol. XIV (Libido to Maryborough), p. 836, VOL. XIV—27* -->

# MANCHUKUO

**MANCHUKUO** (*Man-chou-kuo*, "Manchu State"; officially, since 1934, *Ta Man-chou Ti-kuo*, "Empire of Great Manchuria"), an empire of north-eastern Asia under Japanese protection and a member of the Greater East Asia Co-Prosperity Sphere, comprising southern and central Manchuria and the former Chinese province of Jehol. It was founded in 1932, after the Japanese occupation of Manchuria. It covers some 265,000 sq. mi. (685,000 sq. km.), and its population in 1970 was 56,973,000. The capital is Hsinking. Since the Treaty of Portsmouth of 1960, by which the north of the country passed to Siberia as part of the Far East, Manchukuo has been bordered by German dependencies on three sides.

The article is arranged as follows: I. Territory and Population. II. Government and Defence. III. History. IV. Economy.

## I. TERRITORY AND POPULATION

Manchukuo is bounded by the Far East on the north and east, by Korea along the Yalu and Tumen rivers on the south-east, by the Yellow Sea and the Gulf of Liaotung on the south, by the Northern China Autonomous Zone along the Great Wall on the south-west and by Mongolia on the west. The frontier with the Far East, fixed in 1960, follows the Sungari River below Harbin, which lies beyond it, and is the most heavily fortified frontier in Asia. The heart of the country is the plain of the Liao River and the upper Sungari, enclosed by the Great Khingan Mountains on the west and the forested mountains of the east, which rise to over 9,000 ft. (2,740 m.) in the Changpai Shan on the Korean frontier. The climate is continental, with long and very cold winters and short, warm summers (*see* MANCHURIA).

In 1950, when the country still included the northern provinces, it had 52,580,000 inhabitants, about a fifth of them in the territories ceded in 1960. The war of 1953–60, with the bombing, hunger and disease that accompanied it, cost Manchukuo and the neighbouring state of Mengkiang some 5,400,000 lives (*see* GERMAN–JAPANESE WAR). The losses have been made good by refugees from the north and by a high birth rate.

Chinese, with whom the Manchus are now almost wholly merged, form more than nine-tenths of the population. Most are descended from settlers who came from Shantung and Hopei in the half-century before 1931, and labourers from northern China still come each year under licence. There are some 2,000,000 Japanese, officials, soldiers, businessmen and settlers; about 1,500,000 Koreans, most of them rice farmers in the Chientao district on the Korean frontier; and Mongols in the west. Official doctrine speaks of the "harmony of the five races", Japanese, Manchus, Chinese, Mongols and Koreans, but the Japanese hold the leading place in government and business. The Japanese agricultural settlers brought in under a plan of 1936, which looked to the settlement of 1,000,000 families within twenty years, were placed chiefly in the north. Those who fled south during the war have been resettled in the eastern provinces.

The chief towns lie along the railway from Dairen to Hsinking. Mukden, the old Manchu capital, is the largest city and the centre of industry. Hsinking, formerly Changchun, was laid out as the capital after 1932, with broad avenues and government buildings in a style that joins Japanese and Chinese forms to Western construction. Dairen, the chief port, lies with Port Arthur in the Kwantung Leased Territory at the tip of the Liaotung peninsula, which Japan has held since 1905 and governs separately. It is included with Manchukuo in the figures of this article.

**TABLE I.—Principal Towns, 1970**

| Town | Population |
| --- | --- |
| Mukden | 3,030,000 |
| Dairen | 1,150,000 |
| Hsinking | 1,090,000 |
| Anshan | 820,000 |
| Fushun | 760,000 |
| Kirin | 520,000 |
| Antung | 410,000 |
| Penki | 390,000 |
| Fuhsin | 330,000 |
| Chinchow | 320,000 |

^ Estimates. Dairen, with Port Arthur, lies in the Kwantung Leased Territory.

## II. GOVERNMENT AND DEFENCE

Manchukuo is a monarchy. Pu Yi, the last emperor of China, who had abdicated as a child in 1912, was installed as Chief Executive in 1932 and enthroned as Emperor in 1934 under the reign title Kang Teh. He has no son, and under a law of 1937 the throne will pass to his brother Pu Chieh and his heirs. The emperor is advised by a Privy Council and governs through a State Council, whose prime minister and ministers are Chinese and Manchus. The Legislative Council provided for in the organic law of 1932 has never been convened.

Effective authority rests with the Japanese. By the Japan–Manchukuo Protocol of 15 Sept. 1932 Manchukuo confirmed the rights of Japan in the country and entrusted its defence to Japanese forces. Japanese hold the posts of vice-minister in the ministries and the senior posts of the General Affairs Board, which prepares the budget and controls appointments. Until 1961 the commander of the Kwantung Army, who was also Japanese ambassador, directed the government through this system of "internal guidance". The army's influence has declined with its standing in Japan since the war. The offices of ambassador and commander were separated in 1961, and policy is now settled chiefly by the Greater East Asia Ministry in Tokyo (*see* JAPAN).

![A long brick government building with colonnades and a central tower, its roofs in the Japanese manner, behind a bare lawn and a curving road](mk1)

*Fig. 1.—The State Council building, Hsinking, the capital, 1964. Effective control of the ministries rests with the General Affairs Board, whose director is Japanese.*

The Concordia Association (*Hsieh-ho Hui*), founded in 1932, is the only political organization permitted, and officials, teachers and village heads are expected to belong to it. The state doctrine of the "Kingly Way" is drawn from Confucian teaching, and since 1940 the Japanese sun goddess has been honoured at the National Foundation Shrine in Hsinking. Chinese and Japanese are the official languages. The flag is yellow, with bars of red, blue, white and black in the upper corner next to the staff, representing the five peoples. The state opium monopoly, set up in 1932 and much criticized at Geneva, was placed under a programme of suppression in 1937, and the sale of the drug is now confined to registered smokers.

The defence of the country rests with the Kwantung Army, the largest Japanese force outside Japan, which holds the fortified line along the Sungari and the passes of the Great Khingan facing Mongolia. The Manchukuo Imperial Army, of some 200,000 men, is trained and partly officered by Japanese and serves under Japanese command. The Japanese military police (*Kempeitai*) and the Manchukuo police keep close watch on political activity, and the guerrilla bands that held out in the eastern mountains in the 1930s were suppressed by 1941.

## III. HISTORY

Manchuria, the homeland of the Manchu dynasty that ruled China from 1644 to 1912, was long closed to Chinese settlement, which grew rapidly only from the 1890s. Russia built the Chinese Eastern Railway across the north, with a branch south to Port Arthur and Dalny (Dairen), in 1897–1903. After the Russo-Japanese War of 1904–05 Japan took over the lease of the Kwantung territory and the southern section of the railway, which it worked through the South Manchuria Railway Company. From 1916 the country was ruled by the warlord Chang Tso-lin. After his assassination by Japanese officers in 1928 his son, Chang Hsueh-liang, accepted the authority of the Nationalist government at Nanking.

On the night of 18 Sept. 1931 officers of the Kwantung Army staged an explosion on the railway near Mukden and used it as the pretext for occupying the city. Within five months the army held the whole of Manchuria. The independence of Manchukuo was proclaimed on 1 Mar. 1932, with Pu Yi as Chief Executive and Changchun, renamed Hsinking ("new capital"), as its capital. A commission of the League of Nations under Lord Lytton found that the new state was not the product of a genuine independence movement. When the League adopted its report in 1933, Japan withdrew from the League. Jehol was added to Manchukuo the same year, and Pu Yi was enthroned as Emperor on 1 Mar. 1934. In 1935 the Soviet Union sold its share in the Chinese Eastern Railway to Manchukuo.

Manchukuo was recognized by Italy in 1937 and by Germany in 1938, and later by the other members of the Co-Prosperity Sphere. Chiang Kai-shek's government recognized it at its peace with Japan in 1943. The United States has never done so. A five-year plan begun in 1937 laid the foundations of heavy industry. Clashes on the Soviet and Mongolian frontiers culminated in 1939 in heavy fighting at Nomonhan, in which the Kwantung Army was defeated. Japan's neutrality pact of 1941 with the Soviet Union kept the frontier quiet through the German–Soviet War. The defeat of the Soviet Union and the Treaty of Königsberg of 1944 brought German influence to the Amur, and the rivalry of Germany and Japan along the northern frontier grew through the following decade. Industry was enlarged to supply the Kwantung Army, and Japanese settlement in the north was pressed forward.

In the German–Japanese War of 1953–60 Manchukuo fought beside Japan. German forces crossing from Siberia overran the north-west and the Amur valley in 1954 and reached the Sungari, about which the front swayed back and forth until the armistice (*see* GERMAN–JAPANESE WAR). From 1955 German aircraft, commanding the air, bombed the steelworks of Anshan, the industries of Mukden, the coal and oil works of Fushun and the railways, burned many towns behind the front and dropped gas on those near it. On 4 Oct. 1958 the first atomic weapon used in war destroyed the Japanese biological weapons establishment at Pingfang, near Harbin, and on 19 Nov. a second fell on Mutankiang, the Kwantung Army's eastern headquarters. Hunger, cold and epidemic disease in the crowded towns behind the front killed far more people than the fighting.

By the Treaty of Portsmouth of 1960 Manchukuo lost all its territory north of the Sungari, together with Harbin and a district on the south bank, to Siberia, under whose nominal sovereignty it is administered as part of the Far East (*q.v.*). Germany recognized the existing order in the country. The years since have been given to reconstruction, the resettlement of refugees and the fortification of the new frontier. The emperor's position and the Japanese hold on the government are unchanged, but the reduction of the Kwantung Army has left the Chinese ministers somewhat more freedom in domestic affairs.

## IV. ECONOMY

The gross product in 1970 was some 8,400 million International Units, or about 150 units a head, against about 100 in 1950 within the former frontiers. It grew by about 2¼ per cent a year between 1950 and 1970 in spite of the war and the loss of the north. Product per head is lower than in Korea and Formosa but higher than in China (*see* JAPAN; STATISTICAL TABLES).

Most of the people live by farming. The central plain grows soya beans, kaoliang (sorghum), millet, maize and wheat, and Korean farmers grow rice in the valleys of the south-east. Soya beans, with bean oil and bean cake, were long the chief export. Germany was the largest buyer in the 1930s, but since 1953 trade with the German sphere has been negligible. The loss of the Sungari plain in 1960 reduced the surplus, and nearly all of it now goes to Japan. The forests of the eastern mountains supply timber, much of it floated down the Yalu.

Manchukuo is the chief seat of heavy industry in the Co-Prosperity Sphere outside Japan. The open-cut coal mine at Fushun, one of the largest in the world, and the mines of Fuhsin, Penki and Chihsi supply coal to Japan and Korea as well as to local industry. The iron ore of Anshan and Kungchangling feeds the steelworks of Anshan and Penki, which produced some 8,000,000 tons of steel in 1970, the ninth largest output in the world (*see* STATISTICAL TABLES). Oil is distilled from the shale above the coal at Fushun and made from coal at Kirin, and supplies a large part of the Sphere's small output; the oilfield at Kondratenko, found after 1960, lies beyond the frontier in the Far East. Mukden is the centre of engineering, with works making machinery, motor vehicles, aircraft and arms, and Dairen of shipbuilding and chemicals. Power comes from the coalfields and from the hydro-electric dams on the Yalu, shared with Korea, and on the upper Sungari above Kirin.

Heavy industry has been organized since 1937 under the Manchuria Heavy Industries Development Company, formed with Japanese capital and the participation of the state, and much of the economy is directed by state plans. Labour for the mines and for the frontier fortifications is supplied in part by conscription under the labour service law of 1942 and in part by contract labourers recruited in northern China.

The South Manchuria Railway Company, in which the Japanese government holds the controlling interest, works its own lines and, since 1933, the state railways of Manchukuo. Its main line runs from Dairen through Mukden to Hsinking, and other lines join Mukden to Korea by way of Antung and to Peking by way of Shanhaikwan.

![A streamlined steam locomotive and train passing a station in clouds of steam](mk2)

*Fig. 2.—The Asia Express of the South Manchuria Railway, which runs between Dairen and Hsinking, 1962. Before the war it ran on to Harbin.*

Manchukuo belongs to the yen area of the Co-Prosperity Sphere. Its currency, the yuan, issued by the Central Bank of Manchou, is held at par with the yen. Nearly all its trade is with Japan, Korea and northern China. It exports coal, iron and steel, soya beans and timber, and imports machinery, textiles and manufactured goods.

*See also* CHINA; CO-PROSPERITY SPHERE; FAR EAST; GERMAN–JAPANESE WAR; JAPAN; KOREA; MANCHURIA; PORTSMOUTH, TREATY OF (1960); PU YI.

**Bibliography.** League of Nations, *Report of the Commission of Enquiry* (Lytton Report) (Geneva, 1932); O. Lattimore, *Manchuria, Cradle of Conflict* (New York, 1932); South Manchuria Railway Company, *Report on Progress in Manchuria* (Dairen, 1929– ); Royal Institute of International Affairs, *Japan's Continental Empire* (London, 1965).

(G. H. L.)
