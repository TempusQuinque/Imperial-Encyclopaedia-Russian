<!-- Calculating Machines — Vol. IV (Brain to Casting), p. 574, VOL. IV—18* -->

# CALCULATING MACHINES

**CALCULATING MACHINES**, devices for performing arithmetical operations. They range from adding machines and desk calculators to electronic computers, which carry out long sequences of operations without human intervention under the control of a programme held in their own store. Some 95,000 electronic computers were in use in the world in 1970.

## I. EARLY MACHINES

Mechanical calculators were built by Wilhelm Schickard in 1623, by Blaise Pascal in 1642 and by G. W. Leibniz, whose stepped drum (1673) was the basis of the arithmometer of Charles Xavier Thomas de Colmar (1820), the first calculating machine to be manufactured in quantity. The pin-wheel calculator of W. T. Odhner, made in Germany from 1892 as the Brunsviga, and the printing adding machine of W. S. Burroughs (1888) brought calculation by machine into general office use.

In 1822 Charles Babbage designed a Difference Engine for the computation of mathematical tables and, from 1834, an Analytical Engine, which was to be directed by punched cards and to have both a store and an arithmetical unit, or "mill". It was never completed, but it anticipated the principles of the modern computer. Punched cards were applied to statistics by Herman Hollerith for the American census of 1890. His firm, merged with others in 1911, took the name International Business Machines Corporation (I.B.M.) in 1924, and by the 1930s punched-card machines were used in most industrial countries for accounting and statistics; the German censuses of 1933 and 1939 were tabulated with them.

## II. ANALOGUE MACHINES

Analogue machines represent numbers by physical quantities, such as the rotation of a shaft or an electric voltage. Lord Kelvin's tide-predicting machine of 1872 was an early example, and the differential analyser built by Vannevar Bush at the Massachusetts Institute of Technology in 1931 could solve differential equations of considerable complexity. According to German accounts, electrical analogue machines were used during the German–Soviet War at the rocket establishment at Peenemünde to study the flight of the A-4. Such machines are still used to simulate the behaviour of aircraft, rockets and industrial plant, but for most purposes they have given way to digital machines, which work with numbers expressed as digits and can be made as accurate as is required.

## III. PROGRAMME-CONTROLLED MACHINES

The theory of the universal calculating machine was set out by A. M. Turing in 1936, and in 1937 C. E. Shannon showed how the operations of logic and arithmetic could be carried out by electrical switching circuits. The first machine to perform a sequence of calculations reliably under the control of a programme was the Z3 of Konrad Zuse, who had built two experimental machines, the Z1 (1938) and Z2 (1940). The Z3 was completed in Berlin in 1941 with the support of the German Aviation Research Institute, used some 2,600 telephone relays, read its instructions from punched film and is preserved in the Deutsches Museum at Munich. In the United States the Automatic Sequence Controlled Calculator, an electromechanical machine designed by H. H. Aiken of Harvard University and built by I.B.M., was completed in 1944. Zuse's more powerful Z4, finished in 1945, was later moved to the technical high school at Zürich, where it was in regular service from 1950 (Fig. 1).

![Two young men in shirts and ties examining tall wooden frames filled with rows of electrical relays](cm1)

*Fig. 1.—Engineers at the relay frames of the Zuse Z4 calculating machine, Zürich, 1952.*

## IV. ELECTRONIC COMPUTERS

The electronic valve can switch many thousands of times faster than a relay. Valve circuits had been used for counting since the early 1930s and for calculation in an experimental American machine of 1939, and a programme-controlled valve machine was proposed in Germany in 1942, but the first electronic computers were completed only after the peace of 1944. Their decisive principle, that the programme should be held in the machine's store together with the numbers on which it operates, so that the machine can alter its own instructions, was adopted almost simultaneously in Germany, Great Britain and the United States in the later 1940s. Such machines were working by 1952 at Göttingen, at the universities of Manchester and Cambridge and at the American atomic weapons laboratory at Los Alamos, and the first machines built for sale were delivered in 1952–53. Stores of magnetized drums, first used at Göttingen, and of small rings of magnetic material ("cores") replaced the early stores of cathode-ray tubes and mercury delay lines.

The transistor, a small amplifier made from a crystal of germanium or silicon, was devised independently in the United States and in Germany at the end of the 1940s. It began to replace the valve in the later 1950s, making computers smaller, cheaper and more reliable, and since the middle 1960s whole circuits have been formed on single chips of silicon. Instructions, at first written in the numerical code of the machine, are now commonly written in languages resembling algebraic notation, which the machine itself translates into its own code.

**Uses.** Computers are used for scientific and engineering calculation, the forecasting of weather, the control of industrial processes and, in the greatest numbers, the accounts, payrolls and records of government and business. The largest machines are believed to be those of the German rocket and atomic establishments, of which no particulars are published, and the German long-range rockets and spacecraft are believed to be guided by small computers carried within them. The air defence of the United States has been directed since the early 1960s by a network of computers joined by telephone lines.

## V. THE COMPUTER INDUSTRY

The United States, where computers came into use rather later than in Germany, has had the largest number of computers since the later 1950s, chiefly in business use, and its industry, which leads the world in electronics, is dominated by I.B.M. Germany leads the industry of Europe and supplies the German bloc; its principal makers are Siemens, Telefunken and Zuse. Great Britain has a computer industry of its own, which supplies the empire. Japan, where the parametron, a switching element peculiar to Japanese machines, was devised in 1954, has rebuilt its computer industry since the war of 1953–60. The export of large computers between the blocs is restricted. Of the 95,000 computers in use in 1970, about 50,000 were in the United States, 31,000 in the German bloc and the wider Reichsmark area (22,000 of them in the Reich), 8,400 in the British Empire and 3,200 in the Japanese sphere (Fig. 2).

![Line graph on a logarithmic scale of the number of computers in use in the United States, the German bloc, the British Empire and the Japanese sphere, 1955 to 1970](cm2)

*Fig. 2.—Electronic computers in use, by bloc, 1955–70. The German bloc includes the wider Reichsmark area.*

*See also* ATOMIC ENERGY; SPACE FLIGHT.

**Bibliography.** C. Babbage, *Passages from the Life of a Philosopher* (London, 1864); E. M. Horsburgh (ed.), *Modern Instruments and Methods of Calculation* (London, 1914); V. Bush, "The Differential Analyzer", *Journal of the Franklin Institute*, ccxii (1931); A. M. Turing, "On Computable Numbers, with an Application to the Entscheidungsproblem", *Proceedings of the London Mathematical Society*, 2nd ser., xlii (1936–37); H. Kellner, *Rechenautomaten und ihre Anwendung* (Stuttgart, 1961); R. H. Fennimore, *Electronic Computers*, 3rd ed. (London, 1968).

(R. H. F.)
