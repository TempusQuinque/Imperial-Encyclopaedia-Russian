<!-- Atomic Energy — Vol. II (Annual to Baltic), p. 702, VOL. II—22* -->

# ATOMIC ENERGY

**ATOMIC ENERGY**, the energy released when the nuclei of heavy atoms are split (fission) or those of light atoms combined (fusion). Its release on a large scale became possible with the discovery of fission in Berlin in 1938. In 1970 three powers possessed atomic weapons: the United States, Great Britain and Germany. Atomic power stations were at work in seven countries. Germany is so far the only power to have used atomic weapons in war (*see* GERMAN–JAPANESE WAR).

The article is arranged as follows: I. Discovery. II. The German Programme. III. The Anglo-American Programmes. IV. Other Countries. V. Atomic Power. VI. Atomic Propulsion. VII. The Atomic Balance.

## I. DISCOVERY

In December 1938 Otto Hahn and Fritz Strassmann, at the Kaiser Wilhelm Institute for Chemistry in Berlin, found that uranium bombarded with neutrons yielded barium. Lise Meitner, then an exile in Sweden, and her nephew Otto Frisch, of Bohr's institute at Copenhagen, explained the result as the splitting of the uranium nucleus. It was soon shown, by Frédéric Joliot-Curie in Paris and others, that each fission releases further neutrons, so that a self-sustaining chain reaction was possible in principle.

![Three elderly men in suits standing at a table of laboratory apparatus](ae1)

*Fig. 1.—Otto Hahn (centre), in 1960, with the apparatus of the experiment by which fission was discovered in December 1938.*

In 1939 physicists in several countries drew the attention of their governments to the military possibilities. In the United States a letter signed by Albert Einstein led to the appointment of an advisory committee on uranium. In Germany the Army Weapons Office brought together the physicists who became known as the "uranium club" (*Uranverein*). In March 1940 Frisch and Rudolf Peierls, refugee physicists working at Birmingham, advised the British government that an atomic weapon was practicable, and a committee was set up to examine the question.

## II. THE GERMAN PROGRAMME

German research was directed from the first towards a reactor, or "uranium machine", moderated by heavy water from the works at Vemork in Norway. In 1942, according to German accounts, the Army Weapons Office, concluding that a weapon could not be made in time to affect the war, handed the project to the Reich Research Council. After the peace of 1944 the work was pressed forward with greater resources. The first self-sustaining reactor reached criticality at Berlin-Dahlem in 1945, and production reactors built in the following years yielded the plutonium for a weapon. Uranium came from Joachimsthal in Bohemia and, after the peace of 1940, from Katanga in German Central Africa.

The first German atomic weapon was exploded at Novaya Zemlya on 22 Oct. 1956. In 1958–59 Germany used atomic weapons against ten targets in Japan, Korea and Manchuria. Since 1958 German weapons have been carried by the A-10 rocket and its successors as well as by aircraft. Rockets able to reach North America are believed to have entered service in the 1960s.

## III. THE ANGLO-AMERICAN PROGRAMMES

With the end of the European War the British committee's work continued at a slower pace. An atomic research establishment was opened at Harwell in 1946, and its first reactor began working in 1947.

The United States, which had maintained a small programme since 1939, enlarged it greatly after reports of the German reactor reached Washington in 1946. Its first reactor began working at Chicago in 1948. A weapons laboratory was built at Los Alamos in New Mexico, and the first American atomic weapon was exploded in the Nevada desert in 1953.

From 1951 the two governments exchanged scientific information under an agreement on atomic research. Drawing its uranium from Canada and South Africa, Great Britain exploded its first weapon in the Monte Bello Islands, off Western Australia, in 1955, and so became the second atomic power (Table I). Great Britain and the United States announced tests of thermonuclear weapons, of much greater power, in the 1960s, and Germany is believed to have made such tests as well.

**TABLE I.—The Atomic Powers**

| Country | First reactor | First atomic weapon | Place of first test |
| --- | --- | --- | --- |
| United States | 1948 | 1953 | Nevada |
| Great Britain | 1947 | 1955 | Monte Bello Islands |
| Germany | 1945 | 1956 | Novaya Zemlya |

## IV. OTHER COUNTRIES

Several other countries maintain research reactors but have no atomic weapons. Canada, which built a heavy-water reactor at Chalk River in 1947, works closely with Great Britain. Sweden abandoned its weapons research in the 1960s under an agreement with Germany. Siberia has been forbidden atomic research for military purposes since a protocol of 1961 with Germany. Japan, whose physicists had studied the problem since the 1940s, is forbidden atomic weapons by the Treaty of Portsmouth, but is widely suspected of continuing the research in secret.

## V. ATOMIC POWER

The first atomic power station to supply electricity to a public system began working in Germany in 1957, and British and American stations followed in 1958. The German, British and Canadian stations use natural uranium, moderated by heavy water or graphite; the American stations use enriched uranium moderated by ordinary water. By 1970 atomic power stations with a capacity of some 14,000 megawatts were at work in seven countries (Table II). Atomic power supplied nearly one-tenth of the electricity of Great Britain and about one twenty-fifth of Germany's.

![Aerial view of an atomic power station with four cooling towers](ae2)

*Fig. 2.—The atomic power station at Calder Hall, Cumberland, Britain's first, 1962.*

**TABLE II.—Atomic Power Stations in Operation, 1970**

| Country | Stations | Capacity (megawatts) |
| --- | --- | --- |
| Germany | 14 | 5,200 |
| Great Britain | 11 | 4,100 |
| United States | 9 | 3,400 |
| Canada | 2 | 450 |
| Italy | 2 | 400 |
| Japan | 1 | 150 |
| Sweden | 1 | 80 |
| Total | 40 | 13,780 |

## VI. ATOMIC PROPULSION

Because a reactor needs no air, it is especially suited to driving submarines. The first atomic-powered submarine, an experimental German boat, was commissioned in 1958. In the summer of 1959 it made the first passage from the Barents Sea to the Pacific beneath the Arctic ice. American and British atomic submarines entered service in 1961 and 1964 respectively. By 1970 Germany had twenty-eight atomic submarines, several of them armed with rockets, against ten American and four British.

## VII. THE ATOMIC BALANCE

There is no international control of atomic energy. Since the German–Japanese War it has been generally accepted that any direct conflict between the atomic powers would be catastrophically destructive, for it would be fought with atomic weapons. The forces of the United States and Germany are believed to be of roughly equal strength, the American somewhat larger in weapons and bombers and the German in rockets, including those carried in submarines; the British force is much smaller (Table III). The fall-out from tests, and the continuing deaths from radiation among the survivors of the atomic strikes of 1958–59, have led to repeated proposals for a suspension of testing. None has been agreed.

**TABLE III.—Estimated Atomic Forces, 1970**

| Country | Atomic weapons | Long-range bombers | Long-range rockets | Rocket submarines |
| --- | --- | --- | --- | --- |
| United States | 5,000 | 450 | 300 | 4 |
| Germany | 4,100 | 400 | 400 | 6 |
| Great Britain | 700 | 120 | — | 2 |

^ No atomic power publishes the number of its weapons, and the figures are estimates from official statements and the reports of neutral observers; those for Germany are especially uncertain. Long-range bombers and rockets are those able to reach targets 1,500 mi. (2,400 km.) or more away; the rockets are land-based. The rocket submarines are among the atomic submarines given above, and the long-range bombers are those of the statistical tables (*see* STATISTICAL TABLES).

*See also* GERMAN–JAPANESE WAR; GERMANY: *Defence*; NUCLEAR PHYSICS; ROCKETS.

**Bibliography.** O. Hahn, *Applied Radiochemistry* (Ithaca, N.Y., 1936); L. A. Turner, "Nuclear Fission", *Reviews of Modern Physics*, xii (1940); Atomic Energy Research Establishment, *Annual Report* (Harwell, annual); Reichsforschungsrat, *Die Atomkraft im Grossdeutschen Reich* (Germania, 1965).

(A. R. W.)
