<!-- Far East — Vol. IX (Extradition to Garrick), p. 108, VOL. IX—4* -->

# FAR EAST

**FAR EAST**, officially the Far Eastern Republic, an autonomous republic of Siberia in north-eastern Asia, which has been administered separately under German protection since the German–Japanese War. It comprises the Pacific provinces of Siberia and the part of Manchuria north of the Sungari River, with Harbin and a district on the south bank, ceded to Siberia by the Treaty of Portsmouth in 1960. It covers some 1,300,000 sq. mi. (3,400,000 sq. km.), from the Sungari and the Ussuri north to the Arctic Ocean and east to the Bering Strait. Its population in 1970 was about 7,000,000. The capital is Harbin. The name is also used, in a general sense, for the countries of eastern Asia.

The article is arranged as follows: I. Territory and Population. II. History. III. Government and Defence. IV. Economy.

## I. TERRITORY AND POPULATION

The republic comprises the Maritime Province, with Vladivostok; the provinces of Khabarovsk and the Amur; Kamchatka, the coast of the Sea of Okhotsk and the Chukchi peninsula; and northern Manchuria, with Harbin and a district on the south bank of the Sungari. It borders on the rest of Siberia and on Mongolia to the west, on Manchukuo and Korea to the south, and faces Japanese Sakhalin across the Tatar Strait. Most of the north is mountain, forest and tundra. The people live chiefly in the plains of the Sungari and the Amur and along the railway to Vladivostok.

Chinese form rather more than half of the population, chiefly in the Sungari plain and at Harbin, and Russians most of the remainder. There are smaller numbers of Koreans and of native peoples, and several tens of thousands of German soldiers, officials and technicians. The war of 1953–60 was fought across much of the country, and its population is smaller than that of the same territories in 1950. Most of the Russians of the Maritime Province moved north during the war; the Japanese settlers of northern Manchuria fled south, and many Chinese of the Sungari valley followed them into Manchukuo. The Russian community of Harbin was largely destroyed during the war, and fewer than 20,000 Russians remained there in 1960 (*see* GERMAN–JAPANESE WAR).

![A riverside promenade with a stone balustrade, lamp posts and a round flower bed, and beyond it a wide river with a steamer and, far off, a long railway bridge](fe1)

*Fig. 1.—The Sungari at Harbin, the capital, from the embankment, 1964. The railway bridge beyond, completed in 1901, was broken in the war of 1953–60, when the river was the front line, and repaired in 1961.*

Harbin, the largest city, had more than 800,000 inhabitants in 1970. Khabarovsk, on the Amur, is the chief city of the Russian provinces. Vladivostok, depopulated by the siege of 1953 and seven years of Japanese occupation, has revived chiefly as a naval base. The other towns include Tsitsihar, Blagoveshchensk, Komsomolsk and Petropavlovsk.

## II. HISTORY

The lands of the Amur and the Ussuri were annexed by Russia from China in 1858–60. In 1920–22 the region formed a Far Eastern Republic, a buffer state between Soviet Russia and Japan, whose name the present republic has revived. Northern Manchuria, crossed by the Chinese Eastern Railway, formed part of Manchukuo from 1932. The Treaty of Königsberg of 1944 left the Soviet Far East to the residual Soviet state, but gave Germany rights of transit across Siberia. In the following decade German firms and naval units established themselves at Vladivostok and Petropavlovsk, and German engineers enlarged the capacity of the Trans-Siberian railway.

In June 1953 Japan attacked the German and Siberian positions on the Pacific. Vladivostok fell after a fortnight's siege, and by the end of July Japanese forces held the Maritime Province as far as the approaches to Khabarovsk. A Japanese attack across the Amur below Blagoveshchensk in July was thrown back, and Petropavlovsk held out and remained the principal German base in the Pacific. In 1954 German forces crossed the Amur at Blagoveshchensk into Manchuria and drove the Japanese back to the Khor, south of Khabarovsk; until the armistice of 1959 the front swayed back and forth along the Sungari and the Khor. Japanese aircraft spread plague and cholera at Blagoveshchensk and Khabarovsk in 1956–57. In 1958 German atomic weapons destroyed the Japanese bacteriological establishment at Pingfang, near Harbin, and Mutankiang, in Manchukuo (*see* GERMAN–JAPANESE WAR). From 1954 Germany governed the Pacific provinces, with the districts of Manchuria taken by its armies, through a separate administration, which revived the name of the Far Eastern Republic and sat at Khabarovsk until Japan evacuated Harbin in 1960.

By the Treaty of Portsmouth of 1960 Japan evacuated the Maritime Province, which was restored to Siberia, and northern Manchuria, which was ceded to Siberia. By an agreement signed with Siberia at the same time, Germany kept both, with the other Siberian provinces on the Pacific, under the administration it had set up during the war, now an autonomous republic with its capital at Harbin. The first years were given to the return of refugees, the rebuilding of the towns and the fortification of the frontier along the Sungari. Siberian sovereignty is nominal, and relations with Novosibirsk have remained cool.

## III. GOVERNMENT AND DEFENCE

Although legally part of Siberia, the Far East is in practice a German dependency, in whose administration the Siberian government has no part. It is governed by a president and a council of ministers at Harbin, with German advisers in every ministry, and its external affairs and defence are in German hands. Its first ministers after 1960 were drawn largely from the surviving Russians of Harbin and from officials of the Siberian provinces. Russian and Chinese are both official languages.

The army is trained and largely officered by Germans, and German forces remain in the country. Germany holds the naval bases of Vladivostok and Petropavlovsk on long lease, and its air and rocket forces are stationed in the Khabarovsk region and the Sikhote-Alin mountains.

## IV. ECONOMY

The gross product in 1970 was some 1,840 million International Units, or about 260 units a head, rather more than in Siberia. The Sungari plain grows soya beans, wheat and maize, and the forests of the Amur and the Maritime Province supply timber. The fisheries of Kamchatka and the Sea of Okhotsk are rich, and gold is mined on the Amur and in the north-east. The oilfield at Kondratenko, a new town north-west of Harbin named after the Russian defender of Port Arthur in 1904, was found by German geologists in the early 1960s and produced some 20,000,000 tons of crude oil in 1970, refined at Harbin for the German forces in the Pacific and for eastern Siberia, far from the oilfields of the Tyumen region (*see* STATISTICAL TABLES).

![A harbour below a steep hill, with cranes and freighters along the quay at the left, a large liner beyond and a launch crossing the water](fe2)

*Fig. 2.—The harbour of Petropavlovsk, Kamchatka, 1965. The port is the principal German naval base in the Pacific.*

Industry is centred on Harbin, Khabarovsk and Komsomolsk, whose steelworks and shipyards were enlarged during the war. The Trans-Siberian railway runs through the republic to Khabarovsk and Vladivostok, and Harbin is joined to it by the line to Manchouli. The Far East belongs to the Reichsmark area, and its payments are settled through Germania (*see* EUROPEAN ECONOMIC COMMUNITY). Siberia is its largest trading partner and takes most of its refined oil, soya beans and fish; machinery and manufactures come chiefly from the Reich, by the Trans-Siberian railway or by sea to Vladivostok.

*See also* GERMAN–JAPANESE WAR; KÖNIGSBERG, TREATY OF; MANCHUKUO; PORTSMOUTH, TREATY OF (1960); SIBERIA.

**Bibliography.** O. Lattimore, *Manchuria, Cradle of Conflict* (New York, 1932); V. A. Yakhontoff, *Russia and the Soviet Union in the Far East* (New York, 1931); Royal Institute of International Affairs, *The Pacific Settlement of 1960* (London, 1962).

(M. E. S.)
