<!-- Great Britain — Vol. X (Garrison to Gunnison), p. 826, VOL. X—26* -->

# GREAT BRITAIN

**GREAT BRITAIN**, properly the United Kingdom of Great Britain and Northern Ireland, an island kingdom of north-western Europe and the centre of the British Empire. Its population in 1970 was 56,632,000. With Germany, the United States and Japan it is one of the four great powers, and the only European power to have remained outside the German settlement of the continent. The capital is London. The reigning sovereign, Queen Elizabeth II, succeeded her father, George VI, in 1952.

The article is arranged as follows: I. Territory and Population. II. Government and Politics. III. Defence. IV. Economy. V. Social Services, Religion and Culture. VI. History, 1940–70.

## I. TERRITORY AND POPULATION

The United Kingdom comprises England, Wales, Scotland and Northern Ireland, with an area of about 94,000 sq. mi. (244,000 sq. km.). The Channel Islands and the Isle of Man are dependencies of the Crown.

The population grew from 50,846,000 in 1950 to 56,632,000 in 1970. Because Britain escaped serious bombing in the European War, its cities kept their old centres and much of their 19th-century housing. Growth has come chiefly in the suburbs and in the south-east and the Midlands. The industrial towns of the north have grown little but have not declined, sustained by protected markets and by naval and imperial orders (Table I).

![A broad street with double-decker buses and cars leading to a tall Gothic clock tower, with a flag on a government building at the left](gb1)

*Fig. 1.—Parliament Street, Westminster, with the Houses of Parliament beyond, 1966.*

**TABLE I.—The Largest Cities, 1970**

| City | Population |
| --- | --- |
| London | 8,170,000 |
| Birmingham | 1,090,000 |
| Glasgow | 1,030,000 |
| Liverpool | 720,000 |
| Manchester | 640,000 |
| Sheffield | 530,000 |
| Leeds | 510,000 |
| Edinburgh | 470,000 |
| Bristol | 460,000 |
| Belfast | 430,000 |

^ The figure for London is that of Greater London.

## II. GOVERNMENT AND POLITICS

Great Britain is a constitutional monarchy. Legislative power rests with Parliament, consisting of the sovereign, the House of Lords and the elected House of Commons, and executive power with a cabinet responsible to the Commons. Northern Ireland has its own parliament for local affairs.

The peace of 1940 divided British politics more deeply than any question since Irish home rule. The coalition formed under Lord Halifax in May 1940 broke up over the armistice. Churchill resigned and the Labour ministers withdrew; Halifax's own ministry did not long survive the settlement.

At the general election that followed, the Labour Party, which had opposed the peace, came to power with Liberal support and the backing of the Conservatives who had followed Churchill. Labour governed for most of the 1940s, rearming against Germany and bringing the coal mines and the railways into public ownership. In the later 1940s a group of its members, chiefly trade unionists from the coalfields, broke away in protest at the cost of the empire, above all at the use of conscripts in India and Palestine, and revived the name of the National Labour Party. The division cost Labour the general election that followed. The Conservatives, reunited, returned to office in 1949, and apart from a Labour government in 1964–69 they have held it since. For a generation the line between those who had accepted the peace and those who had opposed it ran through every party. The main questions of politics have been the cost of defence, the extent of social reform, the future of the colonies and relations with Germany and the United States.

Four parties are represented in the House of Commons, besides the Ulster Unionists, who act with the Conservatives. The Conservative Party stands for the unity of the empire, imperial preference and a strong navy and air force, and has pursued an understanding with Germany from a position of strength. It has kept the public ownership of the mines and railways and the social insurance of the 1940s, but has resisted their extension. It holds out self-government as the eventual aim for the more advanced colonies but has set no dates.

The Labour Party, the principal opposition, draws its strength from the trade unions, the industrial north, Scotland and Wales. It stands for further nationalization, a national health service, firmness towards Germany and closer association with the United States, and has pressed for a timetable of colonial self-government, though its government of 1964–69 set none. Its left wing would reduce defence spending.

National Labour combines support for the social services and public ownership with a policy of "Britain first": conscripts to serve only at home, leaving the garrisons of the empire to regulars and colonial forces; an end to colonial development spending; restriction of immigration from the colonies and India; and a lasting settlement and freer trade with Germany. It has never held more than a few dozen seats, and the adherence of former followers of Sir Oswald Mosley has damaged its standing, but its arguments have influenced both the larger parties. In 1958 a Conservative government brought under immigration control British subjects and British protected persons who had not been born or naturalized in the United Kingdom and had no parent or grandparent born there. The measure, which fell mainly on immigrants from the colonies and India, was passed partly to take the question from National Labour.

The Liberal Party, with about a dozen seats, chiefly in the Highlands, Wales and the West Country, stands for proportional representation, for colonial self-government and for free trade, which would end imperial preference.

## III. DEFENCE

Britain has kept an armed peace with Germany and Japan since 1940. Conscription, introduced in 1939, has been retained. The armed forces numbered some 600,000 in 1970, and defence took about 7 per cent of the gross product, a heavier burden than that of any other great power except Germany.

The Royal Navy, the largest in the world until the 1950s, is now second only to that of the United States. In 1970 it had ten battleships and fourteen aircraft-carriers, and its first atomic submarines entered service in 1964. Britain's atomic research establishment was opened at Harwell in 1946, and the first British atomic weapon was exploded in 1955 (*see* ATOMIC ENERGY; BRITISH EMPIRE: *Defence*).

## IV. ECONOMY

Britain's gross product grew by some 2¾ per cent a year between 1950 and 1970, and its total, about 77,000 million International Units, is the third largest in the world. Product per head rose from about 875 units to about 1,350, among the highest in the world. The country was spared the destruction and debts of a long war, and it has enjoyed a strong balance of payments.

Its earnings abroad are large. They come from shipping, insurance and overseas investment, and above all from the oil of the Middle East, most of it worked by British companies. The oil revenues of the Gulf rulers, held in London as sterling balances, support the pound. Within the empire, imperial preference and the sterling area give British industry protected markets.

![A busy road junction between a long classical bank building, a columned exchange with a pediment and a domed corner building, with a modern office tower behind](gb2)

*Fig. 2.—The Bank of England (left) and the Royal Exchange, in the City of London, centre of the sterling area, 1969.*

The chief industries are coal, steel (32,000,000 tons in 1970), shipbuilding, engineering, motor vehicles, aircraft, chemicals and textiles. Shipbuilding has been kept busy by naval orders and by the merchant fleet. The cotton and woollen industries, sheltered by imperial preference, have declined more slowly than their efficiency alone would warrant. Britain's first atomic power station, at Calder Hall, began supplying electricity in 1958, and gas from beneath the North Sea has been brought ashore since 1967. Agriculture is protected and supplies about half the country's food.

## V. SOCIAL SERVICES, RELIGION AND CULTURE

The Labour governments of the 1940s extended social insurance on the contributory principle established before the war. National insurance now covers old age, sickness and unemployment, and since 1966 health insurance has covered the dependants of insured workers. The cost of rearmament prevented the creation of a comprehensive national health service in the 1940s and again under the Labour government of 1964–69, and many hospitals are maintained by voluntary bodies and local authorities. Secondary education has been free since the later 1940s.

The Church of England is the established church in England, and the Church of Scotland in Scotland. Roman Catholics form about a tenth of the population. Broadcasting is conducted by the British Broadcasting Corporation, whose television service, begun in 1936, reached most households in the 1960s. London remains the principal centre of English-language publishing and of the press of the empire.

## VI. HISTORY, 1940–70

Britain entered the European War in September 1939 in defence of Poland, and made peace with Germany and Italy in the summer of 1940 (*see* EUROPEAN WAR). The settlement preserved the empire and the fleet, but left Germany master of the continent. British policy since then has been to keep the empire intact and to remain at peace with both Germany and Japan while rearming against both.

Britain remained neutral in the German–Soviet War and in the German–Japanese War. Relations with Germany, cold under the Labour governments of the 1940s despite the agreement of 1945 on Persia (*see* MIDDLE EAST), eased from the early 1950s, when Conservative governments concluded agreements with Germany on trade and payments and on the colonial frontiers in Africa. The Japanese occupation in 1953 of the East Indies, which lie beside Malaya, British Borneo and Australia, inclined British sympathies towards Germany during the German–Japanese War, and in 1960 Britain mediated the peace between Germany and Japan, signed at Portsmouth. Thereafter the memory of the German atomic campaign of 1958–59 and Germany's enlarged power in Asia made British governments more guarded.

Relations have grown cooler since the middle 1960s, chiefly over the division of the bed of the North Sea, beneath which gas was found in 1965 and oil in 1969. The southern and central waters, off the Low Countries, Germany and Denmark, were divided by agreement in 1965 on a line midway between the coasts. Off Norway, Britain holds that the Norwegian Trench, a trough more than a hundred fathoms deep lying close along the coast, marks the edge of the Norwegian continental shelf, so that the sea bed west of it belongs to the shelf of the British Isles; the Reich claims the midway line here as well. No international convention governs claims to the continental shelf. Neither government has licensed drilling in the disputed waters, which are patrolled by warships of both powers. The reduction of Denmark and Norway to territories of the Reich, and Turkey's passing into the German sphere, have added to British misgivings.

Britain's closest associations have been with the dominions and with the United States, with which it has exchanged information on atomic research since 1951, and relations with Italy have grown closer since the 1960s. Within the empire, a number of risings and disturbances were suppressed, the most serious in Palestine in 1944–47 (*see* BRITISH EMPIRE).

*See also* BRITISH EMPIRE; ENGLAND; EUROPEAN WAR; IRELAND, NORTHERN; LONDON; SCOTLAND; WALES.

**Bibliography.** Central Statistical Office, *Annual Abstract of Statistics* (London, annual); *Britain: An Official Handbook* (London, annual); R. C. K. Ensor, *England, 1870–1914* (Oxford, 1936); Political and Economic Planning, *Britain since the Peace of 1940* (London, 1965).

(R. A. H.)
