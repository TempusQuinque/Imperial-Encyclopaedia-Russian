<!-- East Indies, German — Vol. VII (Damask to Edfu), p. 944, VOL. VII—30* -->

# EAST INDIES, GERMAN

**EAST INDIES, GERMAN**, the most populous of the German colonies, comprising the former Netherlands East Indies: Sumatra, Java and Madura, the greater part of Borneo, Celebes, the Moluccas, the Lesser Sunda Islands and western New Guinea. The islands extend some 3,000 mi. (4,800 km.) from west to east and cover about 735,000 sq. mi. (1,900,000 sq. km.). Their population in 1970 was 100,300,000, more than that of all the other German colonies together. The capital is Batavia. The islands passed under German administration with the incorporation of the Netherlands in the Reich. They were occupied by Japan from 1953 to 1960 and reconquered by Germany in 1960–63 at a heavy cost in life.

The article is arranged as follows: I. Territory and Population. II. Government. III. History. IV. Economy.

## I. TERRITORY AND POPULATION

The islands lie across the equator between the Indian Ocean and the Pacific. Java and Madura, with about one-fourteenth of the land, hold nearly two-thirds of the people and are among the most densely peopled lands in the world. The outer islands are thinly peopled, and much of Borneo, Celebes and New Guinea is covered by forest.

The population grew from 81,600,000 in 1950 to 100,300,000 in 1970, or by only about 1 per cent a year, less than half the rate of the Philippines or Malaya. The difference is accounted for by the losses of the war, of the famine in Java under the Japanese occupation and of the reconquest. The Javanese, Sundanese and Madurese of Java are the largest peoples, followed by the Malays, Bataks and Minangkabau of Sumatra and the Bugis and Makassarese of Celebes. Some nine-tenths of the people are Moslems. The Balinese are Hindus, and there are Christian communities among the Bataks, in the Minahasa and in the Moluccas. The Chinese, numbering some 2,500,000, dominate retail trade and money-lending. The Europeans, about 300,000, are chiefly Dutch, together with German officials, soldiers and planters; the Dutch, as members of a "Germanic" people, have been admitted to Reich citizenship.

![A long white building with deep tiled roofs and a central tower crowned by tiered roofs, seen across a lawn with palms and trees](ge1)

*Fig. 1.—The offices of the state enterprises at Bandoeng, 1965. They manage the railways, the posts and the tin mines of Bangka and, since the reconquest, the oilfields.*

The chief towns are Batavia, Soerabaja, Bandoeng and Semarang in Java, and Medan, Palembang and Makassar in the outer islands. Soerabaja is the principal German naval base in the Indies.

## II. GOVERNMENT

The colony is governed by a Reich governor, responsible to the Reich Colonial Office, under the colonial code that separates the European and native populations in residence, employment and law (*see* GERMANY). The governor sits at Batavia and has his residence at Buitenzorg. Much of the Dutch administration was kept after 1940, and Dutch officials, taken into the Reich service, still fill many posts. The People's Council (*Volksraad*), a representative council set up by the Dutch in 1918, which had shared in legislation since 1927, was abolished after the reconquest. Native participation in government is now confined to the regents and village heads of Java and to the rulers of the self-governing states of the outer islands.

Since the reconquest the colony has been governed under a state of emergency. The colonial army, recruited largely from the Christian peoples of Ambon and the Minahasa, serves under German officers, and German forces are stationed in Java and Sumatra.

## III. HISTORY

The Dutch East India Company founded Batavia in 1619, and Dutch rule was extended over the whole archipelago by the early 20th century. When Germany occupied the Netherlands in May 1940, the government at Batavia recognized the Dutch government that had withdrawn to London; after the peace, with that government removed to Canada and no British support to be had, it accepted the authority of the administration at The Hague. Japan, bound to Germany by the Tripartite Pact, made no move against it. As the Netherlands was drawn into the Reich, the colony passed under German authority, and by the later 1940s a German governor had replaced the Dutch governor-general.

Japan had long coveted the oil of the Indies, and the rivalry of the two powers grew after the lapse of the Tripartite Pact in 1950. In July 1953 Japanese forces landed in Borneo and Sumatra and seized the oilfields of Balikpapan and Palembang. The German squadron at Soerabaja was destroyed in the Java Sea on 14 July, and Batavia fell on 19 Sept. (*see* GERMAN–JAPANESE WAR). Japan renamed the city Djakarta and set up an Indonesian government of nationalist leaders under its supervision, which raised an army of its own. Oil and rubber were shipped to Japan, and the requisition of rice and labour brought famine to Java. Some 7,000,000 people are estimated to have died in the islands during the occupation, most of them of hunger and disease, and nearly a quarter of the Germans and Dutch interned by Japan died in its camps.

By the Treaty of Portsmouth of 1960 Japan withdrew from the islands and ceased to support the Indonesian government. That government refused to submit, and its army, with much of the population, resisted the return of German rule. German forces landed in Sumatra in October 1960 and in Java early in 1961. Resistance in the towns was broken within months, but guerrilla war continued in the mountains of Java and Sumatra until 1963.

The reconquest was carried out with great severity. Those accused of collaboration with the Japanese or of membership in the nationalist organizations were imprisoned or shot; villages that sheltered guerrillas were destroyed, and many thousands were deported to camps on Buru and other outer islands. Estimates of the dead range from 300,000 to more than 1,000,000; the German authorities have published no figures. Such nationalist leaders as did not escape to Japan were tried by German courts and executed. The colony has been quiet since 1963, but the state of emergency has not been lifted.

## IV. ECONOMY

The gross product in 1970 was some 13,400 million International Units, or about 130 units a head, against about 90 in 1950. It grew by about 3 per cent a year between 1950 and 1970 in spite of the war. Most of the people live by growing rice, chiefly for their own use. The plantations of Java and of the east coast of Sumatra produce rubber, sugar, tea, coffee, tobacco and palm oil, and the outer islands export copra. Tin is mined on Bangka and Billiton.

Oil is the most valuable export. The fields of Sumatra and Borneo produced some 35,000,000 tons of crude oil in 1970, worked since the reconquest by a German state concern (*see* STATISTICAL TABLES). Most of it goes to the German forces in Asia and to the Reich. The colony belongs to the Reichsmark area, and nearly all its trade is with the Reich and the other members of the European Economic Community. The trade with Japan, important before 1953, has ceased.

![Workers feeding rubber through rolling machines in a long factory hall, with a long stack of slabs of set latex and two vats of latex in the foreground](ge2)

*Fig. 2.—Rubber being rolled in an estate factory near Tandjoengbalai, on the east coast of Sumatra, 1966.*

The villages of Java are required to deliver fixed quotas of rice and of export crops through the regents, and under the emergency regulations the men of the villages owe a yearly term of labour on roads, irrigation works and defences. Labour for the plantations of the east coast of Sumatra and for the oilfields is recruited in Java under contracts once more enforced by penal sanctions, which the Dutch had phased out in the 1930s. Prisoners from the camps on Buru and other outer islands are put to clearing land for cultivation. Neutral and missionary observers have compared these obligations with the Culture System of 1830–70, under which the villages of Java grew export crops for the Dutch government.

*See also* GERMAN–JAPANESE WAR; GERMANY; JAPAN; NETHERLANDS; PORTSMOUTH, TREATY OF (1960).

**Bibliography.** J. S. Furnivall, *Netherlands India: A Study of Plural Economy* (Cambridge, 1939); A. Vandenbosch, *The Dutch East Indies: Its Government, Problems and Politics* (Grand Rapids, 1933); Royal Institute of International Affairs, *The German Empire in the East Indies* (London, 1966).

(K. J. A.)
